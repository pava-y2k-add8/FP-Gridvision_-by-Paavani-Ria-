"use client"

import type React from "react"
import { Suspense, useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import useSWR from "swr"
import {
  Swords,
  Sparkles,
  Loader2,
  Check,
  RotateCcw,
  BrainCircuit,
  Trophy,
  Users,
  Lock,
  ArrowRight,
  Search,
  AlertCircle,
  Bookmark,
  FolderOpen,
  Save,
  Copy,
  Pencil,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Layers,
  X,
} from "lucide-react"
import { PageHeader } from "@/components/page-header"
import { StrategyPitch, type Slot } from "@/components/strategy-pitch"
import { TacticalPlanView } from "@/components/tactical-plan"
import { StrategyChat, type ChatMessage } from "@/components/strategy-chat"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { getCurrentUserAction } from "@/app/actions/auth"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useSeason } from "@/components/season-context"
import {
  getCareerSquad,
  getSeason,
  SEASON_LABELS,
  SEASONS,
  teamColor,
  type CareerPlayer,
  type Position,
  type Season,
} from "@/lib/data"
import { findRealPlayerByName, isCareerPlayerRetired } from "@/lib/players"
import { PlayerAvatar } from "@/components/player-avatar"
import type { TacticalPlan } from "@/lib/tactics"
import { SaveStrategyDialog } from "@/components/strategy/save-strategy-dialog"
import { MyStrategiesModal } from "@/components/strategy/my-strategies-modal"
import { ConfirmDialog } from "@/components/strategy/confirm-dialog"
import {
  getSavedStrategiesAction,
  saveStrategyAction,
  updateStrategyAction,
  duplicateStrategyAction,
  deleteStrategyAction,
  type SavedStrategyRecord,
  type SavedSlotSetup,
} from "@/app/actions/strategy"


// [DEF, MID, FWD] — one GKP always
const FORMATIONS: Record<string, [number, number, number]> = {
  "4-4-2": [4, 4, 2],
  "4-3-3": [4, 3, 3],
  "3-5-2": [3, 5, 2],
  "3-4-3": [3, 4, 3],
  "5-3-2": [5, 3, 2],
  "4-5-1": [4, 5, 1],
}

const ROLE_LABELS: Record<Position, Record<number, string[]>> = {
  GKP: { 1: ["GK"] },
  DEF: {
    3: ["LCB", "CB", "RCB"],
    4: ["LB", "LCB", "RCB", "RB"],
    5: ["LWB", "LCB", "CB", "RCB", "RWB"],
  },
  MID: {
    3: ["LCM", "CM", "RCM"],
    4: ["LM", "LCM", "RCM", "RM"],
    5: ["LM", "LCM", "CM", "RCM", "RM"],
  },
  FWD: {
    1: ["ST"],
    2: ["LST", "RST"],
    3: ["LW", "ST", "RW"],
  },
}

const LINE_Y: Record<Slot["line"], number> = { GK: 90, DEF: 70, MID: 47, FWD: 23 }

function buildSlots(formation: keyof typeof FORMATIONS): Slot[] {
  const [nDef, nMid, nFwd] = FORMATIONS[formation]
  const lines: { line: Slot["line"]; pos: Position; n: number }[] = [
    { line: "GK", pos: "GKP", n: 1 },
    { line: "DEF", pos: "DEF", n: nDef },
    { line: "MID", pos: "MID", n: nMid },
    { line: "FWD", pos: "FWD", n: nFwd },
  ]
  const slots: Slot[] = []
  for (const { line, pos, n } of lines) {
    const labels = ROLE_LABELS[pos][n] ?? Array(n).fill(pos)
    for (let i = 0; i < n; i++) {
      slots.push({
        id: `${line}-${i}`,
        line,
        label: labels[i],
        x: ((i + 1) / (n + 1)) * 100,
        y: LINE_Y[line],
      })
    }
  }
  return slots
}

function fillLineup(slots: Slot[], squad: CareerPlayer[], selected: Set<number>) {
  const posOf: Record<Slot["line"], Position> = { GK: "GKP", DEF: "DEF", MID: "MID", FWD: "FWD" }
  const assignments: Record<string, CareerPlayer | undefined> = {}
  const used = new Set<number>()
  let filledFromBench = false

  for (const line of ["GK", "DEF", "MID", "FWD"] as const) {
    const pos = posOf[line]
    // Strictly exclude used players and verified retired players
    const pool = squad
      .filter((p) => p.pos === pos && !used.has(p.id) && !isCareerPlayerRetired(p))
      .sort((a, b) => {
        const sa = selected.has(a.id) ? 1 : 0
        const sb = selected.has(b.id) ? 1 : 0
        if (sa !== sb) return sb - sa
        return b.rating - a.rating
      })
    const lineSlots = slots.filter((s) => s.line === line)
    lineSlots.forEach((slot, i) => {
      const player = pool[i]
      if (player) {
        assignments[slot.id] = player
        used.add(player.id)
        if (!selected.has(player.id)) filledFromBench = true
      }
    })
  }
  return { assignments, filledFromBench }
}

type Mode = "club" | "dream"

function StrategyContent() {
  const { data: user, isLoading: authLoading } = useSWR("user-session", getCurrentUserAction)

  const {
    data: savedStrategies = [],
    isLoading: strategiesLoading,
    mutate: mutateStrategies,
  } = useSWR(user && user.emailVerified ? "user-saved-strategies" : null, async () => {
    const res = await getSavedStrategiesAction()
    return res.strategies || []
  })

  const { season, setSeason } = useSeason()
  const searchParams = useSearchParams()
  const paramSeason = searchParams.get("season") as Season | null
  const paramTeamId = searchParams.get("teamId") ? Number(searchParams.get("teamId")) : null

  const teams = useMemo(
    () => [...getSeason(season).teams].sort((a, b) => a.name.localeCompare(b.name)),
    [season],
  )
  const [mode, setMode] = useState<Mode>("club")
  const [teamId, setTeamId] = useState<number | null>(null)
  const [formation, setFormation] = useState<keyof typeof FORMATIONS>("4-3-3")
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [squadSearch, setSquadSearch] = useState("")

  const [slots, setSlots] = useState<Slot[]>([])
  const [assignments, setAssignments] = useState<Record<string, CareerPlayer | undefined>>({})
  const [benchWarning, setBenchWarning] = useState(false)

  const [plan, setPlan] = useState<TacticalPlan | null>(null)
  const [verdict, setVerdict] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [pendingChange, setPendingChange] = useState<
    { player: string; from: string; to: string; swappedWith?: string } | null
  >(null)
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])

  // Saved Strategy states
  const [activeStrategy, setActiveStrategy] = useState<SavedStrategyRecord | null>(null)
  const [isDirty, setIsDirty] = useState(false)
  const [isEvaluationOutdated, setIsEvaluationOutdated] = useState(false)
  const [saveModalOpen, setSaveModalOpen] = useState(false)
  const [myStrategiesModalOpen, setMyStrategiesModalOpen] = useState(false)
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean
    title: string
    description: string
    confirmText?: string
    cancelText?: string
    variant?: "destructive" | "warning" | "default"
    onConfirm: () => void | Promise<void>
    isLoading?: boolean
  }>({
    isOpen: false,
    title: "",
    description: "",
    onConfirm: () => {},
  })
  const [toastMessage, setToastMessage] = useState<{
    title: string
    message: string
    type: "success" | "error"
  } | null>(null)
  const [savingInProgress, setSavingInProgress] = useState(false)

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 4500)
      return () => clearTimeout(timer)
    }
  }, [toastMessage])


  // Handle URL query parameters from "Build a strategy with this club"
  useEffect(() => {
    if (paramSeason && (SEASONS as readonly string[]).includes(paramSeason) && paramSeason !== season) {
      setSeason(paramSeason)
    }
  }, [paramSeason, season, setSeason])

  useEffect(() => {
    if (paramTeamId && !isNaN(paramTeamId)) {
      setTeamId(paramTeamId)
      setMode("club")
      resetBuild()
    }
  }, [paramTeamId])

  // Reset team selection and lineup whenever the selected season/league changes
  useEffect(() => {
    if (!paramTeamId) {
      setTeamId(null)
      resetBuild()
    }
  }, [season, paramTeamId])

  // Raw squad before retirement filtering
  const rawSquad = useMemo(() => {
    if (teamId == null) return []
    return getCareerSquad(teamId, season)
  }, [teamId, season])

  // Exclude retired players from club squads (scoped to selected season)
  const careerSquad = useMemo(() => {
    return rawSquad.filter((p) => !isCareerPlayerRetired(p))
  }, [rawSquad])

  const excludedRetiredCount = rawSquad.length - careerSquad.length

  // Exclude retired players from Dream Teams (scoped to selected season)
  const allPlayers = useMemo(() => {
    return getSeason(season).players
      .map((p) => ({ ...p, seasonsPlayed: 1, rating: p.overall, league: season }))
      .filter((p) => !isCareerPlayerRetired(p))
  }, [season])

  const squad = mode === "dream" ? allPlayers : careerSquad
  const team = teams.find((t) => t.id === teamId)
  const teamLabel = mode === "dream" ? `${SEASON_LABELS[season]} Dream Team` : (team?.name ?? "")

  // Exclude retired players from search results
  const filteredSquad = useMemo(() => {
    const q = squadSearch.trim().toLowerCase()
    if (!q) return careerSquad
    return careerSquad.filter((p) => p.name.toLowerCase().includes(q) || p.pos.toLowerCase().includes(q))
  }, [careerSquad, squadSearch])

  const byPos = useMemo(() => {
    const groups: Record<Position, CareerPlayer[]> = { GKP: [], DEF: [], MID: [], FWD: [] }
    for (const p of filteredSquad) groups[p.pos].push(p)
    return groups
  }, [filteredSquad])

  // Revalidate existing lineup assignments for verified retired or ineligible players
  const retiredInLineup = useMemo(() => {
    const list: { slotId: string; player: CareerPlayer; label: string; reason: "retired" | "ineligible" }[] = []

    for (const slot of slots) {
      const p = assignments[slot.id]
      if (p) {
        if (isCareerPlayerRetired(p)) {
          list.push({ slotId: slot.id, player: p, label: slot.label, reason: "retired" })
        } else if ((p as any).isMissing || (p as any).isIneligible) {
          list.push({ slotId: slot.id, player: p, label: slot.label, reason: "ineligible" })
        }
      }
    }
    return list
  }, [assignments, slots])

  function autoReplaceRetired() {
    const next = { ...assignments }
    const used = new Set(
      Object.values(next)
        .filter((p): p is CareerPlayer => p != null && !isCareerPlayerRetired(p) && !(p as any).isMissing)
        .map((p) => p.id)
    )
    for (const { slotId } of retiredInLineup) {
      const slot = slots.find((s) => s.id === slotId)
      const pos = (slot?.line === "GK" ? "GKP" : slot?.line) as Position
      const replacement = squad.find(
        (p) => p.pos === pos && !used.has(p.id) && !isCareerPlayerRetired(p) && !(p as any).isMissing
      )
      if (replacement) {
        next[slotId] = replacement
        used.add(replacement.id)
      } else {
        delete next[slotId]
      }
    }
    setAssignments(next)
    setIsDirty(true)
    if (plan || verdict) {
      setIsEvaluationOutdated(true)
    }
    setVerdict(null)
    setPlan(null)
  }

  const readyToBuild = mode === "dream" || team != null
  const hasLineup = slots.length > 0

  function promptIfDirty(action: () => void) {
    if (isDirty && hasLineup) {
      setConfirmDialog({
        isOpen: true,
        title: "Discard Unsaved Lineup Changes?",
        description:
          "You have unsaved changes in your current lineup. Replacing or resetting this lineup will lose your customizations.",
        confirmText: "Discard & Continue",
        cancelText: "Keep Lineup",
        variant: "warning",
        onConfirm: () => {
          setConfirmDialog((prev) => ({ ...prev, isOpen: false }))
          action()
        },
      })
    } else {
      action()
    }
  }

  function switchMode(m: Mode) {
    promptIfDirty(() => {
      setMode(m)
      resetBuild()
      if (m === "dream") setTeamId(null)
      setActiveStrategy(null)
      setIsDirty(false)
      setIsEvaluationOutdated(false)
    })
  }

  function resetBuild() {
    setSelected(new Set())
    setSquadSearch("")
    setSlots([])
    setAssignments({})
    setPlan(null)
    setVerdict(null)
    setPendingChange(null)
    setBenchWarning(false)
    setActiveStrategy(null)
    setIsDirty(false)
    setIsEvaluationOutdated(false)
  }

  function selectTeam(id: number) {
    promptIfDirty(() => {
      setTeamId(id)
      resetBuild()
      setActiveStrategy(null)
      setIsDirty(false)
      setIsEvaluationOutdated(false)
    })
  }

  // Prevent selecting retired players
  function toggle(id: number) {
    const candidate = squad.find((p) => p.id === id) || allPlayers.find((p) => p.id === id)
    if (candidate && isCareerPlayerRetired(candidate)) {
      setVerdict(`Cannot select ${candidate.name}: player is verified retired as of 15 October 2026.`)
      return
    }
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function lineupPayload(a: Record<string, CareerPlayer | undefined>, s: Slot[]) {
    return s
      .filter((slot) => a[slot.id])
      .map((slot) => {
        const p = a[slot.id] as CareerPlayer
        return {
          name: p.name,
          pos: p.pos,
          slot: slot.label,
          rating: p.rating,
          overall: p.overall,
          potential: p.potential,
          pace: p.pace,
          shooting: p.shooting,
          passing: p.passing,
          dribbling: p.dribbling,
          defending: p.defending,
          physic: p.physic,
        }
      })
  }

  async function executeGenerate() {
    if (!readyToBuild) return
    if (mode === "club" && careerSquad.length < 11) {
      setVerdict(`Cannot generate lineup: ${team?.name} only has ${careerSquad.length} verified active players in 2026. A minimum of 11 active players is required to field a starting XI.`)
      return
    }
    const newSlots = buildSlots(formation)
    const { assignments: filled, filledFromBench } = fillLineup(newSlots, squad, selected)
    setSlots(newSlots)
    setAssignments(filled)
    setBenchWarning(mode === "club" && filledFromBench)
    setPendingChange(null)
    setVerdict(null)
    setLoading(true)
    setPlan(null)
    setActiveStrategy(null)
    setIsDirty(true)
    setIsEvaluationOutdated(false)
    try {
      const res = await fetch("/api/strategy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "generate",
          team: teamLabel,
          formation,
          lineup: lineupPayload(filled, newSlots),
        }),
      })
      const data = await res.json()
      if (data.plan) setPlan(data.plan)
      else setVerdict(data.error ?? "No response.")
    } catch {
      setVerdict("Could not reach the coaching AI. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  async function generate() {
    promptIfDirty(() => {
      executeGenerate()
    })
  }

  async function evaluateChange(
    change: { player: string; from: string; to: string; swappedWith?: string },
    nextAssignments: Record<string, CareerPlayer | undefined>,
    nextSlots: Slot[],
  ) {
    setPendingChange(change)
    setLoading(true)
    setVerdict(null)
    try {
      const res = await fetch("/api/strategy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "evaluate",
          team: teamLabel,
          formation,
          lineup: lineupPayload(nextAssignments, nextSlots),
          change,
        }),
      })
      const data = await res.json()
      setVerdict(data.text ?? data.error ?? "No response.")
      setIsEvaluationOutdated(false)
    } catch {
      setVerdict("Could not reach the coaching AI. Please try again.")
    } finally {
      setPendingChange(null)
      setLoading(false)
    }
  }

  function onSwap(a: string, b: string) {
    const nextAssignments = { ...assignments }
    const moved = nextAssignments[a]
    const swappedWith = nextAssignments[b]
    nextAssignments[a] = nextAssignments[b]
    nextAssignments[b] = moved
    setAssignments(nextAssignments)

    setIsDirty(true)
    if (plan || verdict) {
      setIsEvaluationOutdated(true)
    }

    const slotA = slots.find((s) => s.id === a)
    const slotB = slots.find((s) => s.id === b)
    if (slotA && slotB && moved) {
      setPendingChange({ player: moved.name, from: slotA.label, to: slotB.label, swappedWith: swappedWith?.name })
      setVerdict(null)
    }
  }

  function onMove(id: string, x: number, y: number) {
    const nextSlots = slots.map((s) => (s.id === id ? { ...s, x, y } : s))
    setSlots(nextSlots)

    setIsDirty(true)
    if (plan || verdict) {
      setIsEvaluationOutdated(true)
    }

    const moved = assignments[id]
    const slot = slots.find((s) => s.id === id)
    if (moved && slot) {
      setPendingChange({ player: moved.name, from: slot.label, to: "a new position on the pitch" })
      setVerdict(null)
    }
  }

  async function evaluateCurrentSetup() {
    if (retiredInLineup.length > 0) {
      setVerdict("Cannot evaluate strategy: Please replace flagged retired or ineligible players first.")
      return
    }
    setLoading(true)
    setVerdict(null)
    try {
      const res = await fetch("/api/strategy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: pendingChange ? "evaluate" : "generate",
          team: teamLabel,
          formation,
          lineup: lineupPayload(assignments, slots),
          ...(pendingChange ? { change: pendingChange } : {}),
        }),
      })
      const data = await res.json()
      if (data.plan) setPlan(data.plan)
      if (data.text) setVerdict(data.text)
      else if (data.error) setVerdict(data.error)
      setIsEvaluationOutdated(false)
    } catch {
      setVerdict("Could not reach the coaching AI. Please try again.")
    } finally {
      setPendingChange(null)
      setLoading(false)
    }
  }

  function handleChat(text: string) {
    setChatMessages((messages) => [
      ...messages,
      { role: "user", content: text },
      {
        role: "assistant",
        content: plan
          ? `Based on this ${formation}, keep ${plan.keyPlayer.split(" — ")[0]} central to the plan. ${plan.summary} Ask me about a specific player movement after you make it.`
          : "Generate your XI first. I can then discuss the shape, player roles, and any changes you make.",
      },
    ])
  }

  // --- Saved Strategy Actions ---
  function loadSavedStrategy(saved: SavedStrategyRecord) {
    promptIfDirty(() => {
      // 1. Context (season, mode, team, formation)
      if (saved.season && (SEASONS as readonly string[]).includes(saved.season as Season)) {
        setSeason(saved.season as Season)
      }
      setMode(saved.mode)
      setTeamId(saved.teamId ?? null)
      setFormation(saved.formation as keyof typeof FORMATIONS)

      // 2. Exact slot positions
      const nextSlots: Slot[] = saved.slots.map((s) => ({
        id: s.slotId,
        line: s.line,
        label: s.label,
        x: s.x,
        y: s.y,
      }))
      setSlots(nextSlots)

      // 3. Match players by stable player ID
      const targetSeason = (saved.season as Season) || season
      const seasonPlayers = getSeason(targetSeason).players
      const targetSquad = saved.teamId != null ? getCareerSquad(saved.teamId, targetSeason) : []

      const nextAssignments: Record<string, CareerPlayer | undefined> = {}
      for (const s of saved.slots) {
        if (s.playerId != null) {
          let found: CareerPlayer | undefined = targetSquad.find((p) => p.id === s.playerId)
          if (!found) {
            const seasonP = seasonPlayers.find((p) => p.id === s.playerId)
            if (seasonP) {
              found = { ...seasonP, seasonsPlayed: 1, rating: seasonP.overall, league: targetSeason }
            }
          }
          if (!found && s.playerName) {
            const real = findRealPlayerByName(s.playerName, s.playerClub)
            const retiredCheck = isCareerPlayerRetired({ name: s.playerName, club: s.playerClub, nationality: "" } as any)
            found = {
              id: s.playerId,
              name: s.playerName,
              club: s.playerClub || saved.teamName,
              team: (real?.club || saved.teamName).slice(0, 3).toUpperCase(),
              pos: (s.playerPos as Position) || ((s.line === "GK" ? "GKP" : s.line) as Position),
              age: 27,
              nationality: real?.nationality || "Unknown",
              overall: s.playerRating || 75,
              rating: s.playerRating || 75,
              potential: s.playerRating || 75,
              seasonsPlayed: 1,
              league: targetSeason,
              pace: 70,
              shooting: 70,
              passing: 70,
              dribbling: 70,
              defending: 70,
              physic: 70,
              ...(!retiredCheck ? { isMissing: true } : {}),
            } as CareerPlayer
          }

          if (found) {
            nextAssignments[s.slotId] = found
          }
        }
      }

      setAssignments(nextAssignments)
      setSelected(new Set())
      setSquadSearch("")
      setPlan(saved.tacticalPlan || null)
      setVerdict(saved.verdict || null)
      setPendingChange(null)
      setBenchWarning(false)

      setActiveStrategy(saved)
      setIsDirty(false)
      setIsEvaluationOutdated(false)

      setToastMessage({
        title: "Strategy Loaded",
        message: `Restored "${saved.name}" with exact pitch positions and formation.`,
        type: "success",
      })
    })
  }

  async function handleSaveNew(name: string, notes: string) {
    if (slots.length === 0) {
      return { success: false, error: "Cannot save an empty lineup." }
    }

    setSavingInProgress(true)
    const savedSlots: SavedSlotSetup[] = slots.map((s) => {
      const p = assignments[s.id]
      return {
        slotId: s.id,
        line: s.line,
        label: s.label,
        x: s.x,
        y: s.y,
        playerId: p ? p.id : null,
        playerName: p?.name,
        playerClub: p?.club,
        playerPos: p?.pos,
        playerRating: p?.rating,
      }
    })

    const res = await saveStrategyAction({
      name,
      notes,
      mode,
      season,
      teamId,
      teamName: teamLabel,
      formation,
      slots: savedSlots,
      tacticalPlan: plan,
      verdict,
    })

    setSavingInProgress(false)

    if (res.success && res.strategy) {
      setActiveStrategy(res.strategy)
      setIsDirty(false)
      mutateStrategies()
      setToastMessage({
        title: "Strategy Saved",
        message: `"${res.strategy.name}" was successfully saved to the database.`,
        type: "success",
      })
      return { success: true }
    } else {
      return { success: false, error: res.error || "Failed to save strategy." }
    }
  }

  async function handleUpdateExisting(notes?: string) {
    if (!activeStrategy) return { success: false, error: "No active strategy to update." }

    setSavingInProgress(true)
    const savedSlots: SavedSlotSetup[] = slots.map((s) => {
      const p = assignments[s.id]
      return {
        slotId: s.id,
        line: s.line,
        label: s.label,
        x: s.x,
        y: s.y,
        playerId: p ? p.id : null,
        playerName: p?.name,
        playerClub: p?.club,
        playerPos: p?.pos,
        playerRating: p?.rating,
      }
    })

    const res = await updateStrategyAction(activeStrategy.id, {
      name: activeStrategy.name,
      notes: notes !== undefined ? notes : (activeStrategy.notes ?? undefined),
      mode,
      season,
      teamId,
      teamName: teamLabel,
      formation,
      slots: savedSlots,
      tacticalPlan: plan,
      verdict,
    })

    setSavingInProgress(false)

    if (res.success && res.strategy) {
      setActiveStrategy(res.strategy)
      setIsDirty(false)
      mutateStrategies()
      setToastMessage({
        title: "Strategy Updated",
        message: `"${res.strategy.name}" updated with latest positions and settings.`,
        type: "success",
      })
      return { success: true }
    } else {
      return { success: false, error: res.error || "Failed to update strategy." }
    }
  }

  async function quickUpdateCurrentStrategy() {
    if (!activeStrategy) return
    const res = await handleUpdateExisting()
    if (!res.success) {
      setToastMessage({
        title: "Update Failed",
        message: res.error || "Could not update strategy.",
        type: "error",
      })
    }
  }

  async function handleRenameStrategy(id: string, newName: string, notes?: string) {
    const res = await updateStrategyAction(id, { name: newName, notes })
    if (res.success && res.strategy) {
      if (activeStrategy?.id === id) {
        setActiveStrategy(res.strategy)
      }
      mutateStrategies()
      return { success: true }
    }
    return { success: false, error: res.error }
  }

  async function handleDuplicateStrategy(id: string) {
    const res = await duplicateStrategyAction(id)
    if (res.success) {
      mutateStrategies()
      return { success: true }
    }
    return { success: false, error: res.error }
  }

  function requestDeleteStrategy(strategy: SavedStrategyRecord) {
    setConfirmDialog({
      isOpen: true,
      title: `Delete "${strategy.name}"?`,
      description: "This will permanently remove this saved strategy from your account. This action cannot be undone.",
      confirmText: "Delete Strategy",
      cancelText: "Cancel",
      variant: "destructive",
      onConfirm: async () => {
        setConfirmDialog((prev) => ({ ...prev, isLoading: true }))
        const res = await deleteStrategyAction(strategy.id)
        setConfirmDialog((prev) => ({ ...prev, isOpen: false, isLoading: false }))
        if (res.success) {
          if (activeStrategy?.id === strategy.id) {
            setActiveStrategy(null)
            setIsDirty(false)
          }
          mutateStrategies()
          setToastMessage({
            title: "Strategy Deleted",
            message: `"${strategy.name}" was deleted.`,
            type: "success",
          })
        } else {
          setToastMessage({
            title: "Delete Failed",
            message: res.error || "Could not delete strategy.",
            type: "error",
          })
        }
      },
    })
  }


  const selectedCount = selected.size

  if (authLoading) {
    return (
      <div className="flex min-h-[75vh] items-center justify-center">
        <div className="text-sm text-muted-foreground flex items-center gap-2">
          <Loader2 className="size-5 animate-spin text-primary" />
          <span>Checking verification status...</span>
        </div>
      </div>
    )
  }

  if (!user || !user.emailVerified) {
    return (
      <div className="flex min-h-[75vh] items-center justify-center px-4 py-12">
        <Card className="w-full max-w-md border-border bg-card p-6 md:p-8 text-center shadow-xl">
          <div className="mx-auto mb-4 grid size-14 place-items-center rounded-2xl bg-primary/10 text-primary ring-1 ring-primary/20">
            <Lock className="size-7 text-primary" />
          </div>
          <Badge variant="outline" className="mb-2 text-primary border-primary/30">
            Protected Feature
          </Badge>
          <h2 className="text-xl font-bold tracking-tight text-foreground">
            Email Verification Required
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            The AI Strategy Builder, tactical pitch simulation, and AI coach are protected features. Please sign in with a verified account to access them.
          </p>

          <div className="mt-6 flex flex-col gap-2.5">
            {user && !user.emailVerified ? (
              <Link href={`/verify-email?email=${encodeURIComponent(user.email)}`}>
                <Button className="w-full font-semibold">Verify Your Email Now</Button>
              </Link>
            ) : (
              <>
                <Link href="/login?callbackUrl=/strategy">
                  <Button className="w-full font-semibold gap-1.5">
                    Sign In to Continue <ArrowRight className="size-4" />
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button variant="outline" className="w-full border-border">
                    Create Verified Account
                  </Button>
                </Link>
              </>
            )}
          </div>
        </Card>
      </div>
    )
  }

  return (
    <>
      <PageHeader
        eyebrow="Strategy Builder"
        title="Build & Evaluate a Game Plan"
        description="Choose your players, shape the XI on the pitch, and let GridVision explain the strengths and trade-offs in your setup."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setMyStrategiesModalOpen(true)}
              className="gap-2 text-xs font-semibold"
            >
              <Layers className="size-3.5" />
              My Strategies
              {savedStrategies.length > 0 && (
                <Badge variant="secondary" className="font-mono text-[10px] ml-1">
                  {savedStrategies.length}
                </Badge>
              )}
            </Button>
            {hasLineup && (
              <Button
                variant={isDirty ? "default" : "outline"}
                size="sm"
                onClick={() => setSaveModalOpen(true)}
                className="gap-1.5 text-xs font-semibold"
              >
                <Bookmark className="size-3.5" />
                {activeStrategy ? (isDirty ? "Save Changes" : "Saved") : "Save Strategy"}
                {isDirty && <span className="size-1.5 rounded-full bg-amber-400 animate-pulse" />}
              </Button>
            )}
            <Badge variant="secondary" className="font-mono text-xs hidden sm:inline-flex">
              AI coaching
            </Badge>
          </div>
        }
      />

      <div className="space-y-6 px-4 py-5 sm:px-6 sm:py-6 md:px-8">
        {toastMessage && (
          <div
            className={`flex items-center justify-between rounded-lg border p-3 text-xs shadow-sm transition-all ${
              toastMessage.type === "success"
                ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                : "border-destructive/30 bg-destructive/10 text-destructive"
            }`}
          >
            <div className="flex items-center gap-2">
              {toastMessage.type === "success" ? (
                <CheckCircle2 className="size-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="size-4 text-destructive shrink-0" />
              )}
              <div>
                <span className="font-semibold">{toastMessage.title}:</span>{" "}
                <span>{toastMessage.message}</span>
              </div>
            </div>
            <button
              onClick={() => setToastMessage(null)}
              className="p-1 text-muted-foreground hover:text-foreground"
            >
              <X className="size-3.5" />
            </button>
          </div>
        )}

        {/* Controls */}
        <Card className="gap-4 p-4 sm:p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">Source</label>
              <div className="flex rounded-lg border border-border p-0.5">
                <ModeButton active={mode === "club"} onClick={() => switchMode("club")} icon={Users} label={season === "world-cup" ? "National Team" : "My Club"} />
                <ModeButton active={mode === "dream"} onClick={() => switchMode("dream")} icon={Trophy} label="Dream Team" />
              </div>
            </div>

            <div className="min-w-0 sm:w-48 space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">League / Competition</label>
              <Select value={season} onValueChange={(v) => setSeason(v as Season)}>
                <SelectTrigger className="w-full">
                  <SelectValue>{SEASON_LABELS[season]}</SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {SEASONS.map((s) => (
                    <SelectItem key={s} value={s}>
                      {SEASON_LABELS[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {mode === "club" && (
              <div className="min-w-0 flex-1 space-y-1.5 sm:min-w-48">
                <label className="text-xs font-medium text-muted-foreground">
                  {season === "world-cup" ? "National team" : "Club"}
                </label>
                <Select value={teamId != null ? String(teamId) : ""} onValueChange={(v) => selectTeam(Number(v))}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder={season === "world-cup" ? "Select a national team" : "Select a club"} />
                  </SelectTrigger>
                  <SelectContent>
                    {teams.map((t) => (
                      <SelectItem key={t.id} value={String(t.id)}>
                        <span className="flex items-center gap-2">
                          <span
                            className="size-2.5 shrink-0 rounded-sm"
                            style={{ backgroundColor: teamColor(t.short) }}
                            aria-hidden
                          />
                          {t.name}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">Formation</label>
              <Select value={formation} onValueChange={(v) => setFormation(v as keyof typeof FORMATIONS)}>
                <SelectTrigger className="w-full sm:w-32"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.keys(FORMATIONS).map((f) => (
                    <SelectItem key={f} value={f}>{f}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button onClick={generate} disabled={!readyToBuild || loading} className="w-full sm:w-auto gap-2 font-semibold">
              {loading ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
              Analyse selected XI
            </Button>
          </div>

          {mode === "dream" ? (
            <p className="text-xs text-muted-foreground">
              Dream Team mode auto-selects the highest-rated {formation} XI from every {season === "world-cup" ? "national team" : "club"} in {SEASON_LABELS[season]}.
            </p>
          ) : team ? (
            <p className="text-xs text-muted-foreground">
              {selectedCount > 0
                ? `${selectedCount} player${selectedCount === 1 ? "" : "s"} hand-picked. The XI fills any gaps with ${team.name}'s highest-rated players.`
                : `No players picked yet — Generate will pick ${team.name}'s best XI automatically. Tick players below to force them into the plan.`}
            </p>
          ) : null}
        </Card>

        {mode === "club" && team != null && careerSquad.length < 11 && (
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-4 text-xs text-amber-200 flex items-start gap-3 shadow-xs">
            <AlertCircle className="size-5 shrink-0 text-amber-400 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-amber-300 text-sm">
                Limited Active Players in Squad ({careerSquad.length} / 11 needed)
              </p>
              <p className="text-amber-200/90 leading-relaxed">
                This historical squad only provides {careerSquad.length} verified active footballers in 2026 ({excludedRetiredCount} retired footballers were excluded to comply with verified active eligibility rules). Strategy Builder cannot automatically construct a complete XI without at least 11 active players.
              </p>
            </div>
          </div>
        )}

        {!readyToBuild && (
          <Card className="grid place-items-center gap-2 p-12 text-center">
            <Swords className="size-8 text-muted-foreground" />
            <p className="text-sm font-medium">{season === "world-cup" ? "Select a national team to start building" : "Select a club to start building"}</p>
            <p className="text-xs text-muted-foreground">
              Or switch to Dream Team to start with a ready-made XI, then adjust it yourself.
            </p>
          </Card>
        )}

        {readyToBuild && (
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_1.1fr] items-start">
            {/* Left: squad picker (club) or dream team roster (stops stretching unnecessarily) */}
            {mode === "club" ? (
              <Card className="gap-0 p-0 self-start w-full lg:sticky lg:top-4 overflow-hidden shadow-sm">
                <div className="flex items-center justify-between border-b border-border p-4">
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className="grid size-7 shrink-0 place-items-center rounded-md font-mono text-[10px] font-bold text-black"
                      style={{ backgroundColor: teamColor(team!.short) }}
                    >
                      {team!.short}
                    </span>
                    <h3 className="truncate text-sm font-semibold">{team!.name} squad</h3>
                  </div>
                  <span className="shrink-0 font-mono text-[11px] text-muted-foreground">{careerSquad.length} active</span>
                </div>
                <div className="border-b border-border p-2.5">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      value={squadSearch}
                      onChange={(e) => setSquadSearch(e.target.value)}
                      placeholder="Search active squad..."
                      className="h-8 pl-8 text-xs"
                    />
                  </div>
                </div>
                <div className="max-h-[min(540px,70vh)] space-y-4 overflow-y-auto p-4 [scrollbar-width:thin]">
                  {(["GKP", "DEF", "MID", "FWD"] as Position[]).map((pos) => (
                    <div key={pos} className="space-y-1.5">
                      <p className="font-mono text-[11px] uppercase tracking-wide text-muted-foreground">{POS_LABEL[pos]}</p>
                      {byPos[pos].map((p) => (
                        <PlayerPick key={p.id} player={p} checked={selected.has(p.id)} onToggle={() => toggle(p.id)} />
                      ))}
                      {byPos[pos].length === 0 && <p className="text-xs text-muted-foreground">No active players found.</p>}
                    </div>
                  ))}
                </div>
              </Card>
            ) : (
              <Card className="gap-0 p-0 self-start w-full lg:sticky lg:top-4 overflow-hidden shadow-sm">
                <div className="flex items-center justify-between border-b border-border p-4">
                  <div className="flex items-center gap-2 min-w-0">
                    <Trophy className="size-4 shrink-0 text-[var(--color-accent)]" />
                    <h3 className="truncate text-sm font-semibold">{SEASON_LABELS[season]} Dream Team</h3>
                  </div>
                  <span className="shrink-0 font-mono text-[11px] text-muted-foreground">{formation}</span>
                </div>
                {hasLineup ? (
                  <div className="divide-y divide-border max-h-[min(540px,70vh)] overflow-y-auto [scrollbar-width:thin]">
                    {slots
                      .filter((s) => assignments[s.id])
                      .map((s) => {
                        const p = assignments[s.id] as CareerPlayer
                        const real = findRealPlayerByName(p.name, p.club, p.nationality)
                        return (
                          <div key={s.id} className="flex items-center gap-3 px-4 py-2.5">
                            <span className="w-9 font-mono text-[10px] uppercase text-muted-foreground">{s.label}</span>
                            <PlayerAvatar
                              name={p.name}
                              image={real?.image}
                              color={teamColor(p.team)}
                              size="list"
                            />
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-medium">{p.name}</p>
                              <p className="text-[11px] text-muted-foreground">
                                {p.club} · {p.pos} · <span title={`Potential rating: ${p.potential}`}>POT {p.potential}</span>
                              </p>
                            </div>
                            <span className="font-mono text-sm font-semibold tabular-nums" title={`Overall rating: ${p.rating}`}>{p.rating}</span>
                          </div>
                        )
                      })}
                  </div>
                ) : (
                  <div className="grid place-items-center gap-2 p-10 text-center">
                    <Trophy className="size-7 text-muted-foreground" />
                    <p className="text-sm font-medium">{season === "world-cup" ? "Best XI in the tournament" : "Best XI in the league"}</p>
                    <p className="text-xs text-muted-foreground">Click Generate Strategy to populate the lineup, make your adjustments, then click Evaluate Strategy.</p>
                  </div>
                )}
              </Card>
            )}

            {/* Right: pitch + tabbed panel */}
            <div className="min-w-0 space-y-4">
              {hasLineup ? (
                <>
                  {activeStrategy && (
                    <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-primary/30 bg-primary/10 px-3.5 py-2 text-xs">
                      <div className="flex items-center gap-2 min-w-0">
                        <Bookmark className="size-4 text-primary shrink-0" />
                        <span className="font-semibold text-foreground truncate">
                          Loaded Strategy: {activeStrategy.name}
                        </span>
                        {isDirty ? (
                          <Badge variant="outline" className="border-amber-500/40 text-amber-400 bg-amber-500/10 text-[10px]">
                            Unsaved Changes
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="border-emerald-500/40 text-emerald-400 bg-emerald-500/10 text-[10px]">
                            Saved
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {isDirty && (
                          <Button
                            size="sm"
                            variant="default"
                            onClick={quickUpdateCurrentStrategy}
                            disabled={savingInProgress}
                            className="h-7 text-xs gap-1 font-semibold"
                          >
                            {savingInProgress ? <Loader2 className="size-3 animate-spin" /> : <Save className="size-3" />}
                            Save Changes
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            promptIfDirty(() => {
                              setActiveStrategy(null)
                              setIsDirty(false)
                            })
                          }}
                          className="h-7 text-xs text-muted-foreground hover:text-foreground"
                        >
                          Unlink
                        </Button>
                      </div>
                    </div>
                  )}

                  <Card className="gap-3 p-4">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-semibold">{formation} · drag players to adjust</p>
                      {loading && (
                        <span className="flex items-center gap-1.5 text-[11px] text-primary">
                          <Loader2 className="size-3.5 animate-spin" /> AI is reviewing the change
                        </span>
                      )}
                    </div>
                    {retiredInLineup.length > 0 && (
                      <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                        <div className="flex items-start gap-2">
                          <AlertCircle className="size-4 text-destructive shrink-0 mt-0.5" />
                          <div className="text-xs">
                            <p className="font-semibold text-destructive">
                              Retired / Ineligible Selection Flagged ({retiredInLineup.length})
                            </p>
                            <p className="text-muted-foreground mt-0.5">
                              {retiredInLineup.map((r) => `${r.player.name} (${r.label})`).join(", ")} {retiredInLineup.length === 1 ? "is verified retired or ineligible" : "are verified retired or ineligible"} and cannot be used in a match strategy.
                            </p>
                          </div>
                        </div>
                        <Button
                          type="button"
                          size="sm"
                          variant="destructive"
                          onClick={autoReplaceRetired}
                          className="shrink-0 text-xs font-semibold"
                        >
                          Replace Ineligible Player{retiredInLineup.length === 1 ? "" : "s"}
                        </Button>
                      </div>
                    )}
                    <StrategyPitch
                      slots={slots}
                      assignments={assignments}
                      plan={plan}
                      onSwap={onSwap}
                      onMove={onMove}
                    />
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <p className="text-[11px] text-muted-foreground">Drag and swap freely. Analysis only runs when you click Evaluate Strategy.</p>
                      <div className="flex items-center gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setSaveModalOpen(true)}
                          disabled={savingInProgress}
                          className="gap-1.5 text-xs font-semibold"
                        >
                          <Bookmark className="size-3.5" />
                          {activeStrategy ? (isDirty ? "Save as..." : "Update Notes / Copy") : "Save Strategy"}
                        </Button>
                        <Button onClick={evaluateCurrentSetup} disabled={loading} size="sm" className="gap-2 font-semibold">
                          {loading ? <Loader2 className="size-3.5 animate-spin" /> : <BrainCircuit className="size-3.5" />}
                          Evaluate Strategy
                        </Button>
                      </div>
                    </div>
                    {benchWarning && (
                      <p className="text-[11px] text-muted-foreground">
                        Some slots were filled with squad players you didn&apos;t pick, to complete the XI.
                      </p>
                    )}
                    {pendingChange && (
                      <p className="flex items-center gap-1.5 text-[11px] text-primary">
                        <RotateCcw className="size-3" />
                        {pendingChange.player} moved to {pendingChange.to}
                        {pendingChange.swappedWith ? ` (swap with ${pendingChange.swappedWith})` : ""} — AI feedback will appear below.
                      </p>
                    )}
                  </Card>

                  <div className="grid gap-4 xl:grid-cols-[1.05fr_0.95fr]">
                    <Card className="gap-0 p-0">
                      <div className="flex items-center gap-2 border-b border-border px-5 py-4">
                        <BrainCircuit className="size-4 text-primary" />
                        <div>
                          <h3 className="text-sm font-semibold">AI game plan</h3>
                          <p className="text-[11px] text-muted-foreground">Evaluation of your selected and positioned XI</p>
                        </div>
                      </div>
                      <div className="p-5">
                        {isEvaluationOutdated && (
                          <div className="mb-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-300">
                            <div className="flex items-start sm:items-center gap-2">
                              <AlertTriangle className="size-4 shrink-0 text-amber-400 mt-0.5 sm:mt-0" />
                              <span>
                                Lineup modified since this snapshot was saved. Click &quot;Evaluate Strategy&quot; to refresh AI coaching feedback.
                              </span>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={evaluateCurrentSetup}
                              disabled={loading}
                              className="shrink-0 h-7 text-xs border-amber-500/40 hover:bg-amber-500/20 text-amber-200"
                            >
                              Re-evaluate
                            </Button>
                          </div>
                        )}
                        {loading && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Loader2 className="size-4 animate-spin" /> Evaluating your game plan…
                          </div>
                        )}
                        {!loading && verdict && (
                          <div className="mb-4 space-y-1.5 rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm leading-relaxed text-foreground/90">
                            <p className="font-mono text-[11px] uppercase tracking-wide text-primary">AI feedback</p>
                            {verdict.split("\n").filter(Boolean).map((line, i) => (
                              <AnalysisLine key={i} line={line} />
                            ))}
                          </div>
                        )}
                        {!loading && plan && <TacticalPlanView plan={plan} />}
                        {!loading && !plan && !verdict && (
                          <p className="text-sm text-muted-foreground">Generate your XI, make any adjustments, then click Evaluate Strategy for feedback.</p>
                        )}
                      </div>
                    </Card>

                    <Card className="gap-0 p-0">
                      <div className="flex items-center gap-2 border-b border-border px-5 py-4">
                        <BrainCircuit className="size-4 text-primary" />
                        <div>
                          <h3 className="text-sm font-semibold">Strategy assistant</h3>
                          <p className="text-[11px] text-muted-foreground">Discuss the submitted setup and tactical choices.</p>
                        </div>
                      </div>
                      <div className="p-5">
                        <StrategyChat messages={chatMessages} loading={false} disabled={!plan} onSend={handleChat} />
                      </div>
                    </Card>
                  </div>
                </>
              ) : (
                <Card className="grid place-items-center gap-2 p-12 text-center">
                  <Sparkles className="size-8 text-muted-foreground" />
                  <p className="text-sm font-medium">No lineup yet</p>
                  <p className="text-xs text-muted-foreground">
                    {mode === "dream" ? "Load the Dream Team, adjust it, then click Evaluate Strategy to analyse the XI." : "Pick your players, place them on the pitch, then click Evaluate Strategy to analyse the XI."}
                  </p>
                </Card>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modals & Dialogs */}
      <SaveStrategyDialog
        isOpen={saveModalOpen}
        onClose={() => setSaveModalOpen(false)}
        onSave={handleSaveNew}
        onUpdateExisting={activeStrategy ? handleUpdateExisting : undefined}
        isExistingStrategy={Boolean(activeStrategy)}
        currentName={activeStrategy?.name}
        currentNotes={activeStrategy?.notes ?? undefined}
        summary={{
          teamName: teamLabel,
          formation,
          playerCount: slots.filter((s) => assignments[s.id]).length,
        }}
      />

      <MyStrategiesModal
        isOpen={myStrategiesModalOpen}
        onClose={() => setMyStrategiesModalOpen(false)}
        strategies={savedStrategies}
        activeStrategyId={activeStrategy?.id ?? null}
        onLoadStrategy={loadSavedStrategy}
        onRenameStrategy={handleRenameStrategy}
        onDuplicateStrategy={handleDuplicateStrategy}
        onDeleteRequest={requestDeleteStrategy}
        isLoading={strategiesLoading}
      />

      <ConfirmDialog
        isOpen={confirmDialog.isOpen}
        onClose={() => setConfirmDialog((prev) => ({ ...prev, isOpen: false }))}
        onConfirm={confirmDialog.onConfirm}
        title={confirmDialog.title}
        description={confirmDialog.description}
        confirmText={confirmDialog.confirmText}
        cancelText={confirmDialog.cancelText}
        variant={confirmDialog.variant}
        isLoading={confirmDialog.isLoading}
      />
    </>
  )
}


const POS_LABEL: Record<Position, string> = {
  GKP: "Goalkeepers",
  DEF: "Defenders",
  MID: "Midfielders",
  FWD: "Forwards",
}

function ModeButton({
  active,
  onClick,
  icon: Icon,
  label,
}: {
  active: boolean
  onClick: () => void
  icon: React.ComponentType<{ className?: string }>
  label: string
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
        active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
      }`}
    >
      <Icon className="size-3.5" />
      {label}
    </button>
  )
}

function AnalysisLine({ line }: { line: string }) {
  const idx = line.indexOf(":")
  if (idx > 0 && idx < 16) {
    return (
      <p>
        <span className="font-semibold text-foreground">{line.slice(0, idx + 1)}</span>
        {line.slice(idx + 1)}
      </p>
    )
  }
  return <p>{line}</p>
}

function PlayerPick({
  player,
  checked,
  onToggle,
}: {
  player: CareerPlayer
  checked: boolean
  onToggle: () => void
}) {
  const real = findRealPlayerByName(player.name, player.club, player.nationality)
  const isRetired = isCareerPlayerRetired(player)

  return (
    <button
      type="button"
      onClick={isRetired ? undefined : onToggle}
      disabled={isRetired}
      className={`flex w-full items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition-colors ${
        isRetired
          ? "opacity-50 cursor-not-allowed bg-muted/20 border-border"
          : checked
          ? "border-primary/60 bg-primary/10"
          : "border-transparent bg-secondary/40 hover:bg-secondary"
      }`}
    >
      <span
        className={`grid size-4 shrink-0 place-items-center rounded border ${
          isRetired
            ? "border-muted-foreground/30 bg-muted"
            : checked
            ? "border-primary bg-primary text-primary-foreground"
            : "border-muted-foreground/40"
        }`}
      >
        {checked && !isRetired && <Check className="size-3" />}
      </span>
      <PlayerAvatar name={player.name} image={real?.image} size="list" color={teamColor(player.team)} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <p className="truncate text-sm font-medium">{player.name}</p>
          {isRetired && (
            <Badge variant="outline" className="border-destructive/30 bg-destructive/10 text-destructive text-[9px] font-mono px-1 py-0">
              Retired
            </Badge>
          )}
        </div>
        <p className="text-[11px] text-muted-foreground">
          {player.club} · {player.age}y · <span title={`Potential rating: ${player.potential}`}>POT {player.potential}</span>
        </p>
      </div>
      <span className="rounded bg-background px-1.5 py-0.5 font-mono text-[11px] font-semibold tabular-nums" title={`Overall rating: ${player.rating}`}>
        {player.rating}
      </span>
    </button>
  )
}

export default function StrategyPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-[75vh] items-center justify-center">
          <div className="text-sm text-muted-foreground flex items-center gap-2">
            <Loader2 className="size-5 animate-spin text-primary" />
            <span>Loading Strategy Builder...</span>
          </div>
        </div>
      }
    >
      <StrategyContent />
    </Suspense>
  )
}
