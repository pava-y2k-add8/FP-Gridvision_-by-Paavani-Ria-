import type { TacticalPlan } from "@/lib/tactics"

export const maxDuration = 30

type LineupPlayer = {
  name: string
  pos: string
  slot: string
  rating: number
  overall: number
  potential: number
  pace: number
  shooting: number
  passing: number
  dribbling: number
  defending: number
  physic: number
}

type Body = {
  mode: "generate" | "evaluate"
  team: string
  formation: string
  lineup: LineupPlayer[]
  change?: { player: string; from: string; to: string; swappedWith?: string }
}

function handleGenerate(body: Body) {
  const players = body.lineup
  const strongest = [...players].sort((a, b) => b.overall - a.overall)[0]
  const fastest = [...players].sort((a, b) => b.pace - a.pace)[0]
  const bestPasser = [...players].sort((a, b) => b.passing - a.passing)[0]
  const average = players.length ? Math.round(players.reduce((sum, p) => sum + p.overall, 0) / players.length) : 0
  const object: TacticalPlan = {
    shape: `${body.formation} should keep the team compact centrally, then use width and quick support around ${strongest?.name ?? "the strongest player"}.`,
    attackFocus: bestPasser && fastest && bestPasser.passing >= fastest.pace ? "central" : "balanced",
    press: average >= 82 ? "high" : "mid",
    tempo: average >= 85 ? "fast" : "balanced",
    strengths: [
      `${strongest?.name ?? "Your strongest player"} leads the XI with ${strongest?.overall ?? 0} OVR.`,
      `${bestPasser?.name ?? "Your best passer"} offers ${bestPasser?.passing ?? 0} passing to connect the lines.`,
      `${fastest?.name ?? "Your quickest player"} gives the shape ${fastest?.pace ?? 0} pace for transitions.`,
    ],
    watchOuts: ["Protect the space behind advanced players during turnovers.", "Keep midfield support close so the formation does not split."],
    keyPlayer: `${strongest?.name ?? "Your strongest player"} — highest overall rating in this XI.`,
    summary: `Build around ${strongest?.name ?? "your strongest player"} and keep the shape compact.`,
  }
  return Response.json({ plan: object })
}

function handleEvaluate(body: Body) {
  const c = body.change!
  const moved = body.lineup.find((p) => p.name === c.player)
  const isForwardMove = /FWD|LW|RW|ST|LST|RST/.test(c.to)
  const isDefensivePlayer = moved?.pos === "DEF" || moved?.pos === "GKP"
  const risky = isForwardMove && isDefensivePlayer
  const text = `Verdict: ${risky ? "Risky" : "Reasonable"}\nWhy: Moving ${c.player} from ${c.from} to ${c.to} ${risky ? "pulls a defensive profile away from its natural cover and may expose transitions" : "can improve spacing and create a useful connection in this shape"}. ${moved?.name ?? "The player"} has ${moved?.overall ?? 0} OVR and ${moved?.passing ?? 0} passing, so judge the move by whether the new role can receive support.\nFix: ${risky ? "Keep a midfielder behind the move or return the player to a defensive role." : "Keep nearby players close enough to cover the space left behind."}`
  return Response.json({ text })
}

export async function POST(req: Request) {
  const body = (await req.json()) as Body
  try {
    if (body.mode === "generate") return await handleGenerate(body)
    if (body.mode === "evaluate" && body.change) return await handleEvaluate(body)
    return Response.json({ error: "Invalid request." }, { status: 400 })
  } catch (err) {
    console.log("[v0] strategy generation error:", err instanceof Error ? err.message : err)
    return Response.json({ error: "Could not generate analysis. Please try again." }, { status: 500 })
  }
}
