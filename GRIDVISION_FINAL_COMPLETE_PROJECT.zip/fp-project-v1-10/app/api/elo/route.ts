import { NextResponse } from "next/server"

export const dynamic = "force-dynamic"

export async function GET() {
  try {
    const res = await fetch("http://127.0.0.1:8000/api/gridvision-elo/", {
      next: { revalidate: 30 },
      signal: AbortSignal.timeout(3000),
    })

    if (!res.ok) {
      return NextResponse.json(
        { status: "error", message: `Django returned HTTP ${res.status}` },
        { status: 502 }
      )
    }

    const data = await res.json()
    return NextResponse.json(data)
  } catch (error: any) {
    return NextResponse.json(
      {
        status: "fallback",
        message: "Django backend unreachable, using fallback ratings.",
        error: error?.message,
      },
      { status: 200 }
    )
  }
}
