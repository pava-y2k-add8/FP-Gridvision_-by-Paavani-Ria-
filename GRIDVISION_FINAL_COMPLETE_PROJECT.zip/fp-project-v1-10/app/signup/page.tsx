"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Hexagon, Mail, ArrowRight, RefreshCw, CheckCircle2, AlertCircle, Lock, User, Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { signUpAction, resendVerificationAction } from "@/app/actions/auth"

export default function SignUpPage() {
  const router = useRouter()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // "Check your email" screen state
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [submittedEmail, setSubmittedEmail] = useState("")
  const [devLink, setDevLink] = useState<string | null>(null)

  // Resend cooldown timer
  const [cooldown, setCooldown] = useState(0)
  const [resendLoading, setResendLoading] = useState(false)
  const [resendSuccess, setResendSuccess] = useState<string | null>(null)

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (cooldown > 0) {
      timer = setTimeout(() => setCooldown((c) => c - 1), 1000)
    }
    return () => clearTimeout(timer)
  }, [cooldown])

  async function handleSignUp(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    if (password !== confirmPassword) {
      setError("Passwords do not match.")
      return
    }

    setLoading(true)
    const formData = new FormData()
    formData.append("name", name)
    formData.append("email", email)
    formData.append("password", password)
    formData.append("confirmPassword", confirmPassword)

    try {
      const res = await signUpAction(formData)
      if (res.error) {
        setError(res.error)
      } else if (res.success && res.email) {
        setSubmittedEmail(res.email)
        setDevLink(res.devLink || null)
        setIsSubmitted(true)
        setCooldown(60) // 60s cooldown for resend
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  async function handleResend() {
    if (cooldown > 0 || resendLoading) return
    setResendLoading(true)
    setResendSuccess(null)
    setError(null)

    try {
      const res = await resendVerificationAction(submittedEmail)
      if (res.error) {
        setError(res.error)
        if (res.cooldownRemaining) {
          setCooldown(res.cooldownRemaining)
        }
      } else if (res.success) {
        setResendSuccess("A new verification email was accepted by the provider! (Check your inbox & spam folder; provider acceptance does not guarantee delivery)")
        if (res.devLink) setDevLink(res.devLink)
        setCooldown(60)
      }
    } catch {
      setError("Failed to resend email. Please try again.")
    } finally {
      setResendLoading(false)
    }
  }

  // --- SCREEN 2: "Check Your Email" SCREEN ---
  if (isSubmitted) {
    return (
      <div className="flex min-h-[85vh] items-center justify-center px-4 py-12">
        <Card className="w-full max-w-md border-border bg-card p-6 md:p-8 shadow-xl">
          <div className="flex flex-col items-center text-center">
            <div className="relative mb-5 grid size-16 place-items-center rounded-2xl bg-primary/10 text-primary ring-1 ring-primary/20">
              <Mail className="size-8 animate-pulse text-primary" />
            </div>

            <h1 className="text-2xl font-bold tracking-tight text-foreground">Verification Requested</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              A verification email request was accepted by the provider for:
            </p>
            <p className="mt-1 font-mono text-sm font-semibold text-primary break-all">
              {submittedEmail}
            </p>
            <p className="mt-1 text-[11px] text-muted-foreground italic">
              Note: Provider acceptance confirms the email was dispatched, but does not guarantee final inbox delivery. Please check your spam or junk folder.
            </p>

            <div className="my-6 w-full rounded-lg border border-border bg-secondary/30 p-4 text-left text-xs text-muted-foreground space-y-2">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="size-4 shrink-0 text-primary mt-0.5" />
                <span>Click the link in the email to activate your account.</span>
              </div>
              <div className="flex items-start gap-2">
                <Lock className="size-4 shrink-0 text-primary mt-0.5" />
                <span>Protected features (like AI Strategy Builder & tactical pitch) require verification.</span>
              </div>
              <div className="flex items-start gap-2">
                <AlertCircle className="size-4 shrink-0 text-muted-foreground mt-0.5" />
                <span>The link will expire in 1 hour.</span>
              </div>
            </div>

            {/* Development Mode Quick-Verify Banner */}
            {devLink && (
              <div className="mb-6 w-full rounded-lg border border-yellow-500/30 bg-yellow-500/10 p-3.5 text-left">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-yellow-500">
                  <span className="inline-block size-2 rounded-full bg-yellow-400 animate-ping mr-1" />
                  Development Mode: Instant Verification Link
                </div>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  No email server needed! Click below to simulate clicking the email link:
                </p>
                <div className="mt-2.5">
                  <Link
                    href={devLink}
                    className="inline-flex items-center gap-1.5 rounded-md bg-yellow-500 px-3 py-1.5 text-xs font-semibold text-black transition-colors hover:bg-yellow-400"
                  >
                    Click to Verify Email Now <ArrowRight className="size-3.5" />
                  </Link>
                </div>
              </div>
            )}

            {resendSuccess && (
              <div className="mb-4 flex w-full items-center gap-2 rounded-md border border-green-500/30 bg-green-500/10 p-3 text-xs text-green-400">
                <CheckCircle2 className="size-4 shrink-0" />
                <span>{resendSuccess}</span>
              </div>
            )}

            {error && (
              <div className="mb-4 flex w-full items-center gap-2 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">
                <AlertCircle className="size-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Resend Option with Cooldown */}
            <div className="flex flex-col items-center gap-3 w-full">
              <p className="text-xs text-muted-foreground">Didn’t receive the email? Check spam or resend.</p>
              <Button
                type="button"
                variant="outline"
                className="w-full gap-2 border-border"
                onClick={handleResend}
                disabled={cooldown > 0 || resendLoading}
              >
                <RefreshCw className={`size-3.5 ${resendLoading ? "animate-spin" : ""}`} />
                {cooldown > 0 ? `Resend email in ${cooldown}s` : "Resend verification email"}
              </Button>
            </div>

            <div className="mt-6 border-t border-border pt-4 w-full">
              <button
                type="button"
                onClick={() => setIsSubmitted(false)}
                className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                ← Back to edit email address
              </button>
            </div>
          </div>
        </Card>
      </div>
    )
  }

  // --- SCREEN 1: SIGNUP FORM ---
  return (
    <div className="flex min-h-[85vh] items-center justify-center px-4 py-12">
      <Card className="w-full max-w-md border-border bg-card p-6 md:p-8 shadow-xl">
        <div className="flex flex-col items-center text-center">
          <div className="grid size-12 place-items-center rounded-xl bg-primary text-primary-foreground mb-4">
            <Hexagon className="size-7" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Create your account</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Sign up for GridVision to unlock strategy building and community predictions.
          </p>
        </div>

        {error && (
          <div className="mt-5 flex items-center gap-2 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive">
            <AlertCircle className="size-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSignUp} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground" htmlFor="name">
              Full Name
            </label>
            <div className="relative">
              <User className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
              <Input
                id="name"
                type="text"
                required
                placeholder="Alex Morgan"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="pl-9 bg-background"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground" htmlFor="email">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                required
                placeholder="alex@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-9 bg-background"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground" htmlFor="password">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                required
                placeholder="At least 6 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-9 pr-9 bg-background"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground" htmlFor="confirmPassword">
              Confirm Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
              <Input
                id="confirmPassword"
                type={showPassword ? "text" : "password"}
                required
                placeholder="Repeat your password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="pl-9 bg-background"
              />
            </div>
          </div>

          <Button type="submit" disabled={loading} className="w-full mt-2 font-semibold">
            {loading ? "Creating account..." : "Sign Up"}
          </Button>
        </form>

        <div className="mt-6 border-t border-border pt-4 text-center">
          <p className="text-xs text-muted-foreground">
            Already have an account?{" "}
            <Link href="/login" className="font-semibold text-primary hover:underline">
              Log in
            </Link>
          </p>
        </div>
      </Card>
    </div>
  )
}
