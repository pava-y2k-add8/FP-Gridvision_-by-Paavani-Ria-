"use server"

import { headers } from "next/headers"
import { hashPassword, verifyPassword, generateVerificationToken } from "@/lib/auth-crypto"
import {
  findUserByEmail,
  createUser,
  updateUserPassword,
  setUserEmailVerified,
  createVerificationToken,
  findVerificationToken,
  deleteVerificationToken,
  getRecentTokenForEmail,
} from "@/lib/db/auth-store"
import { sendVerificationEmail } from "@/lib/email-service"
import { setAuthSession, clearAuthSession, getAuthSession } from "@/lib/auth-session"

async function getBaseUrl(): Promise<string> {
  if (process.env.NEXT_PUBLIC_APP_URL) {
    return process.env.NEXT_PUBLIC_APP_URL.replace(/\/$/, "")
  }
  const headersList = await headers()
  const host = headersList.get("host") || "localhost:3000"
  const proto = headersList.get("x-forwarded-proto") || (host.includes("localhost") ? "http" : "https")
  return `${proto}://${host}`
}

export type AuthResponse = {
  success?: boolean
  error?: string
  message?: string
  email?: string
  unverified?: boolean
  expired?: boolean
  invalid?: boolean
  cooldownRemaining?: number
  devLink?: string
  providerAccepted?: boolean
  isConfigured?: boolean
  user?: {
    name: string
    email: string
    emailVerified: boolean
  }
}

export async function signUpAction(formData: FormData): Promise<AuthResponse> {
  const name = (formData.get("name") as string)?.trim()
  const email = (formData.get("email") as string)?.trim().toLowerCase()
  const password = formData.get("password") as string
  const confirmPassword = formData.get("confirmPassword") as string

  if (!name || name.length < 2) {
    return { error: "Please enter your full name (at least 2 characters)." }
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { error: "Please enter a valid email address." }
  }
  if (!password || password.length < 6) {
    return { error: "Password must be at least 6 characters long." }
  }
  if (password !== confirmPassword) {
    return { error: "Passwords do not match." }
  }

  const existingUser = await findUserByEmail(email)
  if (existingUser && existingUser.emailVerified) {
    return { error: "An account with this email already exists and is verified. Please log in." }
  }

  const { hash, salt } = hashPassword(password)
  let user = existingUser

  if (user) {
    // Update existing unverified account password
    user = await updateUserPassword(email, hash, salt)
  } else {
    // Create new unverified account
    user = await createUser({
      name,
      email,
      passwordHash: hash,
      salt,
    })
  }

  // Generate 1-hour verification token
  const token = generateVerificationToken()
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000)
  await createVerificationToken(email, token, expiresAt)

  const baseUrl = await getBaseUrl()
  const verificationUrl = `${baseUrl}/verify-email?token=${token}`

  const emailResult = await sendVerificationEmail({
    to: email,
    name,
    verificationUrl,
  })

  if (!emailResult.providerAccepted) {
    return {
      success: false,
      email,
      providerAccepted: false,
      isConfigured: emailResult.isConfigured,
      devLink: emailResult.devLink,
      error: emailResult.error || "Failed to dispatch verification email.",
      message: emailResult.error,
    }
  }

  return {
    success: true,
    email,
    providerAccepted: true,
    isConfigured: true,
    message: "A verification email request was accepted by the email provider. Please check your inbox and spam folder. (Note: Provider acceptance does not guarantee final inbox delivery).",
  }
}

export async function verifyEmailAction(token: string): Promise<AuthResponse> {
  if (!token || token.trim() === "") {
    return { error: "Missing or invalid verification token.", invalid: true }
  }

  const record = await findVerificationToken(token.trim())
  if (!record) {
    return {
      error: "This verification link is invalid or has already been used.",
      invalid: true,
    }
  }

  const now = new Date()
  const expiresAt = new Date(record.expiresAt)

  if (now > expiresAt) {
    return {
      error: "This verification link has expired. Verification links are valid for 1 hour.",
      expired: true,
      email: record.email,
    }
  }

  // Valid token: mark email verified
  const updatedUser = await setUserEmailVerified(record.email)
  await deleteVerificationToken(token.trim())

  if (updatedUser) {
    // Create active authenticated session
    await setAuthSession({
      id: updatedUser.id,
      email: updatedUser.email,
      name: updatedUser.name,
      emailVerified: true,
    })

    return {
      success: true,
      user: {
        name: updatedUser.name,
        email: updatedUser.email,
        emailVerified: true,
      },
      message: "Your email address has been verified successfully!",
    }
  }

  return { error: "Failed to update user verification status. Please try again." }
}

export async function resendVerificationAction(email: string): Promise<AuthResponse> {
  const normalized = email?.toLowerCase().trim()
  if (!normalized) {
    return { error: "Email address is required." }
  }

  const user = await findUserByEmail(normalized)
  if (!user) {
    return { error: "No account found with this email address." }
  }
  if (user.emailVerified) {
    return { error: "Your email is already verified. You can log in directly." }
  }

  // Rate-limiting cooldown check (60s)
  const recentToken = await getRecentTokenForEmail(normalized)
  if (recentToken) {
    const elapsedSeconds = Math.floor((Date.now() - new Date(recentToken.createdAt).getTime()) / 1000)
    if (elapsedSeconds < 60) {
      const wait = 60 - elapsedSeconds
      return {
        error: `Please wait ${wait} second${wait === 1 ? "" : "s"} before requesting another email.`,
        cooldownRemaining: wait,
      }
    }
  }

  const token = generateVerificationToken()
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000)
  await createVerificationToken(normalized, token, expiresAt)

  const baseUrl = await getBaseUrl()
  const verificationUrl = `${baseUrl}/verify-email?token=${token}`

  const emailResult = await sendVerificationEmail({
    to: user.email,
    name: user.name,
    verificationUrl,
  })

  if (!emailResult.providerAccepted) {
    return {
      success: false,
      providerAccepted: false,
      isConfigured: emailResult.isConfigured,
      devLink: emailResult.devLink,
      error: emailResult.error || "Failed to dispatch verification email.",
      message: emailResult.error,
    }
  }

  return {
    success: true,
    email: user.email,
    providerAccepted: true,
    isConfigured: true,
    message: "A new verification email was accepted by the provider. Please check your inbox and spam folder. (Note: Provider acceptance does not guarantee final inbox delivery).",
  }
}

export async function loginAction(formData: FormData): Promise<AuthResponse> {
  const email = (formData.get("email") as string)?.trim().toLowerCase()
  const password = formData.get("password") as string

  if (!email || !password) {
    return { error: "Please enter both email and password." }
  }

  const user = await findUserByEmail(email)
  if (!user || !verifyPassword(password, user.passwordHash, user.salt)) {
    return { error: "Invalid email or password." }
  }

  // BLOCK ACCESS TO PROTECTED FEATURES IF UNVERIFIED
  if (!user.emailVerified) {
    return {
      error: "Please verify your email address to log in and access protected features.",
      unverified: true,
      email: user.email,
    }
  }

  await setAuthSession({
    id: user.id,
    email: user.email,
    name: user.name,
    emailVerified: user.emailVerified,
  })

  return {
    success: true,
    user: {
      name: user.name,
      email: user.email,
      emailVerified: true,
    },
  }
}

export async function logoutAction(): Promise<{ success: boolean }> {
  await clearAuthSession()
  return { success: true }
}

export async function getCurrentUserAction(): Promise<{
  name: string
  email: string
  emailVerified: boolean
} | null> {
  const session = await getAuthSession()
  if (!session) return null
  return {
    name: session.name,
    email: session.email,
    emailVerified: session.emailVerified,
  }
}
