"use server"

import { getAuthSession } from "@/lib/auth-session"
import {
  getUserStrategies,
  getStrategyById,
  createStrategy,
  updateStrategy,
  duplicateStrategy,
  deleteStrategy,
  type SavedStrategyRecord,
  type SavedSlotSetup,
} from "@/lib/db/strategy-store"

export type { SavedStrategyRecord, SavedSlotSetup }

export async function getSavedStrategiesAction(): Promise<{
  success: boolean
  strategies?: SavedStrategyRecord[]
  error?: string
}> {
  try {
    const session = await getAuthSession()
    if (!session || !session.userId) {
      return { success: false, error: "Please sign in to access your saved strategies." }
    }

    const strategies = await getUserStrategies(session.userId)
    return { success: true, strategies }
  } catch (err) {
    console.error("Error in getSavedStrategiesAction:", err)
    return {
      success: false,
      error: err instanceof Error ? err.message : "Failed to load saved strategies.",
    }
  }
}

export async function getSavedStrategyByIdAction(id: string): Promise<{
  success: boolean
  strategy?: SavedStrategyRecord
  error?: string
}> {
  try {
    const session = await getAuthSession()
    if (!session || !session.userId) {
      return { success: false, error: "Please sign in to view this strategy." }
    }

    const strategy = await getStrategyById(id, session.userId)
    if (!strategy) {
      return { success: false, error: "Strategy not found or access denied." }
    }

    return { success: true, strategy }
  } catch (err) {
    console.error("Error in getSavedStrategyByIdAction:", err)
    return {
      success: false,
      error: err instanceof Error ? err.message : "Failed to fetch strategy.",
    }
  }
}

export async function saveStrategyAction(payload: {
  name: string
  notes?: string
  mode: "club" | "dream"
  season: string
  teamId?: number | null
  teamName: string
  formation: string
  slots: SavedSlotSetup[]
  tacticalPlan?: any | null
  verdict?: string | null
}): Promise<{
  success: boolean
  strategy?: SavedStrategyRecord
  error?: string
}> {
  try {
    const session = await getAuthSession()
    if (!session || !session.userId) {
      return { success: false, error: "Please sign in to save your strategy." }
    }

    if (!payload.name || !payload.name.trim()) {
      return { success: false, error: "Please provide a name for your strategy." }
    }

    if (!payload.slots || payload.slots.length === 0) {
      return { success: false, error: "Cannot save an empty lineup." }
    }

    const created = await createStrategy({
      userId: session.userId,
      name: payload.name.trim(),
      notes: payload.notes?.trim() || null,
      mode: payload.mode,
      season: payload.season,
      teamId: payload.teamId,
      teamName: payload.teamName,
      formation: payload.formation,
      slots: payload.slots,
      tacticalPlan: payload.tacticalPlan || null,
      verdict: payload.verdict || null,
    })

    return { success: true, strategy: created }
  } catch (err) {
    console.error("Error in saveStrategyAction:", err)
    return {
      success: false,
      error: err instanceof Error ? err.message : "Failed to save strategy.",
    }
  }
}

export async function updateStrategyAction(
  id: string,
  payload: {
    name?: string
    notes?: string
    mode?: "club" | "dream"
    season?: string
    teamId?: number | null
    teamName?: string
    formation?: string
    slots?: SavedSlotSetup[]
    tacticalPlan?: any | null
    verdict?: string | null
  }
): Promise<{
  success: boolean
  strategy?: SavedStrategyRecord
  error?: string
}> {
  try {
    const session = await getAuthSession()
    if (!session || !session.userId) {
      return { success: false, error: "Please sign in to update this strategy." }
    }

    if (payload.name !== undefined && !payload.name.trim()) {
      return { success: false, error: "Strategy name cannot be empty." }
    }

    const updated = await updateStrategy(id, session.userId, payload)
    return { success: true, strategy: updated }
  } catch (err) {
    console.error("Error in updateStrategyAction:", err)
    return {
      success: false,
      error: err instanceof Error ? err.message : "Failed to update strategy.",
    }
  }
}

export async function duplicateStrategyAction(id: string): Promise<{
  success: boolean
  strategy?: SavedStrategyRecord
  error?: string
}> {
  try {
    const session = await getAuthSession()
    if (!session || !session.userId) {
      return { success: false, error: "Please sign in to duplicate this strategy." }
    }

    const duplicated = await duplicateStrategy(id, session.userId)
    return { success: true, strategy: duplicated }
  } catch (err) {
    console.error("Error in duplicateStrategyAction:", err)
    return {
      success: false,
      error: err instanceof Error ? err.message : "Failed to duplicate strategy.",
    }
  }
}

export async function deleteStrategyAction(id: string): Promise<{
  success: boolean
  error?: string
}> {
  try {
    const session = await getAuthSession()
    if (!session || !session.userId) {
      return { success: false, error: "Please sign in to delete this strategy." }
    }

    await deleteStrategy(id, session.userId)
    return { success: true }
  } catch (err) {
    console.error("Error in deleteStrategyAction:", err)
    return {
      success: false,
      error: err instanceof Error ? err.message : "Failed to delete strategy.",
    }
  }
}
