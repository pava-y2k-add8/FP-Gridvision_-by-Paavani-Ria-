"use server"

import { getAuthSession } from "@/lib/auth-session"
import {
  getAllFixtures,
  getUserEvents,
  createEvent,
  updateEvent,
  deleteEvent,
  getLatestSyncLog,
  FixtureRecord,
  CalendarEventRecord,
  SyncLogRecord,
} from "@/lib/db/calendar-store"
import { syncFixtures, ensureSeedFixtures } from "@/lib/calendar/fixture-sync"
import { findUserById } from "@/lib/db/auth-store"
import fs from "fs"
import path from "path"

export interface CalendarFeedResponse {
  fixtures: FixtureRecord[]
  events: CalendarEventRecord[]
  currentUser: {
    userId: number
    name: string
    email: string
  } | null
  latestSync: SyncLogRecord | null
}

export async function getCalendarFeedAction(filters?: {
  competition?: string
  team?: string
  status?: string
}): Promise<CalendarFeedResponse> {
  await ensureSeedFixtures()
  const session = await getAuthSession()
  const userId = session ? session.userId : null

  const [fixtures, events, latestSync] = await Promise.all([
    getAllFixtures(filters),
    getUserEvents(userId),
    getLatestSyncLog(filters?.competition !== "all" ? filters?.competition : undefined),
  ])

  return {
    fixtures,
    events,
    currentUser: session
      ? { userId: session.userId, name: session.name, email: session.email }
      : null,
    latestSync,
  }
}

export async function createPersonalEventAction(payload: {
  title: string
  description?: string
  eventType: "match_note" | "scouting" | "watch_party" | "training" | "personal"
  startDate: string
  endDate?: string
  allDay?: boolean
  linkedFixtureId?: string
  competition?: string
  teamId?: number
  visibility?: "private" | "shared"
  shares?: { userId: number; permission: "view" | "edit" }[]
}): Promise<{ success: boolean; event?: CalendarEventRecord; error?: string }> {
  const session = await getAuthSession()
  if (!session) {
    return { success: false, error: "You must be signed in to create personal events or notes." }
  }

  if (!payload.title || !payload.title.trim()) {
    return { success: false, error: "Event title is required." }
  }

  try {
    const created = await createEvent(
      session.userId,
      {
        title: payload.title.trim(),
        description: payload.description?.trim() || null,
        eventType: payload.eventType || "personal",
        startDate: payload.startDate,
        endDate: payload.endDate || null,
        allDay: Boolean(payload.allDay),
        linkedFixtureId: payload.linkedFixtureId || null,
        competition: payload.competition || null,
        teamId: payload.teamId || null,
        visibility: payload.visibility || "private",
      },
      payload.shares,
    )

    return { success: true, event: created }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return { success: false, error: msg }
  }
}

export async function updatePersonalEventAction(
  eventId: string,
  payload: {
    title?: string
    description?: string
    eventType?: "match_note" | "scouting" | "watch_party" | "training" | "personal"
    startDate?: string
    endDate?: string
    allDay?: boolean
    linkedFixtureId?: string
    competition?: string
    teamId?: number
    visibility?: "private" | "shared"
    shares?: { userId: number; permission: "view" | "edit" }[]
  },
): Promise<{ success: boolean; event?: CalendarEventRecord; error?: string }> {
  const session = await getAuthSession()
  if (!session) {
    return { success: false, error: "You must be signed in to edit events or notes." }
  }

  try {
    const updated = await updateEvent(
      session.userId,
      eventId,
      {
        ...(payload.title !== undefined ? { title: payload.title.trim() } : {}),
        ...(payload.description !== undefined ? { description: payload.description?.trim() || null } : {}),
        ...(payload.eventType !== undefined ? { eventType: payload.eventType } : {}),
        ...(payload.startDate !== undefined ? { startDate: payload.startDate } : {}),
        ...(payload.endDate !== undefined ? { endDate: payload.endDate || null } : {}),
        ...(payload.allDay !== undefined ? { allDay: Boolean(payload.allDay) } : {}),
        ...(payload.linkedFixtureId !== undefined ? { linkedFixtureId: payload.linkedFixtureId || null } : {}),
        ...(payload.competition !== undefined ? { competition: payload.competition || null } : {}),
        ...(payload.teamId !== undefined ? { teamId: payload.teamId || null } : {}),
        ...(payload.visibility !== undefined ? { visibility: payload.visibility } : {}),
      },
      payload.shares,
    )

    if (!updated) {
      return { success: false, error: "Event not found or unauthorized." }
    }

    return { success: true, event: updated }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return { success: false, error: msg }
  }
}

export async function deletePersonalEventAction(
  eventId: string,
): Promise<{ success: boolean; error?: string }> {
  const session = await getAuthSession()
  if (!session) {
    return { success: false, error: "You must be signed in to delete events or notes." }
  }

  try {
    const deleted = await deleteEvent(session.userId, eventId)
    if (!deleted) {
      return { success: false, error: "Event not found or you do not have permission to delete it." }
    }
    return { success: true }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return { success: false, error: msg }
  }
}

export async function syncFixturesAction(
  competition = "all",
): Promise<{ success: boolean; message: string }> {
  try {
    const res = await syncFixtures(competition)
    return { success: res.success, message: res.message }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return { success: false, message: `Fixture sync error: ${msg}` }
  }
}

export async function getShareableUsersAction(): Promise<
  { id: number; name: string; email: string }[]
> {
  const session = await getAuthSession()
  if (!session) return []

  try {
    const storePath = path.join(process.cwd(), ".data", "auth-store.json")
    if (fs.existsSync(storePath)) {
      const data = JSON.parse(fs.readFileSync(storePath, "utf-8"))
      const users = (data.users || []) as { id: number; name: string; email: string }[]
      return users
        .filter((u) => u.id !== session.userId)
        .map((u) => ({ id: u.id, name: u.name, email: u.email }))
    }
  } catch {
    // fallback
  }
  return []
}
