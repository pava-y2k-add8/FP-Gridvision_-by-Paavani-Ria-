import Link from "next/link"
import { notFound } from "next/navigation"
import {
  ArrowLeft,
  Ruler,
  Footprints,
  Flag,
  Calendar,
  MapPin,
  Shirt,
  Target,
  Handshake,
  Activity,
  Square,
  CheckCircle2,
  Info,
} from "lucide-react"
import { PageHeader } from "@/components/page-header"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  getPlayerById,
  initials,
  careerSpan,
  POSITION_LABELS,
  POSITION_COLORS,
} from "@/lib/players"
import { PlayerAvatar } from "@/components/player-avatar"

export default async function PlayerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const player = getPlayerById(Number(id))
  if (!player) notFound()

  const color = POSITION_COLORS[player.position]
  const goalsPer = player.apps > 0 ? (player.goals / player.apps).toFixed(2) : "—"
  const contributions = player.goals + player.assists

  return (
    <>
      <PageHeader
        eyebrow="Player Explorer"
        title={player.name}
        description={`${player.detailedPosition || player.position}${player.club && !player.retired ? ` · ${player.club}` : player.retired ? " · Retired" : ""}`}
        actions={
          <Link
            href="/players"
            className="flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="size-3.5" /> All players
          </Link>
        }
      />

      <div className="space-y-6 px-4 py-5 sm:px-6 sm:py-6 md:px-8">
        {/* Identity + market value */}
        <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <Card className="gap-5 p-5 sm:p-6">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6">
              <PlayerAvatar name={player.name} image={player.image} color={color} size="profile" />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">{player.name}</h2>
                  <Badge variant="secondary" className="font-mono text-xs" style={{ color }}>
                    {player.position}
                  </Badge>
                  {player.retired ? (
                    <Badge variant="outline" className="font-mono text-xs text-muted-foreground border-border">
                      Retired ({player.retirementYear || player.lastYear || "Verified"})
                    </Badge>
                  ) : player.careerStatus === "uncertain" ? (
                    <Badge variant="outline" className="font-mono text-xs text-amber-500 border-amber-500/30">
                      Unattached / Free Agent
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="font-mono text-xs text-emerald-500 border-emerald-500/30">
                      Active
                    </Badge>
                  )}
                </div>
                <p className="mt-1 text-sm font-medium text-muted-foreground">
                  {player.detailedPosition || POSITION_LABELS[player.position]}
                </p>
                {player.club && (
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {player.retired ? `Retired (${player.retirementYear || player.lastYear})` : player.club}
                  </p>
                )}
                {player.statusFlag && (
                  <div className="mt-2 inline-flex items-center gap-1.5 rounded-md border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[11px] text-amber-600 dark:text-amber-400">
                    <Info className="size-3.5 shrink-0" />
                    <span>{player.statusFlag}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <IdentityItem icon={Flag} label="Nationality" value={player.nationalities.join(", ") || "—"} />
              <IdentityItem icon={Calendar} label="Age" value={player.age ? `${player.age}y` : "—"} />
              <IdentityItem icon={Ruler} label="Height" value={player.heightCm ? `${player.heightCm} cm` : "—"} />
              <IdentityItem icon={Footprints} label="Foot" value={player.foot || "—"} />
              <IdentityItem icon={Calendar} label="Born" value={player.dob || "—"} />
              <IdentityItem icon={MapPin} label="Birthplace" value={player.birthPlace || "—"} />
              <IdentityItem icon={Shirt} label="Club" value={player.retired ? "Retired" : player.club || "—"} />
              <IdentityItem icon={Calendar} label="Career span" value={careerSpan(player)} />
            </div>

            {player.statusSource && (
              <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-3 text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1.5 font-medium text-foreground">
                  <CheckCircle2 className="size-3.5 text-primary" />
                  <span>Verified status as of {player.verificationDate || "15 October 2026"}</span>
                </span>
                <span className="truncate max-w-[280px] sm:max-w-md text-[10px]" title={player.statusSource}>
                  Source: {player.statusSource}
                </span>
              </div>
            )}
          </Card>

          <Card className="gap-4 p-4 sm:p-5 flex flex-col justify-between">
            <div className="rounded-lg border border-border bg-secondary/40 p-4 text-center">
              <p className="font-mono text-[11px] uppercase tracking-wide text-muted-foreground">Total Goal Contributions</p>
              <p className="mt-1 font-mono text-2xl sm:text-3xl lg:text-4xl font-bold tabular-nums text-primary break-all sm:break-normal">
                {contributions.toLocaleString()}
              </p>
              <p className="mt-1 text-[11px] text-muted-foreground">
                {player.goals.toLocaleString()} goals · {player.assists.toLocaleString()} assists
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2 border-t border-border pt-4">
              <MiniStat label="Goals/app" value={goalsPer} />
              <MiniStat label="Appearances" value={player.apps.toLocaleString()} />
              <MiniStat label="Discipline" value={`${player.yellowCards}Y · ${player.redCards}R`} />
            </div>
            {player.dod ? (
              <p className="border-t border-border pt-3 text-[11px] text-muted-foreground">Deceased · {player.dod}</p>
            ) : null}
          </Card>
        </div>

        {/* Career performance */}
        <Card className="gap-4 p-4 sm:p-5">
          <h3 className="text-sm font-semibold">Career performance</h3>
          <p className="text-[11px] text-muted-foreground">
            Aggregated across all recorded club competitions{player.firstYear ? ` (${careerSpan(player)})` : ""}.
          </p>
          <div className="grid grid-cols-2 gap-3 sm:gap-4 sm:grid-cols-3 lg:grid-cols-5">
            <BigStat icon={Activity} label="Appearances" value={player.apps} />
            <BigStat icon={Target} label="Goals" value={player.goals} tone={color} />
            <BigStat icon={Handshake} label="Assists" value={player.assists} />
            <BigStat icon={Square} label="Yellow cards" value={player.yellowCards} tone="#eab308" />
            <BigStat icon={Square} label="Red cards" value={player.redCards} tone="#ef4444" />
          </div>
        </Card>

        {/* Competitions */}
        {player.competitions.length > 0 ? (
          <Card className="gap-3 p-4 sm:p-5">
            <h3 className="text-sm font-semibold">Competitions played</h3>
            <div className="flex flex-wrap gap-1.5">
              {player.competitions.map((c) => (
                <Badge key={c} variant="secondary" className="text-xs">
                  {c}
                </Badge>
              ))}
            </div>
          </Card>
        ) : null}
      </div>
    </>
  )
}

function IdentityItem({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
}) {
  return (
    <div className="flex items-start gap-2">
      <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <p className="text-[11px] text-muted-foreground">{label}</p>
        <p className="truncate text-sm font-medium capitalize" title={value}>{value}</p>
      </div>
    </div>
  )
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="text-center">
      <p className="font-mono text-base sm:text-lg font-semibold tabular-nums">{value}</p>
      <p className="text-[11px] text-muted-foreground">{label}</p>
    </div>
  )
}

function BigStat({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: number
  tone?: string
}) {
  return (
    <div className="flex flex-col gap-1 rounded-lg border border-border p-3 sm:p-4">
      <Icon className="size-4 text-muted-foreground" />
      <span className="font-mono text-xl sm:text-2xl font-bold tabular-nums" style={tone ? { color: tone } : undefined}>
        {value.toLocaleString()}
      </span>
      <span className="text-[11px] text-muted-foreground">{label}</span>
    </div>
  )
}
