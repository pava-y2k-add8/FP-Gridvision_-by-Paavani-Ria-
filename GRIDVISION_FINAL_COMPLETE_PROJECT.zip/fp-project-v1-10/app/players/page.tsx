"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { Search, ArrowUpDown, Users, ChevronRight, HelpCircle } from "lucide-react"
import { PageHeader } from "@/components/page-header"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { cn } from "@/lib/utils"
import {
  PLAYERS,
  POSITION_GROUPS,
  POSITION_COLORS,
  getClubs,
  initials,
  careerSpan,
  type RealPlayer,
  type PositionGroup,
} from "@/lib/players"
import { PlayerAvatar } from "@/components/player-avatar"

type SortKey = "goals" | "assists" | "apps" | "age"
type StatusFilter = "ALL" | "ACTIVE" | "RETIRED" | "UNCERTAIN"

const SORTS: { key: SortKey; label: string }[] = [
  { key: "goals", label: "Career goals" },
  { key: "assists", label: "Career assists" },
  { key: "apps", label: "Appearances" },
  { key: "age", label: "Age" },
]

const PAGE_SIZE = 100

export default function PlayersPage() {
  const [query, setQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("ALL")
  const [pos, setPos] = useState<PositionGroup | "ALL">("ALL")
  const [club, setClub] = useState<string>("ALL")
  const [sort, setSort] = useState<SortKey>("goals")
  const [limit, setLimit] = useState(PAGE_SIZE)

  const clubs = useMemo(() => getClubs(), [])

  // Verified career status counts (never inferred from age or statistics cutoff)
  const statusCounts = useMemo(() => {
    let active = 0
    let retired = 0
    let uncertain = 0
    for (const p of PLAYERS) {
      if (p.careerStatus === "uncertain") {
        uncertain++
      } else if (p.retired || p.careerStatus === "retired") {
        retired++
      } else {
        active++
      }
    }
    return { all: PLAYERS.length, active, retired, uncertain }
  }, [])

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase()
    return PLAYERS.filter((p) => {
      // Verified career status filtering
      if (statusFilter === "ACTIVE") return !p.retired && p.careerStatus !== "uncertain"
      if (statusFilter === "RETIRED") return p.retired || p.careerStatus === "retired"
      if (statusFilter === "UNCERTAIN") return p.careerStatus === "uncertain"
      return true
    })
      .filter((p) => (pos === "ALL" ? true : p.position === pos))
      .filter((p) => (club === "ALL" ? true : p.club === club))
      .filter((p) =>
        q ? p.name.toLowerCase().includes(q) || p.club.toLowerCase().includes(q) || p.nationality.toLowerCase().includes(q) : true,
      )
      .sort((a, b) => {
        const av = (a[sort] as number) ?? 0
        const bv = (b[sort] as number) ?? 0
        return bv - av
      })
  }, [statusFilter, pos, club, query, sort])

  const visible = rows.slice(0, limit)

  return (
    <>
      <PageHeader
        eyebrow="Player Explorer"
        title="Players"
        description="Verified career statistics — career goals, assists, and appearances for the game's most notable players. Filter by club, position, and verified career status as of 15 October 2026, sort by performance, then open a name for the full profile."
        actions={
          <Badge variant="secondary" className="font-mono text-xs">
            {rows.length.toLocaleString()} matches
          </Badge>
        }
      />

      <div className="space-y-4 px-4 py-5 sm:px-6 sm:py-6 md:px-8">
        <Card className="p-3.5 sm:p-4 shadow-sm space-y-3">
          {/* Status Tabs: All / Active / Retired / Uncertain */}
          <div className="flex flex-wrap items-center gap-1.5 border-b border-border/60 pb-3">
            <span className="text-xs font-medium text-muted-foreground mr-1">Status:</span>
            <StatusTab
              active={statusFilter === "ALL"}
              onClick={() => {
                setStatusFilter("ALL")
                setLimit(PAGE_SIZE)
              }}
              label="All"
              count={statusCounts.all}
            />
            <StatusTab
              active={statusFilter === "ACTIVE"}
              onClick={() => {
                setStatusFilter("ACTIVE")
                setLimit(PAGE_SIZE)
              }}
              label="Active"
              count={statusCounts.active}
            />
            <StatusTab
              active={statusFilter === "RETIRED"}
              onClick={() => {
                setStatusFilter("RETIRED")
                setLimit(PAGE_SIZE)
              }}
              label="Retired"
              count={statusCounts.retired}
            />
            <StatusTab
              active={statusFilter === "UNCERTAIN"}
              onClick={() => {
                setStatusFilter("UNCERTAIN")
                setLimit(PAGE_SIZE)
              }}
              label="Uncertain / Unattached"
              count={statusCounts.uncertain}
              tone="warning"
            />
          </div>

          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-4 items-center">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value)
                  setLimit(PAGE_SIZE)
                }}
                placeholder="Search player, club or nation…"
                className="pl-9 w-full"
              />
            </div>
            <Select
              value={pos}
              onValueChange={(v) => {
                setPos(v as PositionGroup | "ALL")
                setLimit(PAGE_SIZE)
              }}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Position" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All positions</SelectItem>
                {POSITION_GROUPS.map((p) => (
                  <SelectItem key={p} value={p}>
                    {p}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={club}
              onValueChange={(v) => {
                setClub(v || "ALL")
                setLimit(PAGE_SIZE)
              }}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Club" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All clubs</SelectItem>
                {clubs.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
              <SelectTrigger className="w-full">
                <ArrowUpDown className="size-4" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SORTS.map((s) => (
                  <SelectItem key={s.key} value={s.key}>
                    {s.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </Card>

        <Card className="gap-0 overflow-hidden p-0 shadow-sm">
          <div className="hidden grid-cols-[2.4fr_1fr_repeat(3,0.8fr)_2rem] gap-2 border-b border-border px-4 py-2.5 font-mono text-[11px] uppercase tracking-wide text-muted-foreground md:grid">
            <span>Player</span>
            <span>Club / Status</span>
            <ColHead label="Gls" title="Career goals" active={sort === "goals"} />
            <ColHead label="Ast" title="Career assists" active={sort === "assists"} />
            <ColHead label="Apps" title="Career appearances" active={sort === "apps"} />
            <span />
          </div>
          <div className="divide-y divide-border">
            {visible.map((p) => (
              <PlayerRow key={p.id} player={p} sort={sort} />
            ))}
            {rows.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-16 text-muted-foreground">
                <Users className="size-6" />
                <p className="text-sm">No players match those filters.</p>
              </div>
            ) : null}
          </div>
          {visible.length < rows.length ? (
            <div className="flex justify-center border-t border-border p-3">
              <button
                onClick={() => setLimit((l) => l + PAGE_SIZE)}
                className="rounded-md border border-border px-4 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Show more ({(rows.length - visible.length).toLocaleString()} remaining)
              </button>
            </div>
          ) : null}
        </Card>
      </div>
    </>
  )
}

function StatusTab({
  active,
  onClick,
  label,
  count,
  tone,
}: {
  active: boolean
  onClick: () => void
  label: string
  count: number
  tone?: "warning"
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
        active
          ? "bg-primary text-primary-foreground shadow-sm"
          : tone === "warning"
          ? "text-amber-500 hover:bg-amber-500/10"
          : "text-muted-foreground hover:bg-secondary hover:text-foreground"
      )}
    >
      <span>{label}</span>
      <span
        className={cn(
          "rounded-full px-1.5 py-0.2 text-[10px] font-mono",
          active
            ? "bg-primary-foreground/20 text-primary-foreground"
            : tone === "warning"
            ? "bg-amber-500/15 text-amber-500"
            : "bg-secondary text-muted-foreground"
        )}
      >
        {count.toLocaleString()}
      </span>
    </button>
  )
}

function ColHead({ label, title, active }: { label: string; title?: string; active: boolean }) {
  return (
    <span className={cn("text-right", active && "text-primary")} title={title}>
      {label}
    </span>
  )
}

function PlayerRow({ player, sort }: { player: RealPlayer; sort: SortKey }) {
  const color = POSITION_COLORS[player.position]
  const isUncertain = player.careerStatus === "uncertain"

  return (
    <Link
      href={`/players/${player.id}`}
      className="flex flex-col gap-2 p-3 transition-colors hover:bg-secondary/60 sm:p-3.5 md:grid md:grid-cols-[2.4fr_1fr_repeat(3,0.8fr)_2rem] md:items-center md:gap-2 md:px-4 md:py-2.5"
    >
      <div className="flex items-center gap-3 min-w-0">
        <PlayerAvatar name={player.name} image={player.image} color={color} size="list" />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="truncate text-sm font-medium">{player.name}</p>
            {isUncertain && (
              <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-600 dark:text-amber-400 text-[10px] font-mono px-1.5 py-0">
                Uncertain
              </Badge>
            )}
          </div>
          <p className="text-[11px] text-muted-foreground truncate">
            <span style={{ color }}>{player.position}</span> · {player.nationality || "—"} · {careerSpan(player)}
          </p>
        </div>
      </div>
      <div className="hidden min-w-0 md:block">
        {player.retired ? (
          <span className="truncate text-xs text-muted-foreground">
            Retired ({player.retirementYear || player.lastYear || "Verified"})
          </span>
        ) : isUncertain ? (
          <span className="truncate text-xs text-amber-600 dark:text-amber-400 font-medium">
            Unattached / Uncertain
          </span>
        ) : (
          <span className="truncate text-xs text-muted-foreground">
            {player.club || "—"}
          </span>
        )}
      </div>
      {/* Mobile stats summary */}
      <div className="flex items-center justify-between border-t border-border/40 pt-2 text-xs md:hidden">
        <span className="text-[11px] text-muted-foreground truncate max-w-[45%]">
          {player.retired
            ? `Retired (${player.retirementYear || player.lastYear || ""})`.trim()
            : isUncertain
            ? "Unattached / Uncertain"
            : player.club || "—"}
        </span>
        <div className="flex items-center gap-3 font-mono text-xs">
          <span className={cn(sort === "goals" ? "text-primary font-semibold" : "text-muted-foreground")}>
            <span className="text-[10px] text-muted-foreground mr-0.5">G</span>{player.goals}
          </span>
          <span className={cn(sort === "assists" ? "text-primary font-semibold" : "text-muted-foreground")}>
            <span className="text-[10px] text-muted-foreground mr-0.5">A</span>{player.assists}
          </span>
          <span className={cn(sort === "apps" ? "text-primary font-semibold" : "text-muted-foreground")}>
            <span className="text-[10px] text-muted-foreground mr-0.5">Apps</span>{player.apps}
          </span>
        </div>
      </div>
      {/* Desktop columns */}
      <div className="hidden md:contents">
        <Cell active={sort === "goals"}>{player.goals.toLocaleString()}</Cell>
        <Cell active={sort === "assists"}>{player.assists.toLocaleString()}</Cell>
        <Cell active={sort === "apps"}>{player.apps.toLocaleString()}</Cell>
        <span className="flex items-center justify-end">
          <ChevronRight className="size-4 text-muted-foreground" />
        </span>
      </div>
    </Link>
  )
}

function Cell({ children, active, strong }: { children: React.ReactNode; active?: boolean; strong?: boolean }) {
  return (
    <span
      className={cn(
        "text-right font-mono text-sm tabular-nums",
        strong && "font-semibold",
        active ? "text-primary" : "text-foreground",
      )}
    >
      {children}
    </span>
  )
}
