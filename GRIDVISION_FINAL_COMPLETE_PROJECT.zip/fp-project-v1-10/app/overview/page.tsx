"use client"

import { useMemo, useState } from "react"
import { Trophy, Gauge, Shield, Globe, Sparkles, ChevronRight } from "lucide-react"
import { PageHeader } from "@/components/page-header"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Scatter,
  ScatterChart,
  XAxis,
  YAxis,
  ZAxis,
  Cell,
} from "recharts"
import { useSeason } from "@/components/season-context"
import {
  SEASON_LABELS,
  applyLiveEloRatings,
  teamAggregates,
  teamAttack,
  teamColor,
  teamDefense,
  type Team,
} from "@/lib/data"
import { ClubStylePanel } from "@/components/club-style-panel"
import { useEffect } from "react"

export default function OverviewPage() {
  const { season } = useSeason()
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null)
  const [liveEloLoaded, setLiveEloLoaded] = useState(false)

  useEffect(() => {
    fetch("/api/elo")
      .then((res) => res.json())
      .then((data) => {
        if (data?.teams) {
          applyLiveEloRatings(data.teams)
          setLiveEloLoaded(true)
        }
      })
      .catch((err) => console.warn("Live Elo sync fallback:", err))
  }, [])

  const aggregates = useMemo(() => teamAggregates(season), [season, liveEloLoaded])

  const isNational = season === "world-cup"

  const eloData = useMemo(
    () => aggregates.map((a) => ({ name: a.team.short, elo: a.team.elo, fill: teamColor(a.team.short) })),
    [aggregates],
  )

  const scatterData = useMemo(
    () =>
      aggregates.map((a) => ({
        name: a.team.short,
        attack: teamAttack(a.team),
        defense: teamDefense(a.team),
        elo: a.team.elo,
        fill: teamColor(a.team.short),
      })),
    [aggregates],
  )

  const leader = aggregates[0]

  return (
    <>
      <PageHeader
        eyebrow={`${SEASON_LABELS[season]}`}
        title={isNational ? "National Teams & Tournaments" : "Clubs & Leagues"}
        description={
          isNational
            ? "National teams ranked by Elo rating, with tournament attack and defensive strength. Click any nation to inspect what tactical style suits their squad."
            : "Clubs ranked by Elo rating, with attack and defensive strength drawn from the FIFA player ratings. Click any club to inspect what tactical style suits their squad."
        }
        actions={
          <Badge variant="secondary" className="font-mono text-xs">
            {aggregates.length} {isNational ? "national teams" : "clubs"}
          </Badge>
        }
      />

      <div className="space-y-6 px-4 py-5 sm:px-6 sm:py-6 md:px-8">
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="gap-3 p-4 sm:p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trophy className="size-4 text-primary" />
                <h3 className="text-sm font-semibold">Elo ratings</h3>
              </div>
              {liveEloLoaded && (
                <Badge variant="outline" className="text-[10px] font-mono text-emerald-400 border-emerald-500/30 bg-emerald-950/40">
                  Django Live Synced
                </Badge>
              )}
            </div>
            <ChartContainer
              config={{ elo: { label: "Elo", color: "var(--color-primary)" } }}
              className="h-[280px] sm:h-[340px] md:h-[360px] w-full"
            >
              <BarChart data={eloData} layout="vertical" margin={{ left: 8, right: 16 }}>
                <CartesianGrid horizontal={false} strokeDasharray="3 3" />
                <XAxis type="number" domain={["dataMin - 40", "dataMax + 20"]} tickLine={false} axisLine={false} fontSize={11} />
                <YAxis type="category" dataKey="name" width={44} tickLine={false} axisLine={false} fontSize={11} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="elo" radius={4}>
                  {eloData.map((d) => <Cell key={d.name} fill={d.fill} />)}
                </Bar>
              </BarChart>
            </ChartContainer>
          </Card>

          <Card className="gap-3 p-4 sm:p-5">
            <div className="flex items-center gap-2">
              <Gauge className="size-4 text-[var(--color-accent)]" />
              <h3 className="text-sm font-semibold">Attack vs defense strength</h3>
            </div>
            <ChartContainer
              config={{
                attack: { label: "Attack", color: "var(--color-accent)" },
                defense: { label: "Defense", color: "var(--color-chart-3)" },
              }}
              className="h-[280px] sm:h-[340px] md:h-[360px] w-full"
            >
              <ScatterChart margin={{ left: 8, right: 16, top: 8, bottom: 8 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" dataKey="attack" name="Attack" tickLine={false} axisLine={false} fontSize={11} label={{ value: "Attack", position: "insideBottom", offset: -2, fontSize: 11 }} />
                <YAxis type="number" dataKey="defense" name="Defense" tickLine={false} axisLine={false} fontSize={11} label={{ value: "Defense", angle: -90, position: "insideLeft", fontSize: 11 }} />
                <ZAxis type="number" dataKey="elo" range={[60, 400]} />
                <ChartTooltip cursor={{ strokeDasharray: "3 3" }} content={<ChartTooltipContent />} />
                <Scatter data={scatterData}>
                  {scatterData.map((d) => <Cell key={d.name} fill={d.fill} />)}
                </Scatter>
              </ScatterChart>
            </ChartContainer>
          </Card>
        </div>

        <Card className="gap-0 overflow-hidden p-0 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-border p-4 gap-2">
            <div className="flex items-center gap-2">
              <Shield className="size-4 text-primary" />
              <h3 className="text-sm font-semibold">
                {isNational ? "Tournament Table by Elo" : "League Table by Elo"}
              </h3>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="outline" className="text-[11px] font-mono gap-1 text-muted-foreground border-border/80">
                <Sparkles className="size-3 text-primary" />
                <span>Click any row for &quot;What style suits this squad?&quot;</span>
              </Badge>
              {leader ? (
                <span className="font-mono text-xs text-muted-foreground hidden md:inline">
                  Top: {leader.team.name}
                </span>
              ) : null}
            </div>
          </div>
          <div className="grid grid-cols-[1.75rem_1fr_auto] sm:grid-cols-[2rem_1.8fr_repeat(4,minmax(0,1fr))_auto] md:grid-cols-[2.5rem_2fr_repeat(4,1fr)_auto] gap-2 border-b border-border px-3 sm:px-4 py-2.5 font-mono text-[11px] uppercase tracking-wide text-muted-foreground">
            <span>#</span>
            <span>{isNational ? "Nation" : "Club"}</span>
            <span className="text-right">Elo</span>
            <span className="hidden text-right sm:block">Attack</span>
            <span className="hidden text-right sm:block">Defense</span>
            <span className="hidden text-right sm:block" title="Average Overall rating">Avg OVR</span>
            <span className="hidden sm:block text-right">Style</span>
          </div>
          <div className="divide-y divide-border">
            {aggregates.map((a, i) => (
              <div
                key={a.team.id}
                role="button"
                tabIndex={0}
                onClick={() => setSelectedTeam(a.team)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault()
                    setSelectedTeam(a.team)
                  }
                }}
                className="group grid grid-cols-[1.75rem_1fr_auto] sm:grid-cols-[2rem_1.8fr_repeat(4,minmax(0,1fr))_auto] md:grid-cols-[2.5rem_2fr_repeat(4,1fr)_auto] items-center gap-2 px-3 sm:px-4 py-2.5 cursor-pointer hover:bg-secondary/60 focus:bg-secondary/60 focus:outline-none transition-colors"
                aria-label={`Inspect tactical style for ${a.team.name}`}
              >
                <span className="font-mono text-xs sm:text-sm text-muted-foreground">{i + 1}</span>
                <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                  <span
                    className="grid size-7 sm:size-8 shrink-0 place-items-center rounded-md font-mono text-[10px] sm:text-[11px] font-bold text-black shadow-2xs"
                    style={{ backgroundColor: teamColor(a.team.short) }}
                  >
                    {a.team.short}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-xs sm:text-sm font-medium group-hover:text-primary transition-colors">
                      {a.team.name}
                    </p>
                    {a.topPlayer ? (
                      <p className="text-[10px] text-muted-foreground sm:hidden truncate">★ {a.topPlayer.name}</p>
                    ) : null}
                  </div>
                </div>
                <div className="text-right font-mono text-xs sm:text-sm tabular-nums">
                  <span className="font-semibold">{a.team.elo}</span>
                  {a.team.eloChange !== undefined && a.team.eloChange !== 0 && (
                    <span className={`hidden sm:inline-block ml-1 text-[10px] font-bold ${a.team.eloChange > 0 ? "text-emerald-500" : "text-rose-500"}`}>
                      {a.team.eloChange > 0 ? `+${a.team.eloChange}` : a.team.eloChange}
                    </span>
                  )}
                </div>
                <span className="hidden text-right font-mono text-sm tabular-nums sm:block">{teamAttack(a.team)}</span>
                <span className="hidden text-right font-mono text-sm tabular-nums sm:block">{teamDefense(a.team)}</span>
                <span className="hidden text-right font-mono text-sm tabular-nums sm:block">{a.avgOverall}</span>
                <div className="hidden sm:flex items-center justify-end">
                  <span className="inline-flex items-center gap-1 font-mono text-[11px] text-primary/80 group-hover:text-primary transition-colors">
                    <span className="hidden md:inline">Inspect</span>
                    <ChevronRight className="size-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Expandable Squad Tactical Style Panel */}
      <ClubStylePanel
        team={selectedTeam}
        season={season}
        onClose={() => setSelectedTeam(null)}
      />
    </>
  )
}
