"use client"

import { useEffect, useState, Suspense } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"
import { CheckCircle2, AlertTriangle, XCircle, ArrowRight, RefreshCw, Mail, Hexagon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { verifyEmailAction, resendVerificationAction } from "@/app/actions/auth"

function VerifyEmailContent() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const token = searchParams.get("token")

  const [state, setState] = useState<"loading" | "success" | "expired" | "invalid" | "idle">(
    token ? "loading" : "idle",
  )
  const [message, setMessage] = useState<string>("")
  const [userEmail, setUserEmail] = useState<string>("")

  // Resend state
  const [resendEmail, setResendEmail] = useState<string>("")
  const [cooldown, setCooldown] = useState(0)
  const [resendLoading, setResendLoading] = useState(false)
  const [resendMsg, setResendMsg] = useState<string | null>(null)
  const [resendDevLink, setResendDevLink] = useState<string | null>(null)

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (cooldown > 0) {
      timer = setTimeout(() => setCooldown((c) => c - 1), 1000)
    }
    return () => clearTimeout(timer)
  }, [cooldown])

  useEffect(() => {
    if (!token) return

    let isMounted = true
    async function verify() {
      try {
        const res = await verifyEmailAction(token!)
        if (!isMounted) return

        if (res.success) {
          setState("success")
          setMessage(res.message || "Your email has been verified!")
          setUserEmail(res.user?.email || "")
          // Auto redirect after 3 seconds
          setTimeout(() => {
            router.push("/strategy")
          }, 3500)
        } else if (res.expired) {
          setState("expired")
          setMessage(res.error || "This verification link has expired.")
          if (res.email) {
            setUserEmail(res.email)
            setResendEmail(res.email)
          }
        } else {
          setState("invalid")
          setMessage(res.error || "This verification link is invalid or has already been used.")
        }
      } catch {
        if (isMounted) {
          setState("invalid")
          setMessage("Failed to verify email. Please try again.")
        }
      }
    }

    verify()
    return () => {
      isMounted = false
    }
  }, [token, router])

  async function handleResend(e?: React.FormEvent) {
    if (e) e.preventDefault()
    const targetEmail = resendEmail || userEmail
    if (!targetEmail || cooldown > 0 || resendLoading) return

    setResendLoading(true)
    setResendMsg(null)

    try {
      const res = await resendVerificationAction(targetEmail)
      if (res.error) {
        setResendMsg(res.error)
        if (res.cooldownRemaining) {
          setCooldown(res.cooldownRemaining)
        }
      } else if (res.success) {
        setResendMsg(res.message || "A new verification email was accepted by the provider! (Check your inbox & spam folder; provider acceptance does not guarantee delivery)")
        if (res.devLink) setResendDevLink(res.devLink)
        setCooldown(60)
      }
    } catch {
      setResendMsg("Failed to resend. Please try again.")
    } finally {
      setResendLoading(false)
    }
  }

  return (
    <div className="flex min-h-[85vh] items-center justify-center px-4 py-12">
      <Card className="w-full max-w-md border-border bg-card p-6 md:p-8 shadow-xl text-center">
        {/* 1. LOADING STATE */}
        {state === "loading" && (
          <div className="flex flex-col items-center py-6">
            <div className="relative mb-5 grid size-16 place-items-center rounded-2xl bg-primary/10 text-primary">
              <RefreshCw className="size-8 animate-spin text-primary" />
            </div>
            <h1 className="text-xl font-bold text-foreground">Verifying your email...</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Please wait while we confirm your verification link with GridVision.
            </p>
          </div>
        )}

        {/* 2. SUCCESS STATE */}
        {state === "success" && (
          <div className="flex flex-col items-center py-4">
            <div className="relative mb-5 grid size-16 place-items-center rounded-2xl bg-emerald-500/10 text-emerald-500 ring-1 ring-emerald-500/20">
              <CheckCircle2 className="size-8 text-emerald-500" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Email Verified!</h1>
            <p className="mt-2 text-sm text-muted-foreground">{message}</p>
            {userEmail && (
              <p className="mt-1 font-mono text-xs text-primary font-medium">{userEmail}</p>
            )}

            <div className="my-5 w-full rounded-lg border border-border bg-secondary/30 p-4 text-xs text-muted-foreground text-left space-y-1.5">
              <p className="font-semibold text-foreground flex items-center gap-1.5">
                <Hexagon className="size-3.5 text-primary" /> Unlocked Features:
              </p>
              <p>✓ Full access to AI Strategy Builder & Tactical Analysis</p>
              <p>✓ Matchup Elo Simulation & Tactical Breakdown</p>
            </div>

            <p className="text-xs text-muted-foreground mb-4">
              Redirecting you to the Strategy Builder in a few seconds...
            </p>

            <Link href="/strategy" className="w-full">
              <Button className="w-full gap-2 font-semibold">
                Open Strategy Builder <ArrowRight className="size-4" />
              </Button>
            </Link>
          </div>
        )}

        {/* 3. EXPIRED STATE */}
        {state === "expired" && (
          <div className="flex flex-col items-center py-4">
            <div className="relative mb-5 grid size-16 place-items-center rounded-2xl bg-amber-500/10 text-amber-500 ring-1 ring-amber-500/20">
              <AlertTriangle className="size-8 text-amber-500" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Link Expired</h1>
            <p className="mt-2 text-sm text-muted-foreground">{message}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Verification links expire after 1 hour for your account security.
            </p>

            <div className="my-6 w-full border-t border-border pt-4">
              <p className="text-xs font-medium text-foreground mb-3">Request a fresh verification link:</p>
              <div className="space-y-3">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  value={resendEmail || userEmail}
                  onChange={(e) => setResendEmail(e.target.value)}
                  className="bg-background text-sm"
                />
                <Button
                  onClick={() => handleResend()}
                  disabled={cooldown > 0 || resendLoading}
                  className="w-full gap-2 font-semibold"
                >
                  <RefreshCw className={`size-3.5 ${resendLoading ? "animate-spin" : ""}`} />
                  {cooldown > 0 ? `Resend in ${cooldown}s` : "Send New Verification Link"}
                </Button>
              </div>

              {resendMsg && (
                <p className="mt-3 text-xs text-primary font-medium">{resendMsg}</p>
              )}

              {resendDevLink && (
                <div className="mt-3 rounded border border-yellow-500/30 bg-yellow-500/10 p-2 text-left">
                  <p className="text-[11px] font-semibold text-yellow-500">Dev Link:</p>
                  <Link href={resendDevLink} className="text-[11px] text-primary hover:underline break-all">
                    {resendDevLink}
                  </Link>
                </div>
              )}
            </div>

            <Link href="/login" className="text-xs text-muted-foreground hover:text-foreground">
              ← Return to Login
            </Link>
          </div>
        )}

        {/* 4. INVALID STATE */}
        {state === "invalid" && (
          <div className="flex flex-col items-center py-4">
            <div className="relative mb-5 grid size-16 place-items-center rounded-2xl bg-destructive/10 text-destructive ring-1 ring-destructive/20">
              <XCircle className="size-8 text-destructive" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Invalid Link</h1>
            <p className="mt-2 text-sm text-muted-foreground">{message}</p>

            <div className="my-6 w-full border-t border-border pt-4 space-y-3">
              <p className="text-xs text-muted-foreground">
                If you already verified your account, you can sign in directly.
              </p>
              <div className="flex flex-col gap-2">
                <Link href="/login" className="w-full">
                  <Button className="w-full font-semibold">Sign In to Your Account</Button>
                </Link>
                <Link href="/signup" className="w-full">
                  <Button variant="outline" className="w-full border-border">
                    Create New Account
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* 5. IDLE / MANUAL RESEND FORM */}
        {state === "idle" && (
          <div className="flex flex-col items-center py-4">
            <div className="relative mb-5 grid size-16 place-items-center rounded-2xl bg-primary/10 text-primary">
              <Mail className="size-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Verify Your Email</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Enter your email address to receive a new verification link.
            </p>

            <form onSubmit={handleResend} className="my-6 w-full space-y-3">
              <Input
                type="email"
                required
                placeholder="alex@example.com"
                value={resendEmail}
                onChange={(e) => setResendEmail(e.target.value)}
                className="bg-background"
              />
              <Button
                type="submit"
                disabled={cooldown > 0 || resendLoading}
                className="w-full gap-2 font-semibold"
              >
                <RefreshCw className={`size-3.5 ${resendLoading ? "animate-spin" : ""}`} />
                {cooldown > 0 ? `Resend in ${cooldown}s` : "Send Verification Link"}
              </Button>
            </form>

            {resendMsg && (
              <p className="mb-4 text-xs text-primary font-medium">{resendMsg}</p>
            )}

            {resendDevLink && (
              <div className="mb-4 rounded border border-yellow-500/30 bg-yellow-500/10 p-2.5 text-left w-full">
                <p className="text-[11px] font-semibold text-yellow-500">Dev Link:</p>
                <Link href={resendDevLink} className="text-[11px] text-primary hover:underline break-all">
                  {resendDevLink}
                </Link>
              </div>
            )}

            <Link href="/login" className="text-xs text-muted-foreground hover:text-foreground">
              ← Return to Login
            </Link>
          </div>
        )}
      </Card>
    </div>
  )
}

export default function VerifyEmailPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-[85vh] items-center justify-center">
          <div className="text-sm text-muted-foreground flex items-center gap-2">
            <RefreshCw className="size-4 animate-spin text-primary" /> Loading verification...
          </div>
        </div>
      }
    >
      <VerifyEmailContent />
    </Suspense>
  )
}
