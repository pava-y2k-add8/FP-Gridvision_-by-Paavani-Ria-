"use client"

import { useState, useEffect, Suspense } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { Hexagon, Lock, Mail, Eye, EyeOff, AlertCircle, RefreshCw, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { loginAction, resendVerificationAction } from "@/app/actions/auth"

function LoginContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const callbackUrl = searchParams.get("callbackUrl") || "/"

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isUnverified, setIsUnverified] = useState(false)

  // Resend state
  const [cooldown, setCooldown] = useState(0)
  const [resendLoading, setResendLoading] = useState(false)
  const [resendMsg, setResendMsg] = useState<string | null>(null)
  const [devLink, setDevLink] = useState<string | null>(null)

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (cooldown > 0) {
      timer = setTimeout(() => setCooldown((c) => c - 1), 1000)
    }
    return () => clearTimeout(timer)
  }, [cooldown])

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setIsUnverified(false)
    setResendMsg(null)
    setLoading(true)

    const formData = new FormData()
    formData.append("email", email)
    formData.append("password", password)

    try {
      const res = await loginAction(formData)
      if (res.error) {
        setError(res.error)
        if (res.unverified) {
          setIsUnverified(true)
        }
      } else if (res.success) {
        router.push(callbackUrl)
        router.refresh()
      }
    } catch {
      setError("An unexpected error occurred during login. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  async function handleResend() {
    if (!email || cooldown > 0 || resendLoading) return
    setResendLoading(true)
    setResendMsg(null)

    try {
      const res = await resendVerificationAction(email)
      if (res.error) {
        setResendMsg(res.error)
        if (res.cooldownRemaining) {
          setCooldown(res.cooldownRemaining)
        }
      } else if (res.success) {
        setResendMsg(res.message || "A new verification email was accepted by the provider! (Check your inbox & spam folder; provider acceptance does not guarantee delivery)")
        if (res.devLink) setDevLink(res.devLink)
        setCooldown(60)
      }
    } catch {
      setResendMsg("Failed to resend email. Please try again.")
    } finally {
      setResendLoading(false)
    }
  }

  return (
    <div className="flex min-h-[85vh] items-center justify-center px-4 py-12">
      <Card className="w-full max-w-md border-border bg-card p-6 md:p-8 shadow-xl">
        <div className="flex flex-col items-center text-center">
          <div className="grid size-12 place-items-center rounded-xl bg-primary text-primary-foreground mb-4">
            <Hexagon className="size-7" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Welcome back</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Sign in to GridVision to access strategy and analytics.
          </p>
        </div>

        {error && (
          <div className="mt-5 flex items-start gap-2.5 rounded-lg border border-destructive/40 bg-destructive/10 p-3.5 text-xs text-destructive">
            <AlertCircle className="size-4 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-medium">{error}</span>
              {isUnverified && (
                <p className="text-[11px] text-muted-foreground">
                  Verification ensures only legitimate accounts can access protected tactical tools.
                </p>
              )}
            </div>
          </div>
        )}

        {isUnverified && (
          <div className="mt-4 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3.5 text-xs">
            <p className="font-semibold text-amber-500 mb-2">Need a new verification link?</p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleResend}
              disabled={cooldown > 0 || resendLoading}
              className="w-full gap-2 border-amber-500/30 hover:bg-amber-500/20 text-foreground"
            >
              <RefreshCw className={`size-3.5 ${resendLoading ? "animate-spin" : ""}`} />
              {cooldown > 0 ? `Resend in ${cooldown}s` : "Resend Verification Link"}
            </Button>

            {resendMsg && (
              <p className="mt-2 text-[11px] text-primary font-medium">{resendMsg}</p>
            )}

            {devLink && (
              <div className="mt-2.5 rounded bg-background p-2 border border-border">
                <p className="text-[10px] text-muted-foreground">Dev Mode Quick Link:</p>
                <Link href={devLink} className="text-[11px] text-primary hover:underline break-all">
                  {devLink}
                </Link>
              </div>
            )}
          </div>
        )}

        <form onSubmit={handleLogin} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground" htmlFor="login-email">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
              <Input
                id="login-email"
                type="email"
                required
                placeholder="alex@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-9 bg-background"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-muted-foreground" htmlFor="login-password">
                Password
              </label>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
              <Input
                id="login-password"
                type={showPassword ? "text" : "password"}
                required
                placeholder="Your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-9 pr-9 bg-background"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
          </div>

          <Button type="submit" disabled={loading} className="w-full mt-2 font-semibold">
            {loading ? "Signing in..." : "Sign In"}
          </Button>
        </form>

        <div className="mt-6 border-t border-border pt-4 text-center">
          <p className="text-xs text-muted-foreground">
            Don’t have an account yet?{" "}
            <Link href="/signup" className="font-semibold text-primary hover:underline">
              Create an account
            </Link>
          </p>
        </div>
      </Card>
    </div>
  )
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-[85vh] items-center justify-center">
          <div className="text-sm text-muted-foreground flex items-center gap-2">
            <RefreshCw className="size-4 animate-spin text-primary" /> Loading login...
          </div>
        </div>
      }
    >
      <LoginContent />
    </Suspense>
  )
}
