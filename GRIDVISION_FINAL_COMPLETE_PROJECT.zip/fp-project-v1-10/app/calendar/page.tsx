"use client"

import React, { useState, useEffect } from "react"
import useSWR, { mutate } from "swr"
import { CalendarHeader, CalendarViewMode } from "@/components/calendar/calendar-header"
import { CalendarFilters, CalendarFilterState } from "@/components/calendar/calendar-filters"
import { MonthView } from "@/components/calendar/month-view"
import { WeekView } from "@/components/calendar/week-view"
import { UpcomingView } from "@/components/calendar/upcoming-view"
import { EventDialog } from "@/components/calendar/event-dialog"
import { FixtureDetailModal } from "@/components/calendar/fixture-detail-modal"
import {
  getCalendarFeedAction,
  createPersonalEventAction,
  updatePersonalEventAction,
  deletePersonalEventAction,
  syncFixturesAction,
  getShareableUsersAction,
  CalendarFeedResponse,
} from "@/app/actions/calendar"
import { FixtureRecord, CalendarEventRecord } from "@/lib/db/calendar-store"
import { getAllTeams } from "@/lib/data"
import { CheckCircle2, AlertCircle, X } from "lucide-react"

export default function CalendarPage() {
  const [viewMode, setViewMode] = useState<CalendarViewMode>("month")
  const [currentDate, setCurrentDate] = useState<Date>(new Date())
  const [filters, setFilters] = useState<CalendarFilterState>({
    competition: "all",
    team: "",
    type: "all",
    status: "all",
  })

  const [selectedFixture, setSelectedFixture] = useState<FixtureRecord | null>(null)
  const [selectedEvent, setSelectedEvent] = useState<CalendarEventRecord | null>(null)
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false)
  const [newEventDate, setNewEventDate] = useState<Date | null>(null)
  const [newEventFixture, setNewEventFixture] = useState<FixtureRecord | null>(null)

  const [isSyncing, setIsSyncing] = useState(false)
  const [notification, setNotification] = useState<{
    type: "success" | "error"
    message: string
  } | null>(null)

  // Fetch feed with SWR
  const swrKey = ["calendar-feed", filters.competition, filters.team, filters.status]
  const { data, isLoading } = useSWR<CalendarFeedResponse>(
    swrKey,
    () =>
      getCalendarFeedAction({
        competition: filters.competition,
        team: filters.team,
        status: filters.status,
      }),
    { revalidateOnFocus: true },
  )

  // Fetch registered users for sharing dialog
  const { data: availableUsers = [] } = useSWR(
    "shareable-users",
    getShareableUsersAction,
  )

  const rawFixtures = data?.fixtures || []
  const rawEvents = data?.events || []
  const currentUser = data?.currentUser || null
  const latestSync = data?.latestSync || null

  // Filter events client-side based on `type` filter
  const filteredEvents = rawEvents.filter((e) => {
    if (filters.type === "personal") return e.userId === currentUser?.userId
    if (filters.type === "shared") return e.visibility === "shared" && e.userId !== currentUser?.userId
    if (filters.type === "fixtures") return false
    return true
  })

  // Filter fixtures client-side based on `type` filter
  const filteredFixtures = filters.type === "personal" || filters.type === "shared" ? [] : rawFixtures

  // Get distinct team names for autocomplete
  const teamsList = React.useMemo(() => {
    try {
      const all = getAllTeams().map((t) => t.name)
      return Array.from(new Set(all)).sort()
    } catch {
      return []
    }
  }, [])

  // Auto-dismiss notification after 5s
  useEffect(() => {
    if (!notification) return
    const timer = setTimeout(() => setNotification(null), 5000)
    return () => clearTimeout(timer)
  }, [notification])

  // Navigation handlers
  const handlePrev = () => {
    const next = new Date(currentDate)
    if (viewMode === "month") {
      next.setMonth(next.getMonth() - 1)
    } else {
      next.setDate(next.getDate() - 7)
    }
    setCurrentDate(next)
  }

  const handleNext = () => {
    const next = new Date(currentDate)
    if (viewMode === "month") {
      next.setMonth(next.getMonth() + 1)
    } else {
      next.setDate(next.getDate() + 7)
    }
    setCurrentDate(next)
  }

  const handleToday = () => {
    setCurrentDate(new Date())
  }

  // Event handlers
  const handleOpenNewEvent = (targetDate?: Date, targetFixture?: FixtureRecord) => {
    if (!currentUser) {
      setNotification({
        type: "error",
        message: "Please sign in or create an account to create personal events or notes.",
      })
      return
    }
    setSelectedEvent(null)
    setNewEventDate(targetDate || new Date())
    setNewEventFixture(targetFixture || null)
    setIsEventDialogOpen(true)
  }

  const handleSelectEvent = (event: CalendarEventRecord) => {
    setSelectedEvent(event)
    setNewEventDate(null)
    setNewEventFixture(null)
    setIsEventDialogOpen(true)
  }

  const handleSaveEvent = async (eventData: Parameters<typeof createPersonalEventAction>[0] & { id?: string }) => {
    if (!currentUser) {
      return { success: false, error: "Authentication required" }
    }

    if (eventData.id) {
      // Update
      const res = await updatePersonalEventAction(eventData.id, eventData)
      if (res.success) {
        setNotification({ type: "success", message: "Event updated successfully!" })
        mutate(swrKey)
      }
      return res
    } else {
      // Create
      const res = await createPersonalEventAction(eventData)
      if (res.success) {
        setNotification({ type: "success", message: "Event created successfully!" })
        mutate(swrKey)
      }
      return res
    }
  }

  const handleDeleteEvent = async (id: string) => {
    const res = await deletePersonalEventAction(id)
    if (res.success) {
      setNotification({ type: "success", message: "Event deleted successfully." })
      mutate(swrKey)
    }
    return res
  }

  const handleSyncFixtures = async () => {
    setIsSyncing(true)
    try {
      const res = await syncFixturesAction(filters.competition)
      setNotification({
        type: res.success ? "success" : "error",
        message: res.message,
      })
      mutate(swrKey)
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err)
      setNotification({ type: "error", message: `Sync failed: ${msg}` })
    } finally {
      setIsSyncing(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Toast Notification */}
      {notification && (
        <div
          className={`sticky top-0 z-50 flex items-center justify-between px-4 py-2.5 text-xs font-medium border-b shadow-md transition-all ${
            notification.type === "success"
              ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
              : "bg-destructive/20 text-destructive border-destructive/40"
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === "success" ? (
              <CheckCircle2 className="size-4 shrink-0 text-emerald-400" />
            ) : (
              <AlertCircle className="size-4 shrink-0 text-destructive" />
            )}
            <span>{notification.message}</span>
          </div>
          <button
            onClick={() => setNotification(null)}
            className="p-1 hover:opacity-70 text-foreground"
          >
            <X className="size-3.5" />
          </button>
        </div>
      )}

      {/* Calendar Header with Navigation, View Switching, and Sync */}
      <CalendarHeader
        currentDate={currentDate}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        onNavigatePrev={handlePrev}
        onNavigateNext={handleNext}
        onNavigateToday={handleToday}
        onOpenNewEvent={() => handleOpenNewEvent()}
        onSyncFixtures={handleSyncFixtures}
        isSyncing={isSyncing}
        latestSync={latestSync}
        user={currentUser}
      />

      {/* Multi-level Filters Bar */}
      <CalendarFilters
        filters={filters}
        onChange={(updated) => setFilters((prev) => ({ ...prev, ...updated }))}
        onReset={() =>
          setFilters({ competition: "all", team: "", type: "all", status: "all" })
        }
        teamsList={teamsList}
        fixturesCount={rawFixtures.length}
        eventsCount={rawEvents.length}
        isLoggedIn={Boolean(currentUser)}
      />

      {/* Main View Display */}
      <div className="flex-1">
        {isLoading ? (
          <div className="flex items-center justify-center p-20 text-muted-foreground text-sm">
            Loading verified fixtures and events...
          </div>
        ) : viewMode === "month" ? (
          <MonthView
            currentDate={currentDate}
            fixtures={filteredFixtures}
            events={filteredEvents}
            onSelectFixture={(f) => setSelectedFixture(f)}
            onSelectEvent={handleSelectEvent}
            onCreateEventOnDate={(d) => handleOpenNewEvent(d)}
          />
        ) : viewMode === "week" ? (
          <WeekView
            currentDate={currentDate}
            fixtures={filteredFixtures}
            events={filteredEvents}
            onSelectFixture={(f) => setSelectedFixture(f)}
            onSelectEvent={handleSelectEvent}
            onCreateEventOnDate={(d) => handleOpenNewEvent(d)}
          />
        ) : (
          <UpcomingView
            fixtures={filteredFixtures}
            events={filteredEvents}
            onSelectFixture={(f) => setSelectedFixture(f)}
            onSelectEvent={handleSelectEvent}
            onAddNoteForFixture={(f) => handleOpenNewEvent(new Date(f.kickoffTime), f)}
          />
        )}
      </div>

      {/* Modals & Dialogs */}
      <EventDialog
        isOpen={isEventDialogOpen}
        onClose={() => setIsEventDialogOpen(false)}
        onSave={handleSaveEvent}
        onDelete={handleDeleteEvent}
        initialEvent={selectedEvent}
        initialDate={newEventDate}
        initialFixture={newEventFixture}
        fixtures={rawFixtures}
        availableUsers={availableUsers}
        currentUserId={currentUser?.userId || null}
      />

      <FixtureDetailModal
        fixture={selectedFixture}
        isOpen={Boolean(selectedFixture)}
        onClose={() => setSelectedFixture(null)}
        userEvents={rawEvents}
        onOpenAddNote={(f) => handleOpenNewEvent(new Date(f.kickoffTime), f)}
        onSelectEvent={handleSelectEvent}
        isLoggedIn={Boolean(currentUser)}
      />
    </div>
  )
}
