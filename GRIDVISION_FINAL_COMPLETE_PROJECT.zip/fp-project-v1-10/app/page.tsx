"use client"

import { useMemo } from "react"
import Link from "next/link"
import { Users, Star as StarIcon, Shield, ArrowRight, Star } from "lucide-react"
import { PageHeader } from "@/components/page-header"
import { MatchupSelector } from "@/components/matchup-selector"
import { StatCard } from "@/components/stat-card"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useSeason } from "@/components/season-context"
import { getSeason, SEASON_LABELS, teamColor, type Player } from "@/lib/data"
import { findRealPlayerByName } from "@/lib/players"
import { PlayerAvatar } from "@/components/player-avatar"

export default function DashboardPage() {
  const { season } = useSeason()
  const { teams, players } = useMemo(() => getSeason(season), [season])

  const totals = useMemo(() => {
    const avgOverall = players.length
      ? Math.round(players.reduce((s, p) => s + p.overall, 0) / players.length)
      : 0
    return { avgOverall }
  }, [players])

  const topScorers = useMemo(() => [...players].sort((a, b) => b.overall - a.overall).slice(0, 6), [players])

  return (
    <>
      <PageHeader
        eyebrow={`${SEASON_LABELS[season]} · FIFA`}
        title="GridVision"
        description="FIFA player ratings across the World Cup 2026 and three top leagues — explore players, build a dream team and compare teams by Elo, strength and rating."
        actions={<Badge variant="secondary" className="font-mono text-xs">{players.length} players · {teams.length} {season === "world-cup" ? "national teams" : "clubs"}</Badge>}
      />

      <div className="space-y-6 px-4 py-5 sm:px-6 sm:py-6 md:px-8">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <StatCard icon={Users} label="Players rated" value={players.length} hint={`${SEASON_LABELS[season]}`} />
          <StatCard icon={Shield} label={season === "world-cup" ? "National teams" : "Clubs & teams"} value={teams.length} hint={season === "world-cup" ? "competing in tournament" : "competing in league"} />
          <StatCard icon={StarIcon} label="Avg overall" value={totals.avgOverall} accent="accent" hint={season === "world-cup" ? "across all national teams" : "across all clubs"} />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3 items-start">
          <div className="min-w-0 lg:col-span-2">
            <MatchupSelector />
          </div>

          <Card className="gap-0 p-0 overflow-hidden self-start">
            <div className="flex items-center justify-between border-b border-border p-4">
              <div className="flex items-center gap-2">
                <Star className="size-4 text-primary" />
                <h3 className="text-sm font-semibold">Highest-rated players</h3>
              </div>
              <Link href="/players" className="flex items-center gap-1 text-xs text-primary hover:underline">
                All players <ArrowRight className="size-3" />
              </Link>
            </div>
            <div className="divide-y divide-border">
              {topScorers.map((p, i) => (
                <TopPlayerRow key={p.id} player={p} rank={i + 1} />
              ))}
            </div>
          </Card>
        </div>
      </div>
    </>
  )
}

function TopPlayerRow({ player, rank }: { player: Player; rank: number }) {
  const real = findRealPlayerByName(player.name, player.club, player.nationality)
  const targetHref = real ? `/players/${real.id}` : "/players"

  return (
    <Link href={targetHref} className="flex items-center gap-3 px-4 py-2.5 transition-colors hover:bg-secondary/60">
      <span className="w-4 text-center font-mono text-xs text-muted-foreground">{rank}</span>
      <PlayerAvatar
        name={player.name}
        image={real?.image}
        color={teamColor(player.team)}
        size="list"
      />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{player.name}</p>
        <p className="text-[11px] text-muted-foreground">{player.pos} · {player.club} · <span title={`Potential rating: ${player.potential}`}>POT {player.potential}</span></p>
      </div>
      <span className="font-mono text-sm font-semibold tabular-nums" title={`Overall rating: ${player.overall}`}>{player.overall}</span>
    </Link>
  )
}


