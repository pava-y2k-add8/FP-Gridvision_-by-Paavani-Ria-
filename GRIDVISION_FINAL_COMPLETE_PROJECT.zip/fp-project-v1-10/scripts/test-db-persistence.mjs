/**
 * GridVision - Standalone PostgreSQL Connectivity & Persistence Test Suite
 *
 * This script tests connectivity, table schema, strategy persistence,
 * calendar event persistence, and multi-user data isolation against a
 * dedicated PostgreSQL database.
 *
 * Usage:
 *   node scripts/test-db-persistence.mjs "<POSTGRES_CONNECTION_STRING>"
 * or:
 *   $env:DATABASE_URL="<POSTGRES_CONNECTION_STRING>"; node scripts/test-db-persistence.mjs
 */

import { Pool } from "pg"
import { drizzle } from "drizzle-orm/node-postgres"
import { eq, and, desc } from "drizzle-orm"
import { pgTable, serial, text, timestamp, boolean, integer } from "drizzle-orm/pg-core"
import assert from "node:assert"
import crypto from "node:crypto"

// Resolve connection string from argument or environment variable
const connectionString = (process.argv[2] || process.env.DATABASE_URL || "").trim()

if (!connectionString) {
  console.error("\n[ERROR] No PostgreSQL connection string provided.")
  console.log("\nUsage:")
  console.log('  node scripts/test-db-persistence.mjs "postgresql://<user>:<password>@<host>/<database>?sslmode=require"')
  console.log("or via environment variable:")
  console.log('  $env:DATABASE_URL="postgresql://..."; node scripts/test-db-persistence.mjs\n')
  process.exit(1)
}

// Configure SSL if required by cloud providers (Neon, Supabase, AWS, etc.)
const needsSsl = connectionString.includes("sslmode=require") || 
                 connectionString.includes("neon.tech") || 
                 connectionString.includes("supabase.co")

const pool = new Pool({
  connectionString,
  ssl: needsSsl ? { rejectUnauthorized: false } : undefined,
  max: 3,
  connectionTimeoutMillis: 10000,
})

// Schema definitions matching lib/db/schema.ts
const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  salt: text("salt").notNull(),
  emailVerified: boolean("email_verified").notNull().default(false),
  emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

const savedStrategies = pgTable("saved_strategies", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  notes: text("notes"),
  mode: text("mode").notNull().default("club"),
  season: text("season").notNull(),
  teamId: integer("team_id"),
  teamName: text("team_name").notNull(),
  formation: text("formation").notNull(),
  lineup: text("lineup").notNull(),
  tacticalPlan: text("tactical_plan"),
  verdict: text("verdict"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
})

const calendarEvents = pgTable("calendar_events", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  eventType: text("event_type").notNull().default("personal"),
  startDate: timestamp("start_date", { withTimezone: true }).notNull(),
  endDate: timestamp("end_date", { withTimezone: true }),
  allDay: boolean("all_day").notNull().default(false),
  linkedFixtureId: text("linked_fixture_id"),
  competition: text("competition"),
  teamId: integer("team_id"),
  visibility: text("visibility").notNull().default("private"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
})

const db = drizzle(pool)

async function runTestSuite() {
  console.log("=================================================================")
  console.log("    GridVision - Dedicated PostgreSQL Persistence Test Suite     ")
  console.log("=================================================================\n")

  // Tracking created records for guaranteed cleanup in finally block
  const createdUserIds = []
  const createdStrategyIds = []
  const createdEventIds = []

  try {
    // -------------------------------------------------------------
    // PHASE 1: CONNECTIVITY & SCHEMA VERIFICATION
    // -------------------------------------------------------------
    console.log("[1/5] Testing PostgreSQL Connection & TLS/SSL Handshake...")
    const handshake = await pool.query(
      "SELECT current_database() AS db_name, current_user AS db_user, version() AS db_version;"
    )
    const { db_name, db_user, db_version } = handshake.rows[0]
    console.log(`  ✓ Connected successfully!`)
    console.log(`    Database: ${db_name}`)
    console.log(`    DB User:  ${db_user}`)
    console.log(`    Server:   ${db_version.split(",")[0]}`)

    console.log("\n[2/5] Verifying Required Database Tables...")
    const tablesRes = await pool.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
    `)
    const existingTables = new Set(tablesRes.rows.map((r) => r.table_name))
    const expectedTables = [
      "users",
      "email_verification_tokens",
      "fixtures",
      "calendar_events",
      "event_shares",
      "sync_logs",
      "saved_strategies",
    ]

    for (const t of expectedTables) {
      if (existingTables.has(t)) {
        console.log(`  ✓ Table found: "${t}"`)
      } else {
        throw new Error(
          `Missing required table "${t}". Please run the schema initialization SQL first.`
        )
      }
    }

    // -------------------------------------------------------------
    // PHASE 2: CREATE TEMPORARY UNIQUE TEST USERS
    // -------------------------------------------------------------
    console.log("\n[3/5] Creating Dynamic Isolated Test Users...")
    const nonce = crypto.randomBytes(4).toString("hex")
    const testEmail1 = `test_runner_${Date.now()}_1_${nonce}@gridvision.test`
    const testEmail2 = `test_runner_${Date.now()}_2_${nonce}@gridvision.test`

    const user1Res = await pool.query(
      `INSERT INTO users (email, name, password_hash, salt, email_verified)
       VALUES ($1, $2, $3, $4, true) RETURNING id;`,
      [testEmail1, "Test User Alpha", "hash_alpha", "salt_alpha"]
    )
    const user1Id = user1Res.rows[0].id
    createdUserIds.push(user1Id)

    const user2Res = await pool.query(
      `INSERT INTO users (email, name, password_hash, salt, email_verified)
       VALUES ($1, $2, $3, $4, true) RETURNING id;`,
      [testEmail2, "Test User Beta", "hash_beta", "salt_beta"]
    )
    const user2Id = user2Res.rows[0].id
    createdUserIds.push(user2Id)

    console.log(`  ✓ Created temporary User 1 (ID: ${user1Id})`)
    console.log(`  ✓ Created temporary User 2 (ID: ${user2Id})`)

    // -------------------------------------------------------------
    // PHASE 3: STRATEGY PERSISTENCE & MULTI-USER ISOLATION
    // -------------------------------------------------------------
    console.log("\n[4/5] Testing Strategy Persistence & User Isolation...")
    const strategyId = "strat_test_" + crypto.randomUUID().replace(/-/g, "").slice(0, 16)
    createdStrategyIds.push(strategyId)

    const testSlots = [
      { slotId: "GK-0", line: "GK", label: "GK", x: 50.0, y: 90.0, playerId: 101, playerName: "David Raya", playerRating: 84 },
      { slotId: "DEF-0", line: "DEF", label: "LB", x: 18.5, y: 72.4, playerId: 102, playerName: "Jurrien Timber", playerRating: 81 },
      { slotId: "DEF-1", line: "DEF", label: "LCB", x: 38.2, y: 75.1, playerId: 103, playerName: "Gabriel Magalhaes", playerRating: 86 },
      { slotId: "DEF-2", line: "DEF", label: "RCB", x: 61.8, y: 75.1, playerId: 104, playerName: "William Saliba", playerRating: 87 },
      { slotId: "DEF-3", line: "DEF", label: "RB", x: 81.5, y: 72.4, playerId: 105, playerName: "Ben White", playerRating: 83 },
      { slotId: "MID-0", line: "MID", label: "LCM", x: 26.0, y: 52.0, playerId: 106, playerName: "Declan Rice", playerRating: 87 },
      { slotId: "MID-1", line: "MID", label: "CM", x: 50.0, y: 48.5, playerId: 107, playerName: "Thomas Partey", playerRating: 82 },
      { slotId: "MID-2", line: "MID", label: "RCM", x: 74.0, y: 52.0, playerId: 108, playerName: "Martin Odegaard", playerRating: 89 },
      { slotId: "FWD-0", line: "FWD", label: "LW", x: 20.0, y: 22.0, playerId: 109, playerName: "Gabriel Martinelli", playerRating: 83 },
      { slotId: "FWD-1", line: "FWD", label: "ST", x: 50.0, y: 19.5, playerId: 110, playerName: "Kai Havertz", playerRating: 83 },
      { slotId: "FWD-2", line: "FWD", label: "RW", x: 80.0, y: 22.0, playerId: 111, playerName: "Bukayo Saka", playerRating: 87 },
    ]

    // 1. Insert Strategy for User 1
    await db.insert(savedStrategies).values({
      id: strategyId,
      userId: user1Id,
      name: "Arsenal 4-3-3 High Press",
      notes: "Automated persistence test setup.",
      mode: "club",
      season: "premier-league",
      teamId: 1,
      teamName: "Arsenal",
      formation: "4-3-3",
      lineup: JSON.stringify(testSlots),
      tacticalPlan: JSON.stringify({ press: "high", summary: "High press test" }),
      verdict: "Strong tactical setup verified.",
    })
    console.log(`  ✓ Inserted strategy "${strategyId}" for User 1`)

    // 2. Query Strategy as User 1
    const user1Strategies = await db
      .select()
      .from(savedStrategies)
      .where(eq(savedStrategies.userId, user1Id))

    assert.strictEqual(user1Strategies.length, 1, "User 1 should find exactly 1 strategy")
    const fetchedStrat = user1Strategies[0]
    assert.strictEqual(fetchedStrat.name, "Arsenal 4-3-3 High Press")
    const parsedSlots = JSON.parse(fetchedStrat.lineup)
    assert.strictEqual(parsedSlots.length, 11, "Must contain all 11 slots")
    assert.strictEqual(parsedSlots[0].x, 50.0, "Exact x coordinate must match")
    assert.strictEqual(parsedSlots[0].y, 90.0, "Exact y coordinate must match")
    console.log(`  ✓ User 1 retrieved strategy with exact lineup coordinates preserved`)

    // 3. Verify Isolation: User 2 must NOT see User 1's strategy
    const user2Strategies = await db
      .select()
      .from(savedStrategies)
      .where(eq(savedStrategies.userId, user2Id))
    assert.strictEqual(user2Strategies.length, 0, "User 2 strategy list must be empty")
    console.log(`  ✓ User 2 strategy list is empty (cross-user data leak prevented)`)

    // 4. Verify Single Lookup Authorization: User 2 querying User 1's strategy by ID returns empty
    const crossFetch = await db
      .select()
      .from(savedStrategies)
      .where(and(eq(savedStrategies.id, strategyId), eq(savedStrategies.userId, user2Id)))
    assert.strictEqual(crossFetch.length, 0, "User 2 cannot query User 1 strategy by ID")
    console.log(`  ✓ Direct strategy access by unauthorized User 2 blocked`)

    // -------------------------------------------------------------
    // PHASE 4: CALENDAR EVENT PERSISTENCE & PRIVACY ISOLATION
    // -------------------------------------------------------------
    console.log("\n[5/5] Testing Calendar Event Persistence & Privacy Isolation...")
    const eventId = "evt_test_" + crypto.randomUUID().replace(/-/g, "").slice(0, 16)
    createdEventIds.push(eventId)

    // 1. Insert Private Event for User 1
    await db.insert(calendarEvents).values({
      id: eventId,
      userId: user1Id,
      title: "Confidential Scouting vs Manchester City",
      description: "Tactical breakdown and opposition player notes.",
      eventType: "scouting",
      startDate: new Date("2026-11-15T15:00:00Z"),
      endDate: new Date("2026-11-15T17:00:00Z"),
      allDay: false,
      visibility: "private",
    })
    console.log(`  ✓ Inserted private calendar event "${eventId}" for User 1`)

    // 2. Query Event as User 1
    const user1Events = await db
      .select()
      .from(calendarEvents)
      .where(eq(calendarEvents.userId, user1Id))
    assert.strictEqual(user1Events.length, 1, "User 1 must find their private event")
    assert.strictEqual(user1Events[0].title, "Confidential Scouting vs Manchester City")
    console.log(`  ✓ User 1 successfully retrieved their private calendar event`)

    // 3. Verify Isolation: User 2 querying private events receives nothing
    const user2Events = await db
      .select()
      .from(calendarEvents)
      .where(
        and(
          eq(calendarEvents.id, eventId),
          eq(calendarEvents.userId, user2Id)
        )
      )
    assert.strictEqual(user2Events.length, 0, "User 2 cannot see User 1 private event")
    console.log(`  ✓ User 2 cannot access User 1 private calendar event`)

    console.log("\n=================================================================")
    console.log("   ALL POSTGRESQL PERSISTENCE & ISOLATION CHECKS PASSED (100%)   ")
    console.log("=================================================================\n")

  } finally {
    // -------------------------------------------------------------
    // GUARANTEED CLEANUP (Runs even if any assert fails)
    // -------------------------------------------------------------
    console.log("Cleaning up temporary test records...")

    if (createdStrategyIds.length > 0) {
      await pool.query(
        "DELETE FROM saved_strategies WHERE id = ANY($1::text[]);",
        [createdStrategyIds]
      )
      console.log(`  ✓ Cleaned up ${createdStrategyIds.length} test strategy record(s).`)
    }

    if (createdEventIds.length > 0) {
      await pool.query(
        "DELETE FROM calendar_events WHERE id = ANY($1::text[]);",
        [createdEventIds]
      )
      console.log(`  ✓ Cleaned up ${createdEventIds.length} test calendar event record(s).`)
    }

    if (createdUserIds.length > 0) {
      await pool.query(
        "DELETE FROM users WHERE id = ANY($1::int[]);",
        [createdUserIds]
      )
      console.log(`  ✓ Cleaned up ${createdUserIds.length} temporary test user(s).`)
    }

    await pool.end()
    console.log("  ✓ Closed database connection pool cleanly.\n")
  }
}

runTestSuite().catch((err) => {
  console.error("\n[FATAL TEST ERROR]:", err.message || err)
  process.exit(1)
})
