import { mkdir, writeFile, readFile } from "node:fs/promises"
import { dirname } from "node:path"
import { fileURLToPath } from "node:url"

// Source: github.com/tkarim45/Beginner-Data-Science-Projects
//   EDA Visualization/FIFA Player Statistics Analysis/data/fifa.csv
const RAW =
  "https://raw.githubusercontent.com/tkarim45/Beginner-Data-Science-Projects/main/EDA%20Visualization/FIFA%20Player%20Statistics%20Analysis/data/fifa.csv"
const OUT_DIR = dirname(fileURLToPath(import.meta.url)) + "/../lib/fifa"

// Three flagship leagues -> the three dataset slots the UI switches between.
const LEAGUES = {
  "premier-league": "English Premier League",
  "la-liga": "Spain Primera Division",
  "serie-a": "Italian Serie A",
}

// Minimal RFC-4180-ish CSV parser (handles quoted fields with commas/newlines)
function parseCSV(text) {
  const rows = []
  let row = []
  let field = ""
  let i = 0
  let inQuotes = false
  while (i < text.length) {
    const c = text[i]
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"'
          i += 2
          continue
        }
        inQuotes = false
        i++
        continue
      }
      field += c
      i++
      continue
    }
    if (c === '"') {
      inQuotes = true
      i++
      continue
    }
    if (c === ",") {
      row.push(field)
      field = ""
      i++
      continue
    }
    if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++
      row.push(field)
      rows.push(row)
      row = []
      field = ""
      i++
      continue
    }
    field += c
    i++
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field)
    rows.push(row)
  }
  return rows
}

function toObjects(text) {
  const rows = parseCSV(text)
  if (rows.length === 0) return []
  const header = rows[0]
  const out = []
  for (let r = 1; r < rows.length; r++) {
    const row = rows[r]
    if (row.length === 1 && row[0] === "") continue
    const obj = {}
    for (let c = 0; c < header.length; c++) obj[header[c]] = row[c]
    out.push(obj)
  }
  return out
}

const num = (v) => {
  if (v === undefined || v === null || v === "") return 0
  const n = Number(v)
  return Number.isFinite(n) ? Math.round(n) : 0
}
const str = (v) => (v == null ? "" : String(v).trim())

// FIFA detailed positions -> the app's four buckets
function bucket(rawPositions) {
  const first = str(rawPositions).split(",")[0].trim().toUpperCase()
  if (first === "GK") return "GKP"
  if (["CB", "LB", "RB", "LWB", "RWB"].includes(first)) return "DEF"
  if (["CDM", "CM", "CAM", "LM", "RM", "LCM", "RCM"].includes(first)) return "MID"
  return "FWD" // ST, CF, LW, RW, LS, RS, etc.
}

// Deterministic, legible-on-dark badge colour from the club name.
function clubColor(name) {
  let h = 0
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0
  const hue = h % 360
  return `hsl(${hue} 62% 66%)`
}

function shortCode(name, taken) {
  const clean = name.replace(/[^A-Za-z0-9 ]/g, " ").trim()
  const words = clean.split(/\s+/).filter(Boolean)
  let base
  if (words.length >= 2) base = (words[0][0] + words[1][0] + (words[1][1] ?? words[0][1] ?? "")).toUpperCase()
  else base = clean.slice(0, 3).toUpperCase()
  base = base.slice(0, 3).padEnd(3, "X")
  let code = base
  let n = 1
  while (taken.has(code)) {
    code = (base.slice(0, 2) + String(n)).toUpperCase()
    n++
  }
  taken.add(code)
  return code
}

async function loadCsv() {
  // Prefer a local copy if present (faster / offline), else fetch the raw file.
  try {
    return await readFile("/tmp/fifa.csv", "utf-8")
  } catch {
    const res = await fetch(RAW)
    if (!res.ok) throw new Error(`${res.status} fetching FIFA csv`)
    return res.text()
  }
}

let CLUB_ID = 1

function buildLeague(rows) {
  const clubMap = new Map() // clubName -> team
  const takenCodes = new Set()

  const players = rows.map((row) => {
    const club = str(row.club_name)
    if (!clubMap.has(club)) {
      clubMap.set(club, {
        id: CLUB_ID++,
        name: club,
        short: shortCode(club, takenCodes),
        color: clubColor(club),
      })
    }
    const team = clubMap.get(club)
    return {
      id: num(row.sofifa_id),
      name: str(row.short_name),
      longName: str(row.long_name),
      pos: bucket(row.player_positions),
      positions: str(row.player_positions),
      teamId: team.id,
      team: team.short,
      club,
      nationality: str(row.nationality),
      age: num(row.age),
      dob: str(row.dob),
      heightCm: num(row.height_cm),
      weightKg: num(row.weight_kg),
      overall: num(row.overall),
      potential: num(row.potential),
      valueEur: num(row.value_eur),
      wageEur: num(row.wage_eur),
      releaseClauseEur: num(row.release_clause_eur),
      preferredFoot: str(row.preferred_foot),
      weakFoot: num(row.weak_foot),
      skillMoves: num(row.skill_moves),
      intReputation: num(row.international_reputation),
      workRate: str(row.work_rate),
      bodyType: str(row.body_type),
      jerseyNumber: num(row.team_jersey_number),
      traits: str(row.player_traits),
      // main FIFA face stats (GK columns hold the keeper equivalents)
      pace: num(row.pace) || num(row.gk_speed),
      shooting: num(row.shooting) || num(row.gk_positioning),
      passing: num(row.passing) || num(row.gk_kicking),
      dribbling: num(row.dribbling) || num(row.gk_reflexes),
      defending: num(row.defending) || num(row.gk_handling),
      physic: num(row.physic) || num(row.gk_diving),
      // detailed breakdown for the player page
      attacking: {
        crossing: num(row.attacking_crossing),
        finishing: num(row.attacking_finishing),
        heading: num(row.attacking_heading_accuracy),
        shortPassing: num(row.attacking_short_passing),
        volleys: num(row.attacking_volleys),
      },
      skill: {
        dribbling: num(row.skill_dribbling),
        curve: num(row.skill_curve),
        fkAccuracy: num(row.skill_fk_accuracy),
        longPassing: num(row.skill_long_passing),
        ballControl: num(row.skill_ball_control),
      },
      movement: {
        acceleration: num(row.movement_acceleration),
        sprintSpeed: num(row.movement_sprint_speed),
        agility: num(row.movement_agility),
        reactions: num(row.movement_reactions),
        balance: num(row.movement_balance),
      },
      power: {
        shotPower: num(row.power_shot_power),
        jumping: num(row.power_jumping),
        stamina: num(row.power_stamina),
        strength: num(row.power_strength),
        longShots: num(row.power_long_shots),
      },
      mentality: {
        aggression: num(row.mentality_aggression),
        interceptions: num(row.mentality_interceptions),
        positioning: num(row.mentality_positioning),
        vision: num(row.mentality_vision),
        penalties: num(row.mentality_penalties),
        composure: num(row.mentality_composure),
      },
      defense: {
        marking: num(row.defending_marking),
        standing: num(row.defending_standing_tackle),
        sliding: num(row.defending_sliding_tackle),
      },
      goalkeeping: {
        diving: num(row.goalkeeping_diving),
        handling: num(row.goalkeeping_handling),
        kicking: num(row.goalkeeping_kicking),
        positioning: num(row.goalkeeping_positioning),
        reflexes: num(row.goalkeeping_reflexes),
      },
    }
  })

  players.sort((a, b) => b.overall - a.overall)
  const teams = [...clubMap.values()].sort((a, b) => a.name.localeCompare(b.name))
  return { teams, players }
}

async function main() {
  const csv = await loadCsv()
  const all = toObjects(csv)
  await mkdir(OUT_DIR, { recursive: true })

  for (const [slug, leagueName] of Object.entries(LEAGUES)) {
    const rows = all.filter((r) => str(r.league_name) === leagueName)
    const { teams, players } = buildLeague(rows)
    await writeFile(`${OUT_DIR}/teams-${slug}.json`, JSON.stringify(teams))
    await writeFile(`${OUT_DIR}/players-${slug}.json`, JSON.stringify(players))
    console.log(`[${slug}] ${leagueName}: teams=${teams.length} players=${players.length}`)
  }
  console.log("\nDone.")
}

await main()
