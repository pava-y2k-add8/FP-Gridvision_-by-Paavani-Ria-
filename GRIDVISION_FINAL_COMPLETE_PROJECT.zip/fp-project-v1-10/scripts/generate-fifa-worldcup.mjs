import { mkdir, writeFile, readFile } from "node:fs/promises"
import { dirname } from "node:path"
import { fileURLToPath } from "node:url"

// Source: github.com/mominullptr/FIFA-World-Cup-2026-Dataset
//   teams.csv + squads_and_players.csv + player_stats.csv
// The World Cup dataset carries real squad data (national team, club, market
// value, caps, height, tournament goals) but no FIFA-style attribute ratings,
// so club/player face stats are derived deterministically from those real
// signals (market value is the dominant driver, blended with caps and the
// player's average tournament match rating).
const BASE = "https://raw.githubusercontent.com/mominullptr/FIFA-World-Cup-2026-Dataset/main"
const OUT_DIR = dirname(fileURLToPath(import.meta.url)) + "/../lib/fifa"
const SLUG = "world-cup"

// Avoid id collisions with the club-league datasets (small sofifa/team ids).
const TEAM_ID_OFFSET = 100000
const PLAYER_ID_OFFSET = 9000000
const TOURNAMENT_YEAR = 2026

// Minimal RFC-4180-ish CSV parser (handles quoted fields with commas/newlines)
function parseCSV(text) {
  const rows = []
  let row = []
  let field = ""
  let i = 0
  let inQuotes = false
  while (i < text.length) {
    const c = text[i]
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"'
          i += 2
          continue
        }
        inQuotes = false
        i++
        continue
      }
      field += c
      i++
      continue
    }
    if (c === '"') {
      inQuotes = true
      i++
      continue
    }
    if (c === ",") {
      row.push(field)
      field = ""
      i++
      continue
    }
    if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++
      row.push(field)
      rows.push(row)
      row = []
      field = ""
      i++
      continue
    }
    field += c
    i++
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field)
    rows.push(row)
  }
  return rows
}

function toObjects(text) {
  const rows = parseCSV(text)
  if (rows.length === 0) return []
  const header = rows[0]
  const out = []
  for (let r = 1; r < rows.length; r++) {
    const row = rows[r]
    if (row.length === 1 && row[0] === "") continue
    const obj = {}
    for (let c = 0; c < header.length; c++) obj[header[c]] = row[c]
    out.push(obj)
  }
  return out
}

const num = (v) => {
  if (v === undefined || v === null || v === "") return 0
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}
const str = (v) => (v == null ? "" : String(v).trim())
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Math.round(v)))

// Deterministic PRNG seeded by the player id so generated stats are stable.
function rng(seed) {
  let s = (seed >>> 0) || 1
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0
    return s / 4294967296
  }
}

// Deterministic, legible-on-dark badge colour from the team name.
function teamColor(name) {
  let h = 0
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0
  const hue = h % 360
  return `hsl(${hue} 62% 66%)`
}

function bucket(rawPosition) {
  const p = str(rawPosition).toUpperCase()
  if (p === "GK" || p === "GKP") return "GKP"
  if (p === "DEF") return "DEF"
  if (p === "MID") return "MID"
  return "FWD"
}

function ageFromDob(dob) {
  const d = new Date(dob)
  if (Number.isNaN(d.getTime())) return 0
  let age = TOURNAMENT_YEAR - d.getFullYear()
  // tournament kicks off in June; nudge down if birthday falls later in the year
  if (d.getMonth() > 5) age -= 1
  return age
}

// Market value (log scale) is the dominant real signal for a player's quality,
// blended with international experience (caps) and average match rating.
function deriveOverall(valueEur, caps, avgRating) {
  const v = Math.max(25000, valueEur || 25000)
  const logV = Math.log10(v) // 25k -> 4.40, 200M -> 8.30
  let ovr = 52 + ((logV - 4.4) / (8.3 - 4.4)) * 39 // -> ~52..91
  ovr += Math.min(4, caps / 40) // experience bump, capped
  if (avgRating > 0) ovr += (avgRating - 7) * 3 // sofascore-style rating nudge
  return clamp(ovr, 48, 94)
}

// Per-position offsets applied to the six FIFA face stats.
const FACE_OFFSETS = {
  FWD: { pace: 6, shooting: 8, passing: -2, dribbling: 5, defending: -26, physic: -2 },
  MID: { pace: 0, shooting: -2, passing: 6, dribbling: 5, defending: -5, physic: -2 },
  DEF: { pace: -2, shooting: -20, passing: -4, dribbling: -8, defending: 8, physic: 6 },
  GKP: { pace: 0, shooting: 0, passing: -4, dribbling: 0, defending: -2, physic: 2 },
}

function faceStats(ovr, pos, rand) {
  const off = FACE_OFFSETS[pos]
  const j = () => Math.round((rand() - 0.5) * 8)
  return {
    pace: clamp(ovr + off.pace + j(), 38, 99),
    shooting: clamp(ovr + off.shooting + j(), 30, 99),
    passing: clamp(ovr + off.passing + j(), 38, 99),
    dribbling: clamp(ovr + off.dribbling + j(), 38, 99),
    defending: clamp(ovr + off.defending + j(), 24, 99),
    physic: clamp(ovr + off.physic + j(), 40, 99),
  }
}

function around(base, rand, spread = 6) {
  return clamp(base + Math.round((rand() - 0.5) * spread), 20, 99)
}

function buildPlayer(row, stats, team, jersey) {
  const rand = rng(num(row.player_id) + 1)
  const pos = bucket(row.position)
  const valueEur = Math.round(num(row.market_value_eur))
  const caps = num(row.caps)
  const avgRating = stats ? num(stats.average_rating) : 0
  const overall = deriveOverall(valueEur, caps, avgRating)
  const age = ageFromDob(row.date_of_birth)
  const potential = clamp(overall + (age > 0 && age <= 23 ? 3 + Math.round(rand() * 4) : Math.round(rand() * 2)), overall, 96)
  const heightCm = num(row.height_cm) || clamp(178 + (rand() - 0.5) * 14, 160, 205)
  const f = faceStats(overall, pos, rand)
  const isGk = pos === "GKP"

  return {
    id: PLAYER_ID_OFFSET + num(row.player_id),
    name: str(row.player_name),
    longName: str(row.player_name),
    pos,
    positions: str(row.position),
    teamId: team.id,
    team: team.short,
    club: str(row.club_team),
    nationality: team.name,
    age,
    dob: str(row.date_of_birth),
    heightCm,
    weightKg: clamp(heightCm - 100 + (rand() - 0.5) * 8, 55, 100),
    overall,
    potential,
    valueEur,
    wageEur: Math.round(valueEur / 200 / 1000) * 1000,
    releaseClauseEur: 0,
    preferredFoot: rand() < 0.78 ? "Right" : "Left",
    weakFoot: clamp(2 + rand() * 3, 1, 5),
    skillMoves: clamp((isGk ? 1 : 2) + rand() * 3, 1, 5),
    intReputation: clamp(1 + (overall - 70) / 8 + rand(), 1, 5),
    workRate: "Medium/Medium",
    bodyType: "Normal",
    jerseyNumber: jersey,
    traits: "",
    pace: f.pace,
    shooting: f.shooting,
    passing: f.passing,
    dribbling: f.dribbling,
    defending: f.defending,
    physic: f.physic,
    attacking: {
      crossing: around(f.passing, rand),
      finishing: around(f.shooting, rand),
      heading: around((f.physic + f.shooting) / 2, rand),
      shortPassing: around(f.passing + 2, rand),
      volleys: around(f.shooting - 2, rand),
    },
    skill: {
      dribbling: around(f.dribbling, rand),
      curve: around(f.passing - 2, rand),
      fkAccuracy: around((f.shooting + f.passing) / 2 - 4, rand),
      longPassing: around(f.passing, rand),
      ballControl: around(f.dribbling + 2, rand),
    },
    movement: {
      acceleration: around(f.pace, rand),
      sprintSpeed: around(f.pace, rand),
      agility: around(f.dribbling, rand),
      reactions: around(overall, rand),
      balance: around(f.dribbling, rand),
    },
    power: {
      shotPower: around(f.shooting, rand),
      jumping: around(f.physic, rand),
      stamina: around(f.physic + 4, rand),
      strength: around(f.physic, rand),
      longShots: around(f.shooting - 3, rand),
    },
    mentality: {
      aggression: around(f.defending + 4, rand),
      interceptions: around(f.defending, rand),
      positioning: around((f.shooting + f.pace) / 2, rand),
      vision: around(f.passing, rand),
      penalties: around(f.shooting - 2, rand),
      composure: around(overall, rand),
    },
    defense: {
      marking: around(f.defending, rand),
      standing: around(f.defending, rand),
      sliding: around(f.defending - 2, rand),
    },
    goalkeeping: isGk
      ? {
          diving: around(overall, rand),
          handling: around(overall, rand),
          kicking: around(overall - 4, rand),
          positioning: around(overall, rand),
          reflexes: around(overall + 2, rand),
        }
      : {
          diving: clamp(4 + rand() * 10, 2, 18),
          handling: clamp(4 + rand() * 10, 2, 18),
          kicking: clamp(4 + rand() * 12, 2, 20),
          positioning: clamp(4 + rand() * 10, 2, 18),
          reflexes: clamp(4 + rand() * 10, 2, 18),
        },
  }
}

async function fetchCsv(name) {
  try {
    return await readFile(`/tmp/${name}`, "utf-8")
  } catch {
    const res = await fetch(`${BASE}/${name}`)
    if (!res.ok) throw new Error(`${res.status} fetching ${name}`)
    return res.text()
  }
}

async function main() {
  const [teamsCsv, squadsCsv, statsCsv] = await Promise.all([
    fetchCsv("teams.csv"),
    fetchCsv("squads_and_players.csv"),
    fetchCsv("player_stats.csv"),
  ])

  const rawTeams = toObjects(teamsCsv)
  const rawSquads = toObjects(squadsCsv)
  const rawStats = toObjects(statsCsv)

  const statsById = new Map()
  for (const s of rawStats) statsById.set(num(s.player_id), s)

  const teams = rawTeams.map((t) => ({
    id: TEAM_ID_OFFSET + num(t.team_id),
    name: str(t.team_name),
    short: str(t.fifa_code) || str(t.team_name).slice(0, 3).toUpperCase(),
    color: teamColor(str(t.team_name)),
  }))
  const teamById = new Map(teams.map((t) => [t.id, t]))

  const jerseyCounter = new Map()
  const players = []
  for (const row of rawSquads) {
    const team = teamById.get(TEAM_ID_OFFSET + num(row.team_id))
    if (!team) continue
    const n = (jerseyCounter.get(team.id) ?? 0) + 1
    jerseyCounter.set(team.id, n)
    players.push(buildPlayer(row, statsById.get(num(row.player_id)), team, n))
  }

  players.sort((a, b) => b.overall - a.overall)
  teams.sort((a, b) => a.name.localeCompare(b.name))

  await mkdir(OUT_DIR, { recursive: true })
  await writeFile(`${OUT_DIR}/teams-${SLUG}.json`, JSON.stringify(teams))
  await writeFile(`${OUT_DIR}/players-${SLUG}.json`, JSON.stringify(players))
  console.log(`[${SLUG}] FIFA World Cup 2026: teams=${teams.length} players=${players.length}`)
}

await main()
