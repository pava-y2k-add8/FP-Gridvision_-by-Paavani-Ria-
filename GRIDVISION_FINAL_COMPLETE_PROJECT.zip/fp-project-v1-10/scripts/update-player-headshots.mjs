import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PLAYERS_FILE = path.join(__dirname, "../lib/players/players.json")

async function main() {
  console.log("=== UPDATING PLAYER HEADSHOTS WITH ACCURATE OFFICIAL PHOTOS ===")
  const raw = await fs.readFile(PLAYERS_FILE, "utf-8")
  const players = JSON.parse(raw)
  console.log(`Loaded ${players.length} players from players.json`)

  // Step 1: Upgrade all /portrait/header/ to /portrait/big/
  let upgradedToBig = 0
  for (const p of players) {
    if (p.image && p.image.includes("/portrait/header/")) {
      p.image = p.image.replace("/portrait/header/", "/portrait/big/")
      upgradedToBig++
    }
  }
  console.log(`Step 1: Upgraded ${upgradedToBig} players to high-resolution /portrait/big/`)

  // Step 2: Query top 150 active players by market value to fetch most recent official portrait
  const sorted = [...players]
    .filter((p) => !p.retired && p.marketValueEur > 0)
    .sort((a, b) => b.marketValueEur - a.marketValueEur)
    .slice(0, 150)

  console.log(`Step 2: Checking recency for top ${sorted.length} players...`)
  let recencyUpgraded = 0
  let unchangedVerified = 0

  // Run in batches of 10
  const BATCH_SIZE = 10
  for (let i = 0; i < sorted.length; i += BATCH_SIZE) {
    const batch = sorted.slice(i, i + BATCH_SIZE)
    await Promise.all(
      batch.map(async (p) => {
        const oldUrl = p.image
        const oldTsMatch = oldUrl ? oldUrl.match(/-([0-9]+)\./) : null
        const oldTs = oldTsMatch ? Number(oldTsMatch[1]) : 0

        try {
          const profileUrl = `https://www.transfermarkt.com/${p.slug}/profil/spieler/${p.id}`
          const res = await fetch(profileUrl, {
            headers: { "User-Agent": "Mozilla/5.0" },
          })
          if (res.ok) {
            const html = await res.text()
            const match = html.match(
              new RegExp(`https://img\\.a\\.transfermarkt\\.technology/portrait/big/${p.id}-([0-9]+)\\.[a-z]+`, "i")
            )
            if (match) {
              const newUrl = match[0]
              const newTs = Number(match[1])
              if (newTs > oldTs) {
                // Verify new URL is accessible
                const imgCheck = await fetch(newUrl, {
                  headers: { "User-Agent": "Mozilla/5.0" },
                })
                if (imgCheck.ok) {
                  // Find original in players array and update
                  const target = players.find((x) => x.id === p.id)
                  if (target) {
                    target.image = newUrl
                    recencyUpgraded++
                    const oldDate = oldTs ? new Date(oldTs * 1000).toISOString().split("T")[0] : "none"
                    const newDate = new Date(newTs * 1000).toISOString().split("T")[0]
                    console.log(`[RECENCY UPGRADE] ${p.name}: ${oldDate} -> ${newDate}`)
                  }
                  return
                }
              }
            }
          }
        } catch {
          // Keep existing verified fallback
        }
        unchangedVerified++
      })
    )
  }

  console.log(`\nRecency check complete:`)
  console.log(`- Upgraded to newer official photo: ${recencyUpgraded}`)
  console.log(`- Verified existing official photo already most recent: ${unchangedVerified}`)

  // Step 3: Write updated players.json
  await fs.writeFile(PLAYERS_FILE, JSON.stringify(players, null, 2), "utf-8")
  console.log(`Successfully updated ${PLAYERS_FILE}`)
}

main().catch((err) => {
  console.error("Error in script:", err)
  process.exit(1)
})
