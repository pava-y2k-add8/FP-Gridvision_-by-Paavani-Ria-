import assert from "node:assert"
import {
  getUserStrategies,
  getStrategyById,
  createStrategy,
  updateStrategy,
  duplicateStrategy,
  deleteStrategy,
  type SavedSlotSetup,
} from "../lib/db/strategy-store"

console.log("=== RUNNING SAVED STRATEGIES TEST SUITE ===")

async function runTests() {
  const user1 = 8881
  const user2 = 8882

  console.log("\n1. Testing Strategy Creation for User 1...")
  const initialSlots: SavedSlotSetup[] = [
    { slotId: "GK-0", line: "GK", label: "GK", x: 50, y: 90, playerId: 1001, playerName: "David Raya", playerClub: "Arsenal", playerPos: "GKP", playerRating: 84 },
    { slotId: "DEF-0", line: "DEF", label: "LB", x: 18.5, y: 72.4, playerId: 1002, playerName: "Jurrien Timber", playerClub: "Arsenal", playerPos: "DEF", playerRating: 81 },
    { slotId: "DEF-1", line: "DEF", label: "LCB", x: 38.2, y: 75.1, playerId: 1003, playerName: "Gabriel Magalhaes", playerClub: "Arsenal", playerPos: "DEF", playerRating: 86 },
    { slotId: "DEF-2", line: "DEF", label: "RCB", x: 61.8, y: 75.1, playerId: 1004, playerName: "William Saliba", playerClub: "Arsenal", playerPos: "DEF", playerRating: 87 },
    { slotId: "DEF-3", line: "DEF", label: "RB", x: 81.5, y: 72.4, playerId: 1005, playerName: "Ben White", playerClub: "Arsenal", playerPos: "DEF", playerRating: 83 },
    { slotId: "MID-0", line: "MID", label: "LCM", x: 26.0, y: 52.0, playerId: 1006, playerName: "Declan Rice", playerClub: "Arsenal", playerPos: "MID", playerRating: 87 },
    { slotId: "MID-1", line: "MID", label: "CM", x: 50.0, y: 48.5, playerId: 1007, playerName: "Thomas Partey", playerClub: "Arsenal", playerPos: "MID", playerRating: 82 },
    { slotId: "MID-2", line: "MID", label: "RCM", x: 74.0, y: 52.0, playerId: 1008, playerName: "Martin Odegaard", playerClub: "Arsenal", playerPos: "MID", playerRating: 89 },
    { slotId: "FWD-0", line: "FWD", label: "LW", x: 20.0, y: 22.0, playerId: 1009, playerName: "Gabriel Martinelli", playerClub: "Arsenal", playerPos: "FWD", playerRating: 83 },
    { slotId: "FWD-1", line: "FWD", label: "ST", x: 50.0, y: 19.5, playerId: 1010, playerName: "Kai Havertz", playerClub: "Arsenal", playerPos: "FWD", playerRating: 83 },
    { slotId: "FWD-2", line: "FWD", label: "RW", x: 80.0, y: 22.0, playerId: 1011, playerName: "Bukayo Saka", playerClub: "Arsenal", playerPos: "FWD", playerRating: 87 },
  ]

  const created1 = await createStrategy({
    userId: user1,
    name: "Arsenal 4-3-3 High Press",
    notes: "Aggressive counter-pressing with high fullbacks and inverted wingers.",
    mode: "club",
    season: "2025-26",
    teamId: 1,
    teamName: "Arsenal",
    formation: "4-3-3",
    slots: initialSlots,
    tacticalPlan: {
      summary: "High pressing 4-3-3 focused on rapid ball recovery.",
      keyPlayer: "Martin Odegaard — Chief creator in half-spaces",
      press: "high",
      attackFocus: "wings",
    },
    verdict: "Strong structure with optimal defensive spacing and creative midfield hub.",
  })

  assert(created1.id, "Strategy ID should be generated")
  assert.strictEqual(created1.userId, user1, "User ID should match user1")
  assert.strictEqual(created1.name, "Arsenal 4-3-3 High Press")
  assert.strictEqual(created1.slots.length, 11)
  assert.strictEqual(created1.slots[1].x, 18.5, "Exact x coordinate must be preserved")
  assert.strictEqual(created1.slots[1].y, 72.4, "Exact y coordinate must be preserved")
  console.log("✓ Strategy successfully created with exact positions and snapshot verdict.")

  console.log("\n2. Testing User 1 Fetch List...")
  const listUser1 = await getUserStrategies(user1)
  assert(listUser1.some((s) => s.id === created1.id), "User 1 should see their strategy in list")
  console.log(`✓ User 1 has ${listUser1.length} strategy/strategies returned.`)

  console.log("\n3. Testing Strict Multi-User Security & Cross-Account Isolation...")
  const listUser2 = await getUserStrategies(user2)
  assert(!listUser2.some((s) => s.id === created1.id), "User 2 MUST NOT see User 1's strategy in list")
  console.log("✓ User 2 strategy list does not leak User 1's strategies.")

  const getOther = await getStrategyById(created1.id, user2)
  assert.strictEqual(getOther, null, "User 2 cannot read User 1's strategy by ID")
  console.log("✓ User 2 read attempt rejected (returned null).")

  let updateBlocked = false
  try {
    await updateStrategy(created1.id, user2, { name: "Hacked Strategy" })
  } catch (err) {
    updateBlocked = true
  }
  assert(updateBlocked, "User 2 must be blocked from updating User 1's strategy")
  console.log("✓ User 2 update attempt blocked server-side.")

  let dupBlocked = false
  try {
    await duplicateStrategy(created1.id, user2)
  } catch (err) {
    dupBlocked = true
  }
  assert(dupBlocked, "User 2 must be blocked from duplicating User 1's strategy")
  console.log("✓ User 2 duplication attempt blocked server-side.")

  let deleteBlocked = false
  try {
    await deleteStrategy(created1.id, user2)
  } catch (err) {
    deleteBlocked = true
  }
  assert(deleteBlocked, "User 2 must be blocked from deleting User 1's strategy")
  console.log("✓ User 2 deletion attempt blocked server-side.")

  console.log("\n4. Testing Strategy Update & Position Changes by Owner...")
  const modifiedSlots = [...initialSlots]
  modifiedSlots[10] = { ...modifiedSlots[10], x: 84.2, y: 24.8 } // Saka pushed wider and slightly deeper

  const updated = await updateStrategy(created1.id, user1, {
    notes: "Updated tactical notes: Saka pushed wider to stretch low blocks.",
    slots: modifiedSlots,
  })

  assert.strictEqual(updated.notes, "Updated tactical notes: Saka pushed wider to stretch low blocks.")
  assert.strictEqual(updated.slots[10].x, 84.2, "Updated position x coordinate must be preserved")
  assert.strictEqual(updated.slots[10].y, 24.8, "Updated position y coordinate must be preserved")
  console.log("✓ Strategy successfully updated with new positions and notes.")

  console.log("\n5. Testing Strategy Duplication...")
  const duplicated = await duplicateStrategy(created1.id, user1)
  assert(duplicated.id !== created1.id, "Duplicated strategy must have a new unique ID")
  assert.strictEqual(duplicated.name, "Arsenal 4-3-3 High Press (Copy)")
  assert.strictEqual(duplicated.slots[10].x, 84.2, "Duplicated strategy retains exact slot coordinates")
  console.log(`✓ Strategy successfully duplicated as "${duplicated.name}" (ID: ${duplicated.id}).`)

  console.log("\n6. Testing Deletion by Owner...")
  const del1 = await deleteStrategy(created1.id, user1)
  assert.strictEqual(del1, true, "Delete should return true")
  const del2 = await deleteStrategy(duplicated.id, user1)
  assert.strictEqual(del2, true, "Delete copy should return true")

  const verifyEmpty = await getUserStrategies(user1)
  assert(!verifyEmpty.some((s) => s.id === created1.id || s.id === duplicated.id), "Deleted strategies must be removed")
  console.log("✓ Strategy successfully deleted and verified removed from database.")

  console.log("\n=== ALL SAVED STRATEGIES SERVER TESTS PASSED PERFECTLY ===")
}

runTests().catch((err) => {
  console.error("Test failed with error:", err)
  process.exit(1)
})
