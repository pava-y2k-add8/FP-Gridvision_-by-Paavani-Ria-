import ts from "typescript"
import fs from "fs"
import path from "path"

const storeTsPath = path.resolve("lib/db/strategy-store.ts")
const testTsPath = path.resolve("scripts/test-saved-strategies.ts")

const storeTs = fs.readFileSync(storeTsPath, "utf8")
const testTs = fs.readFileSync(testTsPath, "utf8")

const transformedStore = storeTs
  .replace('import { db } from "./index"', 'const db = null')
  .replace('import { savedStrategies } from "./schema"', 'const savedStrategies = null')

const storeJs = ts.transpileModule(transformedStore, {
  compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 }
}).outputText

const testJs = ts.transpileModule(testTs, {
  compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 }
}).outputText
  .replace(/from ["']\.\.\/lib\/db\/strategy-store(\.ts)?["']/, 'from "./temp-store.mjs"')

fs.writeFileSync("scripts/temp-store.mjs", storeJs)
fs.writeFileSync("scripts/temp-test.mjs", testJs)

console.log("Transpiled test files successfully.")
