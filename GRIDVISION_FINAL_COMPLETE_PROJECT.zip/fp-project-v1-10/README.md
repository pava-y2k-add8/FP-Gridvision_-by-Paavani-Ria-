# GridVision - Football Strategy & Analytics Platform

GridVision is a full-stack tactical analytics, player intelligence, and fixture calendar application. It features real-world football Elo ratings dynamically integrated with a Django tactical analytics engine, verified player career profiles, an interactive AI Strategy Builder, and an interactive team calendar.

---

## Features

1. **Live Real-World Team Elo Ratings**:
   - Dynamic Elo leaderboard, historical ratings, and head-to-head matchup probability model sourced from verified match outcomes.
   - Connected via `/api/elo` proxying the Django backend calculation engine.
2. **Player Intelligence**:
   - Comprehensive player database with verified career statistics (appearances, goals, assists, age).
   - Filter by position group, verified career status (`ACTIVE`, `RETIRED`, `UNCERTAIN`), and club.
   - Strictly free of speculative fan votes or artificial market values.
3. **Tactical Strategy Pitch & AI Builder**:
   - Interactive 11-player formation planner (4-4-2, 4-3-3, 3-5-2, 3-4-3, 5-3-2, 4-5-1).
   - Tactical plan generation, matchup breakdown, and conversational strategy assistant.
4. **Calendar & Match Center**:
   - Verified real-world fixtures across Premier League, La Liga, Serie A, and FIFA World Cup.
   - Month, week, and upcoming views with local kickoff times, status badges, and source attribution.
   - Personal events and notes with synchronized permissions.
5. **Secure Authentication**:
   - Salted PBKDF2 password hashing with single-use 1-hour verification tokens.
   - Resend API integration for email verification with strict provider acceptance checks.

---

## Environment Variables

Copy `.env.example` to `.env.local` to configure your environment:

```bash
cp .env.example .env.local
```

### Configuration Options:
- `NEXT_PUBLIC_APP_URL`: The public URL of the frontend (default: `http://localhost:3000`).
- `AUTH_SECRET`: Secret key used for session signing.
- `RESEND_API_KEY`: Your Resend API key (e.g. `re_...`) from [Resend](https://resend.com/api-keys).
- `EMAIL_FROM`: Sender address. Default for free testing: `GridVision <onboarding@resend.dev>`.
- `DATABASE_URL`: (Optional) PostgreSQL database connection URL. If left blank, the application automatically uses the resilient local file store in `.data/auth-store.json`.

---

## Local Setup & Running

### Prerequisites
- Node.js 18+ (tested on Node v20/v24)
- Python 3.10+ (for the Django Elo engine)

### 1. Start the Django Elo Backend
From the workspace root directory:
```bash
python manage.py runserver 0.0.0.0:8000
```
This serves the calculated Elo ratings endpoint at `http://localhost:8000/api/gridvision-elo/`.

### 2. Install and Start the Next.js Frontend
From the `fp-project-v1-10` directory:
```bash
npm install # or pnpm install
npm run build
npm run start
```
The site is now live at `http://localhost:3000/`.

---

## Deployment to Vercel

The application is architected natively for Next.js on Vercel:

1. Push this repository to GitHub or GitLab.
2. In the [Vercel Dashboard](https://vercel.com/new), click **Add New Project** and import the repository.
3. Set the Root Directory to `fp-project-v1-10`.
4. In the **Environment Variables** section, add:
   - `NEXT_PUBLIC_APP_URL`: Your Vercel deployment URL (e.g. `https://your-project.vercel.app`).
   - `AUTH_SECRET`: A secure random string for HMAC session cookies.
   - `RESEND_API_KEY`: Your production Resend API key.
   - `EMAIL_FROM`: Your verified domain address (e.g. `GridVision <noreply@yourdomain.com>`).
   - `DATABASE_URL`: (Optional) A hosted PostgreSQL connection string (Neon, Supabase, or Vercel Postgres).
5. Click **Deploy**. Vercel will build and launch your application at a permanent HTTPS URL.
