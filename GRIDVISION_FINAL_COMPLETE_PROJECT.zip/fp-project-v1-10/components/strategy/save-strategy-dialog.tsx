"use client"

import React, { useState, useEffect } from "react"
import { X, Save, Copy, Loader2, AlertCircle, Bookmark } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

interface SaveStrategyDialogProps {
  isOpen: boolean
  onClose: () => void
  onSave: (name: string, notes: string) => Promise<{ success: boolean; error?: string }>
  onUpdateExisting?: (notes?: string) => Promise<{ success: boolean; error?: string }>
  isExistingStrategy: boolean
  currentName?: string
  currentNotes?: string
  summary: {
    teamName: string
    formation: string
    playerCount: number
  }
}

export function SaveStrategyDialog({
  isOpen,
  onClose,
  onSave,
  onUpdateExisting,
  isExistingStrategy,
  currentName = "",
  currentNotes = "",
  summary,
}: SaveStrategyDialogProps) {
  const [name, setName] = useState(currentName)
  const [notes, setNotes] = useState(currentNotes)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (isOpen) {
      setName(currentName || `${summary.teamName} ${summary.formation}`)
      setNotes(currentNotes || "")
      setError(null)
      setIsSubmitting(false)
    }
  }, [isOpen, currentName, currentNotes, summary.teamName, summary.formation])

  if (!isOpen) return null

  async function handleSaveNew(e: React.FormEvent) {
    e.preventDefault()
    if (!name.trim()) {
      setError("Please provide a name for this strategy.")
      return
    }

    setIsSubmitting(true)
    setError(null)
    try {
      const res = await onSave(name.trim(), notes.trim())
      if (!res.success) {
        setError(res.error || "Failed to save strategy.")
      } else {
        onClose()
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save strategy.")
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleUpdateExisting() {
    if (!onUpdateExisting) return
    setIsSubmitting(true)
    setError(null)
    try {
      const res = await onUpdateExisting(notes.trim())
      if (!res.success) {
        setError(res.error || "Failed to update strategy.")
      } else {
        onClose()
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update strategy.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md rounded-xl border border-border bg-card p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border pb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="grid size-9 place-items-center rounded-lg bg-primary/15 text-primary">
              <Bookmark className="size-4.5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-foreground">
                {isExistingStrategy ? "Save Strategy Changes" : "Save Strategy"}
              </h3>
              <p className="text-xs text-muted-foreground">
                Persist your exact lineup, roles, and pitch positions
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          >
            <X className="size-4" />
          </button>
        </div>

        {/* Setup summary chip */}
        <div className="mt-4 flex flex-wrap items-center gap-2 rounded-lg border border-border/60 bg-secondary/30 p-2.5 text-xs">
          <span className="text-muted-foreground">Lineup:</span>
          <Badge variant="outline" className="font-semibold border-primary/30 text-primary">
            {summary.teamName}
          </Badge>
          <Badge variant="secondary" className="font-mono text-[11px]">
            {summary.formation}
          </Badge>
          <span className="ml-auto font-mono text-[11px] text-muted-foreground">
            {summary.playerCount} players placed
          </span>
        </div>

        {error && (
          <div className="mt-3.5 flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">
            <AlertCircle className="size-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSaveNew} className="mt-4 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-foreground">
              Strategy Name <span className="text-destructive">*</span>
            </label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. 4-3-3 High Press & Overload"
              maxLength={80}
              disabled={isSubmitting}
              className="text-sm font-medium"
              autoFocus
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">
              Tactical Notes <span className="text-muted-foreground/60">(Optional)</span>
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add key notes, match situation, or defensive instructions..."
              rows={3}
              maxLength={300}
              disabled={isSubmitting}
              className="w-full rounded-md border border-input bg-transparent px-3 py-2 text-xs shadow-xs placeholder:text-muted-foreground focus-visible:outline-hidden focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
            />
          </div>

          <div className="mt-6 flex flex-col sm:flex-row gap-2 pt-2 border-t border-border">
            {isExistingStrategy ? (
              <>
                <Button
                  type="button"
                  variant="default"
                  onClick={handleUpdateExisting}
                  disabled={isSubmitting}
                  className="flex-1 gap-2 font-semibold"
                >
                  {isSubmitting ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                  Update &quot;{currentName}&quot;
                </Button>
                <Button
                  type="submit"
                  variant="outline"
                  disabled={isSubmitting}
                  className="gap-2 text-xs"
                >
                  <Copy className="size-3.5" />
                  Save as New Copy
                </Button>
              </>
            ) : (
              <>
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  disabled={isSubmitting}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="default"
                  disabled={isSubmitting}
                  className="flex-1 gap-2 font-semibold"
                >
                  {isSubmitting ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                  Save Strategy
                </Button>
              </>
            )}
          </div>
        </form>
      </div>
    </div>
  )
}
