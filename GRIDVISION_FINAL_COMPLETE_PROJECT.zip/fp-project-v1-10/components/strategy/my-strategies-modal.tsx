"use client"

import React, { useState } from "react"
import {
  X,
  Search,
  FolderOpen,
  Pencil,
  Copy,
  Trash2,
  Calendar,
  Clock,
  Check,
  Loader2,
  Layers,
  FileText,
  AlertCircle,
  Plus,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import type { SavedStrategyRecord } from "@/lib/db/strategy-store"

interface MyStrategiesModalProps {
  isOpen: boolean
  onClose: () => void
  strategies: SavedStrategyRecord[]
  activeStrategyId: string | null
  onLoadStrategy: (strategy: SavedStrategyRecord) => void
  onRenameStrategy: (id: string, newName: string, notes?: string) => Promise<{ success: boolean; error?: string }>
  onDuplicateStrategy: (id: string) => Promise<{ success: boolean; error?: string }>
  onDeleteRequest: (strategy: SavedStrategyRecord) => void
  isLoading?: boolean
}

export function MyStrategiesModal({
  isOpen,
  onClose,
  strategies,
  activeStrategyId,
  onLoadStrategy,
  onRenameStrategy,
  onDuplicateStrategy,
  onDeleteRequest,
  isLoading = false,
}: MyStrategiesModalProps) {
  const [search, setSearch] = useState("")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState("")
  const [editNotes, setEditNotes] = useState("")
  const [actionInProgress, setActionInProgress] = useState<string | null>(null)
  const [feedback, setFeedback] = useState<{ text: string; type: "success" | "error" } | null>(null)

  if (!isOpen) return null

  const filtered = strategies.filter((s) => {
    const q = search.trim().toLowerCase()
    if (!q) return true
    return (
      s.name.toLowerCase().includes(q) ||
      s.teamName.toLowerCase().includes(q) ||
      s.formation.toLowerCase().includes(q) ||
      (s.notes && s.notes.toLowerCase().includes(q))
    )
  })

  function startRename(s: SavedStrategyRecord) {
    setEditingId(s.id)
    setEditName(s.name)
    setEditNotes(s.notes || "")
    setFeedback(null)
  }

  async function handleSaveRename(id: string) {
    if (!editName.trim()) {
      setFeedback({ text: "Strategy name cannot be empty.", type: "error" })
      return
    }

    setActionInProgress(`rename-${id}`)
    try {
      const res = await onRenameStrategy(id, editName.trim(), editNotes.trim())
      if (res.success) {
        setEditingId(null)
        setFeedback({ text: "Strategy renamed successfully.", type: "success" })
      } else {
        setFeedback({ text: res.error || "Failed to rename.", type: "error" })
      }
    } catch (err) {
      setFeedback({ text: err instanceof Error ? err.message : "Failed to rename.", type: "error" })
    } finally {
      setActionInProgress(null)
    }
  }

  async function handleDuplicate(id: string) {
    setActionInProgress(`dup-${id}`)
    setFeedback(null)
    try {
      const res = await onDuplicateStrategy(id)
      if (res.success) {
        setFeedback({ text: "Strategy duplicated successfully.", type: "success" })
      } else {
        setFeedback({ text: res.error || "Failed to duplicate.", type: "error" })
      }
    } catch (err) {
      setFeedback({ text: err instanceof Error ? err.message : "Failed to duplicate.", type: "error" })
    } finally {
      setActionInProgress(null)
    }
  }

  function formatDate(iso: string) {
    try {
      const d = new Date(iso)
      return d.toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    } catch {
      return iso
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-4 backdrop-blur-xs">
      <div className="relative flex flex-col w-full max-w-2xl max-h-[85vh] rounded-xl border border-border bg-card shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="grid size-9 place-items-center rounded-lg bg-primary/15 text-primary">
              <Layers className="size-4.5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-foreground">My Saved Strategies</h3>
                <Badge variant="secondary" className="font-mono text-xs">
                  {strategies.length}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">
                Load, duplicate, update, or manage your saved tactical setups
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          >
            <X className="size-4" />
          </button>
        </div>

        {/* Search & feedback toolbar */}
        <div className="border-b border-border bg-secondary/20 px-5 py-3 space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by strategy name, club, or formation..."
              className="h-8 pl-8 text-xs bg-background"
            />
          </div>

          {feedback && (
            <div
              className={`flex items-center justify-between rounded-md px-3 py-1.5 text-xs ${
                feedback.type === "success"
                  ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                  : "bg-destructive/10 text-destructive border border-destructive/30"
              }`}
            >
              <span>{feedback.text}</span>
              <button
                onClick={() => setFeedback(null)}
                className="hover:opacity-75"
              >
                <X className="size-3" />
              </button>
            </div>
          )}
        </div>

        {/* List of strategies */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3 [scrollbar-width:thin]">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-16 gap-2 text-muted-foreground">
              <Loader2 className="size-6 animate-spin text-primary" />
              <p className="text-xs">Loading your saved strategies...</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center text-muted-foreground gap-2">
              <Layers className="size-8 stroke-[1.5] text-muted-foreground/60" />
              {search.trim() ? (
                <>
                  <p className="text-sm font-medium text-foreground">No matches found</p>
                  <p className="text-xs">No strategies match &quot;{search}&quot;.</p>
                </>
              ) : (
                <>
                  <p className="text-sm font-medium text-foreground">No saved strategies yet</p>
                  <p className="text-xs max-w-xs">
                    Build a lineup on the pitch and click &quot;Save Strategy&quot; to preserve your exact tactical plan and player positions.
                  </p>
                </>
              )}
            </div>
          ) : (
            filtered.map((s) => {
              const isActive = s.id === activeStrategyId
              const isEditing = editingId === s.id
              const isDuping = actionInProgress === `dup-${s.id}`
              const isRenaming = actionInProgress === `rename-${s.id}`

              return (
                <div
                  key={s.id}
                  className={`relative rounded-lg border p-3.5 sm:p-4 transition-all ${
                    isActive
                      ? "border-primary/60 bg-primary/5 shadow-xs"
                      : "border-border/70 bg-card hover:border-border hover:bg-secondary/20"
                  }`}
                >
                  {isEditing ? (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-foreground">Strategy Name</label>
                        <Input
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="h-8 text-xs font-medium"
                          autoFocus
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-medium text-muted-foreground">Notes</label>
                        <textarea
                          value={editNotes}
                          onChange={(e) => setEditNotes(e.target.value)}
                          rows={2}
                          className="w-full rounded-md border border-input bg-transparent px-2.5 py-1.5 text-xs shadow-xs focus-visible:outline-hidden focus-visible:ring-1 focus-visible:ring-ring"
                        />
                      </div>
                      <div className="flex items-center gap-2 justify-end">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditingId(null)}
                          disabled={isRenaming}
                          className="h-7 text-xs"
                        >
                          Cancel
                        </Button>
                        <Button
                          size="sm"
                          variant="default"
                          onClick={() => handleSaveRename(s.id)}
                          disabled={isRenaming}
                          className="h-7 text-xs gap-1 font-semibold"
                        >
                          {isRenaming ? <Loader2 className="size-3 animate-spin" /> : <Check className="size-3" />}
                          Save Changes
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-1.5 min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h4 className="text-sm font-bold text-foreground truncate">{s.name}</h4>
                          {isActive && (
                            <Badge className="bg-primary/20 text-primary border-primary/40 text-[10px] font-semibold px-1.5 py-0">
                              Currently Loaded
                            </Badge>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                          <Badge variant="outline" className="border-border text-[11px] font-medium">
                            {s.teamName}
                          </Badge>
                          <Badge variant="secondary" className="font-mono text-[11px]">
                            {s.formation}
                          </Badge>
                          <span className="flex items-center gap-1 font-mono text-[11px]">
                            <Clock className="size-3 text-muted-foreground" />
                            {formatDate(s.updatedAt)}
                          </span>
                        </div>

                        {s.notes && (
                          <p className="text-xs text-muted-foreground/90 line-clamp-2 leading-relaxed bg-secondary/30 rounded p-1.5 mt-1 border border-border/40">
                            {s.notes}
                          </p>
                        )}
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                        <Button
                          type="button"
                          size="sm"
                          variant={isActive ? "secondary" : "default"}
                          onClick={() => {
                            onLoadStrategy(s)
                            onClose()
                          }}
                          className="h-8 gap-1.5 text-xs font-semibold px-3"
                        >
                          <FolderOpen className="size-3.5" />
                          {isActive ? "Reload" : "Open"}
                        </Button>

                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          onClick={() => startRename(s)}
                          title="Rename strategy"
                          className="size-8 text-muted-foreground hover:text-foreground"
                        >
                          <Pencil className="size-3.5" />
                        </Button>

                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          onClick={() => handleDuplicate(s.id)}
                          disabled={isDuping}
                          title="Duplicate strategy"
                          className="size-8 text-muted-foreground hover:text-foreground"
                        >
                          {isDuping ? <Loader2 className="size-3.5 animate-spin" /> : <Copy className="size-3.5" />}
                        </Button>

                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          onClick={() => onDeleteRequest(s)}
                          title="Delete strategy"
                          className="size-8 text-destructive/80 hover:text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="size-3.5" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )
            })
          )}
        </div>
      </div>
    </div>
  )
}
