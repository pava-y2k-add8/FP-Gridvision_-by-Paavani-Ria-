"use client"

import { useEffect, useRef, useState } from "react"
import { Send, Loader2, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"

export interface ChatMessage {
  role: "user" | "assistant"
  content: string
}

const PROMPTS = [
  "How should we set up out of possession?",
  "Who is my weak link and how do I cover them?",
  "Suggest a change to score more goals.",
]

export function StrategyChat({
  messages,
  loading,
  disabled,
  onSend,
}: {
  messages: ChatMessage[]
  loading: boolean
  disabled?: boolean
  onSend: (text: string) => void
}) {
  const [value, setValue] = useState("")
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" })
  }, [messages, loading])

  function submit() {
    const text = value.trim()
    if (!text || loading || disabled) return
    onSend(text)
    setValue("")
  }

  return (
    <div className="flex min-h-[300px] h-[340px] sm:h-[400px] md:h-[420px] flex-col">
      <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto pr-1 [scrollbar-width:thin]">
        {messages.length === 0 && !loading && (
          <div className="grid h-full place-items-center gap-3 p-2 text-center">
            <MessageSquare className="size-7 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Talk tactics with GridVision</p>
              <p className="mt-0.5 text-xs text-muted-foreground">Ask about your XI, matchups or adjustments.</p>
            </div>
            <div className="flex flex-wrap justify-center gap-1.5 max-w-md">
              {PROMPTS.map((p) => (
                <button
                  key={p}
                  type="button"
                  disabled={disabled}
                  onClick={() => onSend(p)}
                  className="rounded-full border border-border bg-secondary/50 px-2.5 py-1 text-[11px] text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground disabled:opacity-50 text-left sm:text-center"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-3.5 py-2 text-[13px] leading-relaxed ${
                m.role === "user"
                  ? "rounded-br-sm bg-primary text-primary-foreground"
                  : "rounded-bl-sm bg-secondary text-foreground"
              }`}
            >
              {m.content}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="flex items-center gap-2 rounded-2xl rounded-bl-sm bg-secondary px-3.5 py-2 text-[13px] text-muted-foreground">
              <Loader2 className="size-3.5 animate-spin" /> Thinking…
            </div>
          </div>
        )}
      </div>

      <div className="mt-3 flex items-end gap-2">
        <textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              if (e.nativeEvent.isComposing || e.keyCode === 229) return
              e.preventDefault()
              submit()
            }
          }}
          rows={1}
          disabled={disabled}
          placeholder={disabled ? "Generate a strategy first…" : "Ask about your game plan…"}
          className="max-h-28 min-h-9 flex-1 resize-none rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
        />
        <Button size="icon" onClick={submit} disabled={loading || disabled || !value.trim()} className="size-9 shrink-0">
          <Send className="size-4" />
        </Button>
      </div>
    </div>
  )
}
