import type { LucideIcon } from "lucide-react"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

export function StatCard({
  icon: Icon,
  label,
  value,
  unit,
  hint,
  accent = "primary",
}: {
  icon: LucideIcon
  label: string
  value: string | number
  unit?: string
  hint?: string
  accent?: "primary" | "accent" | "chart-3" | "destructive"
}) {
  const accentClass = {
    primary: "text-primary bg-primary/10",
    accent: "text-[var(--color-accent)] bg-[var(--color-accent)]/10",
    "chart-3": "text-[var(--color-chart-3)] bg-[var(--color-chart-3)]/10",
    destructive: "text-destructive bg-destructive/10",
  }[accent]

  return (
    <Card className="gap-0 p-4">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground">{label}</span>
        <span className={cn("grid size-8 place-items-center rounded-md", accentClass)}>
          <Icon className="size-4" />
        </span>
      </div>
      <div className="mt-3 flex items-baseline gap-1">
        <span className="font-mono text-2xl font-semibold tabular-nums">{value}</span>
        {unit ? <span className="text-sm text-muted-foreground">{unit}</span> : null}
      </div>
      {hint ? <p className="mt-1 text-xs text-muted-foreground">{hint}</p> : null}
    </Card>
  )
}
