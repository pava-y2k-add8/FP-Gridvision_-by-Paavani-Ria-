"use client"

import type React from "react"
import { useState } from "react"
import { Sparkles, Loader2, Send } from "lucide-react"
import { Button } from "@/components/ui/button"

const SUGGESTIONS = [
  "How do I beat a low block?",
  "When should I press high vs sit deep?",
  "Best formation for a fast counter-attack?",
]

export function GeminiQuickAsk() {
  const [question, setQuestion] = useState("")
  const [answer, setAnswer] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function ask(text: string) {
    const q = text.trim()
    if (!q || loading) return
    setLoading(true)
    setAnswer(null)
    try {
      const res = await fetch("/api/strategy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "ask", question: q }),
      })
      const data = await res.json()
      setAnswer(data.text ?? data.error ?? "No response.")
    } catch {
      setAnswer("Could not reach Gemini. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && !e.nativeEvent.isComposing && e.keyCode !== 229) {
      e.preventDefault()
      ask(question)
    }
  }

  return (
    <div className="mt-2 w-full max-w-xl space-y-3 text-left">
      <div className="flex items-center justify-center gap-1.5 text-[11px] font-medium text-muted-foreground">
        <Sparkles className="size-3.5 text-primary" />
        Ask GridVision AI anything while you decide — powered by Gemini
      </div>

      <div className="flex items-center gap-2">
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder="Ask a tactics question…"
          aria-label="Ask a tactics question"
          className="h-9 flex-1 rounded-lg border border-border bg-background px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
        />
        <Button onClick={() => ask(question)} disabled={loading || !question.trim()} size="sm" className="gap-1.5">
          {loading ? <Loader2 className="size-3.5 animate-spin" /> : <Send className="size-3.5" />}
          Ask
        </Button>
      </div>

      {!answer && !loading && (
        <div className="flex flex-wrap justify-center gap-1.5">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => {
                setQuestion(s)
                ask(s)
              }}
              className="rounded-full border border-border bg-secondary/40 px-2.5 py-1 text-[11px] text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {loading && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="size-4 animate-spin" /> Gemini is thinking…
        </div>
      )}

      {!loading && answer && (
        <div className="space-y-1.5 rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm leading-relaxed text-foreground/90">
          <p className="font-mono text-[11px] uppercase tracking-wide text-primary">Gemini · GridVision</p>
          {answer.split("\n").filter(Boolean).map((line, i) => (
            <p key={i}>{line}</p>
          ))}
        </div>
      )}
    </div>
  )
}
