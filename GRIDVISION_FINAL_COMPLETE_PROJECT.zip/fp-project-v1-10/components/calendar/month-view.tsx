"use client"

import React from "react"
import { FixtureRecord, CalendarEventRecord } from "@/lib/db/calendar-store"
import { Plus, Clock, Users, FileText, AlertTriangle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface MonthViewProps {
  currentDate: Date
  fixtures: FixtureRecord[]
  events: CalendarEventRecord[]
  onSelectFixture: (f: FixtureRecord) => void
  onSelectEvent: (e: CalendarEventRecord) => void
  onCreateEventOnDate: (date: Date) => void
}

const COMPETITION_NAMES: Record<string, string> = {
  "world-cup": "FIFA World Cup",
  "premier-league": "Premier League",
  "la-liga": "La Liga",
  "serie-a": "Serie A",
}

const COMPETITION_COLORS: Record<string, { bg: string; text: string; border: string; dot: string }> = {
  "world-cup": {
    bg: "bg-amber-500/10 hover:bg-amber-500/20",
    text: "text-amber-300",
    border: "border-amber-500/30",
    dot: "bg-amber-400",
  },
  "premier-league": {
    bg: "bg-purple-500/10 hover:bg-purple-500/20",
    text: "text-purple-300",
    border: "border-purple-500/30",
    dot: "bg-purple-400",
  },
  "la-liga": {
    bg: "bg-red-500/10 hover:bg-red-500/20",
    text: "text-red-300",
    border: "border-red-500/30",
    dot: "bg-red-400",
  },
  "serie-a": {
    bg: "bg-blue-500/10 hover:bg-blue-500/20",
    text: "text-blue-300",
    border: "border-blue-500/30",
    dot: "bg-blue-400",
  },
}

export function MonthView({
  currentDate,
  fixtures,
  events,
  onSelectFixture,
  onSelectEvent,
  onCreateEventOnDate,
}: MonthViewProps) {
  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()

  const firstDayOfMonth = new Date(year, month, 1)
  const lastDayOfMonth = new Date(year, month + 1, 0)

  const startingDayIndex = firstDayOfMonth.getDay() // 0 = Sun, 1 = Mon ...
  const daysInMonth = lastDayOfMonth.getDate()

  const prevMonthLastDay = new Date(year, month, 0).getDate()

  // Generate 42 cells (6 rows x 7 days)
  const calendarCells = []

  // Prev month padding
  for (let i = startingDayIndex - 1; i >= 0; i--) {
    const d = new Date(year, month - 1, prevMonthLastDay - i)
    calendarCells.push({ date: d, isCurrentMonth: false })
  }

  // Current month days
  for (let day = 1; day <= daysInMonth; day++) {
    const d = new Date(year, month, day)
    calendarCells.push({ date: d, isCurrentMonth: true })
  }

  // Next month padding to fill up to 35 or 42 cells
  const remaining = (7 - (calendarCells.length % 7)) % 7
  for (let day = 1; day <= remaining; day++) {
    const d = new Date(year, month + 1, day)
    calendarCells.push({ date: d, isCurrentMonth: false })
  }

  const todayStr = new Date().toDateString()

  // Group items by date string (YYYY-MM-DD)
  const getItemsForDay = (cellDate: Date) => {
    const y = cellDate.getFullYear()
    const m = String(cellDate.getMonth() + 1).padStart(2, "0")
    const d = String(cellDate.getDate()).padStart(2, "0")
    const key = `${y}-${m}-${d}`

    const dayFixtures = fixtures.filter((f) => {
      try {
        const fDate = new Date(f.kickoffTime)
        const fy = fDate.getFullYear()
        const fm = String(fDate.getMonth() + 1).padStart(2, "0")
        const fd = String(fDate.getDate()).padStart(2, "0")
        return `${fy}-${fm}-${fd}` === key
      } catch {
        return false
      }
    })

    const dayEvents = events.filter((e) => {
      try {
        const eDate = new Date(e.startDate)
        const ey = eDate.getFullYear()
        const em = String(eDate.getMonth() + 1).padStart(2, "0")
        const ed = String(eDate.getDate()).padStart(2, "0")
        return `${ey}-${em}-${ed}` === key
      } catch {
        return false
      }
    })

    return { dayFixtures, dayEvents }
  }

  const formatLocalTime = (iso: string) => {
    try {
      return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } catch {
      return ""
    }
  }

  const WEEK_DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  return (
    <div className="flex flex-col bg-background">
      {/* Weekday Labels Header */}
      <div className="grid grid-cols-7 border-b border-border bg-secondary/30 text-center text-xs font-semibold text-muted-foreground py-2.5">
        {WEEK_DAYS.map((day) => (
          <div key={day} className="tracking-wide">
            {day}
          </div>
        ))}
      </div>

      {/* Grid of Days */}
      <div className="grid grid-cols-7 auto-rows-fr border-l border-t border-border">
        {calendarCells.map((cell, idx) => {
          const isToday = cell.date.toDateString() === todayStr
          const { dayFixtures, dayEvents } = getItemsForDay(cell.date)
          const totalItems = dayFixtures.length + dayEvents.length

          return (
            <div
              key={idx}
              className={`group relative min-h-[110px] md:min-h-[135px] border-b border-r border-border p-1.5 transition-colors flex flex-col ${
                cell.isCurrentMonth
                  ? "bg-card/40 hover:bg-card/80"
                  : "bg-background/40 text-muted-foreground/40"
              }`}
            >
              {/* Day Header with Date Number and Add Button */}
              <div className="flex items-center justify-between mb-1">
                <span
                  className={`grid size-6 place-items-center rounded-full text-xs font-semibold ${
                    isToday
                      ? "bg-primary text-primary-foreground shadow-xs ring-2 ring-primary/40 font-bold"
                      : cell.isCurrentMonth
                      ? "text-foreground"
                      : "text-muted-foreground/50"
                  }`}
                >
                  {cell.date.getDate()}
                </span>

                {/* Quick Add Event on hover */}
                <button
                  onClick={() => onCreateEventOnDate(cell.date)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity p-0.5 rounded-sm hover:bg-secondary text-muted-foreground hover:text-foreground"
                  title="Add event on this day"
                >
                  <Plus className="size-3.5" />
                </button>
              </div>

              {/* Day Items List */}
              <div className="flex-1 space-y-1 overflow-y-auto max-h-[85px] md:max-h-[105px] [scrollbar-width:none]">
                {/* Official Fixtures */}
                {dayFixtures.slice(0, 3).map((f) => {
                  const style = COMPETITION_COLORS[f.competition] || {
                    bg: "bg-primary/10",
                    text: "text-primary",
                    border: "border-primary/20",
                    dot: "bg-primary",
                  }
                  const isFinished = f.status === "FINISHED"
                  const isPostponed = f.status === "POSTPONED"
                  const isLive = f.status === "LIVE"

                  return (
                    <div
                      key={f.id}
                      onClick={() => onSelectFixture(f)}
                      className={`cursor-pointer rounded-md border p-1 text-[11px] leading-tight transition-all truncate flex items-center gap-1.5 ${style.bg} ${style.border}`}
                      title={`${f.homeTeam} vs ${f.awayTeam} · ${COMPETITION_NAMES[f.competition] || f.competition} (${f.round}) - ${f.status}`}
                    >
                      <span className={`size-1.5 shrink-0 rounded-full ${style.dot}`} />
                      <div className="min-w-0 flex-1 truncate font-medium">
                        <span className={style.text}>
                          {f.homeTeam.split(" ")[0]} v {f.awayTeam.split(" ")[0]}
                        </span>
                      </div>
                      <span className="shrink-0 text-[10px] text-muted-foreground font-mono">
                        {isFinished
                          ? `${f.homeScore}-${f.awayScore}`
                          : isPostponed
                          ? "PSTP"
                          : isLive
                          ? "LIVE"
                          : formatLocalTime(f.kickoffTime)}
                      </span>
                    </div>
                  )
                })}

                {/* Personal & Shared Events */}
                {dayEvents.slice(0, 2).map((ev) => {
                  const isShared = ev.visibility === "shared"
                  return (
                    <div
                      key={ev.id}
                      onClick={() => onSelectEvent(ev)}
                      className="cursor-pointer rounded-md border border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20 p-1 text-[11px] leading-tight transition-all truncate flex items-center gap-1.5 text-emerald-300"
                      title={`${ev.title} (${isShared ? "Shared Event" : "Personal Note"})`}
                    >
                      {isShared ? (
                        <Users className="size-3 shrink-0 text-indigo-400" />
                      ) : (
                        <FileText className="size-3 shrink-0 text-emerald-400" />
                      )}
                      <span className="truncate font-medium">{ev.title}</span>
                    </div>
                  )
                })}

                {/* Overflow count */}
                {totalItems > 3 && (
                  <div
                    onClick={() => onCreateEventOnDate(cell.date)}
                    className="cursor-pointer text-[10px] text-muted-foreground hover:text-foreground text-center font-medium pt-0.5"
                  >
                    +{totalItems - 3} more
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
