"use client"

import React from "react"
import { Search, Trophy, Filter, X, ShieldAlert, Sparkles, UserCheck } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export interface CalendarFilterState {
  competition: string // "all" | "world-cup" | "premier-league" | "la-liga" | "serie-a"
  team: string
  type: string // "all" | "fixtures" | "personal" | "shared"
  status: string // "all" | "SCHEDULED" | "LIVE" | "FINISHED" | "POSTPONED"
}

interface CalendarFiltersProps {
  filters: CalendarFilterState
  onChange: (updated: Partial<CalendarFilterState>) => void
  onReset: () => void
  teamsList: string[]
  fixturesCount: number
  eventsCount: number
  isLoggedIn: boolean
}

const COMPETITIONS = [
  { id: "all", label: "All Competitions", short: "ALL" },
  { id: "world-cup", label: "FIFA World Cup", short: "WC 2026", color: "from-amber-500/20 to-emerald-500/20 text-amber-300 border-amber-500/40" },
  { id: "premier-league", label: "Premier League", short: "PL", color: "from-purple-500/20 to-cyan-500/20 text-purple-300 border-purple-500/40" },
  { id: "la-liga", label: "La Liga", short: "ESP", color: "from-red-500/20 to-yellow-500/20 text-red-300 border-red-500/40" },
  { id: "serie-a", label: "Serie A", short: "ITA", color: "from-blue-500/20 to-emerald-500/20 text-blue-300 border-blue-500/40" },
]

export function CalendarFilters({
  filters,
  onChange,
  onReset,
  teamsList,
  fixturesCount,
  eventsCount,
  isLoggedIn,
}: CalendarFiltersProps) {
  const hasActiveFilters =
    filters.competition !== "all" ||
    filters.team !== "" ||
    filters.type !== "all" ||
    filters.status !== "all"

  return (
    <div className="space-y-3 bg-card/60 p-4 border-b border-border">
      {/* Competitions Row */}
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-xs font-semibold text-muted-foreground mr-1 flex items-center gap-1">
          <Trophy className="size-3.5 text-primary" />
          <span>Competition:</span>
        </span>
        {COMPETITIONS.map((c) => {
          const active = filters.competition === c.id
          return (
            <button
              key={c.id}
              onClick={() => onChange({ competition: c.id })}
              className={`rounded-full px-3 py-1 text-xs font-medium transition-all ${
                active
                  ? "bg-primary text-primary-foreground shadow-sm scale-105"
                  : "bg-secondary/60 text-muted-foreground hover:bg-secondary hover:text-foreground border border-border/40"
              }`}
            >
              {c.label}
            </button>
          )
        })}
      </div>

      {/* Second Row: Team Search, Type Filter, Status Filter */}
      <div className="flex flex-wrap items-center gap-2.5">
        {/* Team Search Input */}
        <div className="relative min-w-[200px] flex-1 sm:max-w-xs">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
          <Input
            value={filters.team}
            onChange={(e) => onChange({ team: e.target.value })}
            placeholder="Filter by team (e.g. Arsenal, Real Madrid, Brazil)..."
            className="pl-8 text-xs h-8 bg-secondary/40 border-border"
          />
          {filters.team && (
            <button
              onClick={() => onChange({ team: "" })}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="size-3" />
            </button>
          )}
        </div>

        {/* Event Type Filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-muted-foreground font-medium">Type:</span>
          <select
            value={filters.type}
            onChange={(e) => onChange({ type: e.target.value })}
            className="rounded-md border border-border bg-secondary/50 px-2 py-1 text-xs text-foreground focus:outline-hidden focus:ring-1 focus:ring-primary"
          >
            <option value="all">All Items ({fixturesCount + eventsCount})</option>
            <option value="fixtures">Official Fixtures ({fixturesCount})</option>
            <option value="personal">My Notes & Events ({eventsCount})</option>
            {isLoggedIn && <option value="shared">Shared With Me</option>}
          </select>
        </div>

        {/* Match Status Filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-muted-foreground font-medium">Status:</span>
          <select
            value={filters.status}
            onChange={(e) => onChange({ status: e.target.value })}
            className="rounded-md border border-border bg-secondary/50 px-2 py-1 text-xs text-foreground focus:outline-hidden focus:ring-1 focus:ring-primary"
          >
            <option value="all">All Match Statuses</option>
            <option value="SCHEDULED">Upcoming / Scheduled</option>
            <option value="LIVE">Live Now</option>
            <option value="FINISHED">Completed / Results</option>
            <option value="POSTPONED">Postponed</option>
          </select>
        </div>

        {/* Reset Filter Button */}
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onReset}
            className="h-8 px-2 text-xs text-muted-foreground hover:text-foreground hover:bg-secondary/60"
          >
            <X className="size-3 mr-1" />
            Reset Filters
          </Button>
        )}
      </div>
    </div>
  )
}
