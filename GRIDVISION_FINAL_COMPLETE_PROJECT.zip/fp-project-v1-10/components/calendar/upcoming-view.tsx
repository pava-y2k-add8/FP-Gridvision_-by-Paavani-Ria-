"use client"

import React from "react"
import { FixtureRecord, CalendarEventRecord } from "@/lib/db/calendar-store"
import {
  CalendarDays,
  Clock,
  MapPin,
  ShieldCheck,
  AlertTriangle,
  Users,
  FileText,
  Plus,
  ArrowRight,
  Sparkles,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface UpcomingViewProps {
  fixtures: FixtureRecord[]
  events: CalendarEventRecord[]
  onSelectFixture: (f: FixtureRecord) => void
  onSelectEvent: (e: CalendarEventRecord) => void
  onAddNoteForFixture: (f: FixtureRecord) => void
}

const COMPETITION_CONFIG: Record<string, { label: string; badge: string }> = {
  "world-cup": { label: "FIFA World Cup", badge: "border-amber-500/30 bg-amber-500/10 text-amber-300" },
  "premier-league": { label: "Premier League", badge: "border-purple-500/30 bg-purple-500/10 text-purple-300" },
  "la-liga": { label: "La Liga", badge: "border-red-500/30 bg-red-500/10 text-red-300" },
  "serie-a": { label: "Serie A", badge: "border-blue-500/30 bg-blue-500/10 text-blue-300" },
}

export function UpcomingView({
  fixtures,
  events,
  onSelectFixture,
  onSelectEvent,
  onAddNoteForFixture,
}: UpcomingViewProps) {
  // Merge items and sort chronologically
  interface UnifiedItem {
    type: "fixture" | "event"
    date: Date
    fixture?: FixtureRecord
    event?: CalendarEventRecord
  }

  const items: UnifiedItem[] = []

  for (const f of fixtures) {
    items.push({
      type: "fixture",
      date: new Date(f.kickoffTime),
      fixture: f,
    })
  }

  for (const ev of events) {
    items.push({
      type: "event",
      date: new Date(ev.startDate),
      event: ev,
    })
  }

  items.sort((a, b) => a.date.getTime() - b.date.getTime())

  // Group by Date string
  const grouped = new Map<string, UnifiedItem[]>()
  for (const item of items) {
    const dateKey = item.date.toLocaleDateString("default", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
    const existing = grouped.get(dateKey) || []
    existing.push(item)
    grouped.set(dateKey, existing)
  }

  const getRelativeBadge = (targetDate: Date) => {
    const now = new Date()
    const diffMs = targetDate.getTime() - now.getTime()
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24))

    if (targetDate.toDateString() === now.toDateString()) {
      return <Badge className="bg-emerald-500 text-white hover:bg-emerald-600">Today</Badge>
    }
    if (diffDays === 1) {
      return <Badge className="bg-primary text-primary-foreground">Tomorrow</Badge>
    }
    if (diffDays > 1 && diffDays <= 7) {
      return <Badge variant="secondary">In {diffDays} days</Badge>
    }
    if (diffDays > 7 && diffDays <= 30) {
      return <Badge variant="outline">In {Math.round(diffDays / 7)} weeks</Badge>
    }
    if (diffDays < 0) {
      return <Badge variant="outline" className="text-muted-foreground">Past</Badge>
    }
    return <Badge variant="outline">{targetDate.toLocaleDateString()}</Badge>
  }

  const formatLocalTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + " (" + Intl.DateTimeFormat().resolvedOptions().timeZone + ")"
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <div className="grid size-12 place-items-center rounded-full bg-secondary text-muted-foreground mb-3">
          <CalendarDays className="size-6" />
        </div>
        <h3 className="text-base font-semibold">No fixtures or events found</h3>
        <p className="text-xs text-muted-foreground mt-1 max-w-sm">
          No matches match your current filters. Try resetting the competition or team filters to view upcoming fixtures.
        </p>
      </div>
    )
  }

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-5xl mx-auto">
      {Array.from(grouped.entries()).map(([dateLabel, dayItems]) => (
        <div key={dateLabel} className="space-y-3">
          {/* Date Header */}
          <div className="flex items-center justify-between border-b border-border pb-2">
            <h2 className="text-sm md:text-base font-bold text-foreground flex items-center gap-2">
              <CalendarDays className="size-4 text-primary" />
              <span>{dateLabel}</span>
            </h2>
            {getRelativeBadge(dayItems[0].date)}
          </div>

          {/* Items for this date */}
          <div className="grid gap-3">
            {dayItems.map((item, idx) => {
              if (item.type === "fixture" && item.fixture) {
                const f = item.fixture
                const comp = COMPETITION_CONFIG[f.competition] || {
                  label: f.competition,
                  badge: "border-border bg-secondary text-foreground",
                }
                const isPostponed = f.status === "POSTPONED"
                const isLive = f.status === "LIVE"
                const isFinished = f.status === "FINISHED"

                // Check if user has personal notes linked to this fixture
                const linkedNotes = events.filter((e) => e.linkedFixtureId === f.id)

                return (
                  <div
                    key={f.id}
                    className="rounded-xl border border-border bg-card/80 hover:bg-card p-4 transition-all hover:border-primary/50 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    {/* Left: Competition, Teams, Venue */}
                    <div className="space-y-2 flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline" className={`text-xs py-0.5 px-2 ${comp.badge}`}>
                          {comp.label}
                        </Badge>
                        <span className="text-xs text-muted-foreground font-medium">
                          {f.round}
                        </span>
                        {isPostponed && (
                          <Badge variant="outline" className="border-amber-500/40 bg-amber-500/10 text-amber-400 text-xs">
                            <AlertTriangle className="size-3 mr-1" /> Postponed
                          </Badge>
                        )}
                        {isLive && (
                          <Badge className="bg-emerald-500 text-white animate-pulse text-xs">
                            ● LIVE
                          </Badge>
                        )}
                        {isFinished && (
                          <Badge variant="secondary" className="text-xs font-mono">
                            Final Score: {f.homeScore} - {f.awayScore}
                          </Badge>
                        )}
                      </div>

                      {/* Teams Matchup Header */}
                      <div className="flex items-center gap-3">
                        <div className="text-base md:text-lg font-bold text-foreground">
                          <span>{f.homeTeam}</span>
                          <span className="text-muted-foreground font-normal mx-2">vs</span>
                          <span>{f.awayTeam}</span>
                        </div>
                      </div>

                      {/* Venue and Kickoff Time */}
                      <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1 font-mono text-foreground font-medium">
                          <Clock className="size-3.5 text-primary" />
                          {formatLocalTime(item.date)}
                        </span>
                        {f.venue && (
                          <span className="flex items-center gap-1">
                            <MapPin className="size-3.5" />
                            {f.venue}
                          </span>
                        )}
                        <span className="flex items-center gap-1 text-[11px] text-muted-foreground/80">
                          <ShieldCheck className="size-3 text-emerald-400" />
                          <span>{f.source}</span>
                        </span>
                      </div>

                      {/* Linked Personal Notes (if any) */}
                      {linkedNotes.length > 0 && (
                        <div className="mt-2 space-y-1">
                          {linkedNotes.map((n) => (
                            <div
                              key={n.id}
                              onClick={() => onSelectEvent(n)}
                              className="cursor-pointer rounded-md border border-emerald-500/20 bg-emerald-500/5 p-2 text-xs flex items-center gap-2 text-emerald-300 hover:bg-emerald-500/10"
                            >
                              <FileText className="size-3.5 text-emerald-400 shrink-0" />
                              <span className="font-semibold">{n.title}:</span>
                              <span className="text-muted-foreground truncate">{n.description}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Right: Actions */}
                    <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onAddNoteForFixture(f)}
                        className="text-xs h-8 border-border hover:bg-secondary flex items-center gap-1"
                        title="Add private tactical or scouting note for this match"
                      >
                        <Plus className="size-3.5 text-primary" />
                        <span>Add Note</span>
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => onSelectFixture(f)}
                        className="text-xs h-8 flex items-center gap-1"
                      >
                        <span>Details</span>
                        <ArrowRight className="size-3.5" />
                      </Button>
                    </div>
                  </div>
                )
              }

              if (item.type === "event" && item.event) {
                const ev = item.event
                const isShared = ev.visibility === "shared"

                return (
                  <div
                    key={ev.id}
                    onClick={() => onSelectEvent(ev)}
                    className="cursor-pointer rounded-xl border border-emerald-500/30 bg-emerald-500/5 hover:bg-emerald-500/10 p-4 transition-all shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3"
                  >
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2">
                        <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/40 text-xs">
                          {isShared ? (
                            <span className="flex items-center gap-1">
                              <Users className="size-3 text-indigo-400" />
                              Shared Event
                            </span>
                          ) : (
                            <span className="flex items-center gap-1">
                              <FileText className="size-3" />
                              Personal Note
                            </span>
                          )}
                        </Badge>
                        <span className="text-xs text-muted-foreground capitalize">
                          {ev.eventType.replace("_", " ")}
                        </span>
                      </div>
                      <h4 className="text-base font-bold text-foreground">{ev.title}</h4>
                      {ev.description && (
                        <p className="text-xs text-muted-foreground line-clamp-2">{ev.description}</p>
                      )}
                      <div className="text-xs text-muted-foreground font-mono flex items-center gap-1 pt-1">
                        <Clock className="size-3 text-emerald-400" />
                        <span>{ev.allDay ? "All day" : formatLocalTime(item.date)}</span>
                      </div>
                    </div>

                    <div className="shrink-0 self-end md:self-center">
                      <Button variant="outline" size="sm" className="text-xs h-8 border-emerald-500/30 text-emerald-300">
                        {ev.canEdit ? "Edit Event" : "View Event"}
                      </Button>
                    </div>
                  </div>
                )
              }

              return null
            })}
          </div>
        </div>
      ))}
    </div>
  )
}
