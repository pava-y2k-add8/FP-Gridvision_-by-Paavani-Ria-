"use client"

import React from "react"
import { FixtureRecord, CalendarEventRecord } from "@/lib/db/calendar-store"
import {
  X,
  ShieldCheck,
  Lock,
  Clock,
  MapPin,
  Calendar,
  AlertTriangle,
  FileText,
  Plus,
  ExternalLink,
  Info,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const COMPETITION_NAMES: Record<string, string> = {
  "world-cup": "FIFA World Cup",
  "premier-league": "Premier League",
  "la-liga": "La Liga",
  "serie-a": "Serie A",
}

interface FixtureDetailModalProps {
  fixture: FixtureRecord | null
  isOpen: boolean
  onClose: () => void
  userEvents: CalendarEventRecord[]
  onOpenAddNote: (f: FixtureRecord) => void
  onSelectEvent: (e: CalendarEventRecord) => void
  isLoggedIn: boolean
}

export function FixtureDetailModal({
  fixture,
  isOpen,
  onClose,
  userEvents,
  onOpenAddNote,
  onSelectEvent,
  isLoggedIn,
}: FixtureDetailModalProps) {
  if (!isOpen || !fixture) return null

  const isPostponed = fixture.status === "POSTPONED"
  const isLive = fixture.status === "LIVE"
  const isFinished = fixture.status === "FINISHED"

  const localKickoffDate = new Date(fixture.kickoffTime)
  const formattedLocalDate = localKickoffDate.toLocaleDateString("default", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })
  const formattedLocalTime = localKickoffDate.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  })
  const localTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone

  const linkedNotes = userEvents.filter((e) => e.linkedFixtureId === fixture.id)

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-lg rounded-xl border border-border bg-card p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Header with Read-Only Badge */}
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="border-border bg-secondary/60 text-muted-foreground flex items-center gap-1 text-xs">
              <Lock className="size-3" />
              <span>Official Fixture (Read-Only)</span>
            </Badge>
            <Badge variant="outline" className="border-emerald-500/30 bg-emerald-500/10 text-emerald-400 flex items-center gap-1 text-xs">
              <ShieldCheck className="size-3" />
              <span>Verified Source</span>
            </Badge>
          </div>
          <button
            onClick={onClose}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <X className="size-4" />
          </button>
        </div>

        {/* Competition & Round */}
        <div className="text-center space-y-1">
          <p className="text-xs font-semibold uppercase tracking-wider text-primary">
            {COMPETITION_NAMES[fixture.competition] || fixture.competition.replace("-", " ")} • {fixture.season}
          </p>
          <h2 className="text-lg font-bold text-foreground">{fixture.round}</h2>
        </div>

        {/* Teams & Scoreboard Card */}
        <div className="rounded-xl border border-border bg-secondary/30 p-4 text-center space-y-3">
          <div className="grid grid-cols-5 items-center gap-2">
            {/* Home Team */}
            <div className="col-span-2 text-center md:text-right">
              <p className="text-base font-bold text-foreground">{fixture.homeTeam}</p>
              <p className="text-[11px] text-muted-foreground">Home</p>
            </div>

            {/* Score / VS Box */}
            <div className="col-span-1 flex flex-col items-center justify-center">
              {isFinished ? (
                <div className="rounded-lg bg-card px-3 py-1.5 border border-border text-lg font-mono font-bold">
                  {fixture.homeScore} : {fixture.awayScore}
                </div>
              ) : isLive ? (
                <div className="rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 px-2.5 py-1 text-xs font-bold animate-pulse">
                  LIVE
                </div>
              ) : isPostponed ? (
                <div className="rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-300 px-2 py-1 text-[11px] font-bold">
                  PSTP
                </div>
              ) : (
                <div className="text-xs font-bold text-muted-foreground bg-secondary px-2 py-1 rounded">
                  VS
                </div>
              )}
            </div>

            {/* Away Team */}
            <div className="col-span-2 text-center md:text-left">
              <p className="text-base font-bold text-foreground">{fixture.awayTeam}</p>
              <p className="text-[11px] text-muted-foreground">Away</p>
            </div>
          </div>

          {/* Postponed Warning */}
          {isPostponed && (
            <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-2.5 text-xs text-amber-300 flex items-center justify-center gap-2">
              <AlertTriangle className="size-4 shrink-0" />
              <span>This match was postponed. Kickoff time will update once rescheduled.</span>
            </div>
          )}
        </div>

        {/* Kickoff & Venue Info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="rounded-lg border border-border bg-secondary/20 p-3 space-y-1">
            <div className="flex items-center gap-1.5 text-muted-foreground font-semibold">
              <Clock className="size-3.5 text-primary" />
              <span>Local Kickoff Time</span>
            </div>
            <p className="font-semibold text-foreground text-sm">{formattedLocalTime}</p>
            <p className="text-[11px] text-muted-foreground">{formattedLocalDate}</p>
            <p className="text-[10px] text-muted-foreground font-mono">Timezone: {localTimezone}</p>
          </div>

          <div className="rounded-lg border border-border bg-secondary/20 p-3 space-y-1">
            <div className="flex items-center gap-1.5 text-muted-foreground font-semibold">
              <MapPin className="size-3.5 text-primary" />
              <span>Venue</span>
            </div>
            <p className="font-semibold text-foreground text-sm">
              {fixture.venue || "Venue To Be Announced"}
            </p>
            <p className="text-[11px] text-muted-foreground">Official Match Location</p>
          </div>
        </div>

        {/* Verified Source Attribution Banner */}
        <div className="rounded-lg border border-border/60 bg-secondary/15 p-3 space-y-1 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-foreground flex items-center gap-1.5">
              <ShieldCheck className="size-3.5 text-emerald-400" />
              <span>Source Attribution</span>
            </span>
            <Badge variant="outline" className="text-[10px] py-0 border-emerald-500/30 text-emerald-400">
              Verified Real Data
            </Badge>
          </div>
          <p className="text-muted-foreground text-[11px]">
            Provided by: <span className="font-semibold text-foreground">{fixture.source}</span>
          </p>
          <p className="text-[10px] text-muted-foreground">
            Last verified / updated: {new Date(fixture.lastUpdated).toLocaleString()}
          </p>
        </div>

        {/* Personal Notes Section */}
        <div className="border-t border-border pt-3 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-foreground flex items-center gap-1.5">
              <FileText className="size-3.5 text-emerald-400" />
              <span>My Tactical Notes for this Fixture</span>
            </h4>
            {isLoggedIn ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  onClose()
                  onOpenAddNote(fixture)
                }}
                className="h-7 text-xs border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10 flex items-center gap-1"
              >
                <Plus className="size-3" />
                <span>Add Note</span>
              </Button>
            ) : (
              <span className="text-[10px] text-muted-foreground">Sign in to add notes</span>
            )}
          </div>

          {linkedNotes.length === 0 ? (
            <p className="text-xs text-muted-foreground italic bg-secondary/20 p-2.5 rounded-md text-center">
              No personal scouting or tactical notes attached to this fixture yet.
            </p>
          ) : (
            <div className="space-y-1.5">
              {linkedNotes.map((note) => (
                <div
                  key={note.id}
                  onClick={() => {
                    onClose()
                    onSelectEvent(note)
                  }}
                  className="cursor-pointer rounded-md border border-emerald-500/30 bg-emerald-500/5 hover:bg-emerald-500/15 p-2.5 text-xs transition-colors flex items-center justify-between"
                >
                  <div className="space-y-0.5 truncate">
                    <p className="font-semibold text-emerald-300 truncate">{note.title}</p>
                    {note.description && (
                      <p className="text-[11px] text-muted-foreground truncate">{note.description}</p>
                    )}
                  </div>
                  <Button variant="ghost" size="sm" className="h-6 text-[10px] text-emerald-400 shrink-0">
                    Edit Note
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end border-t border-border pt-3">
          <Button variant="outline" size="sm" onClick={onClose} className="text-xs h-8">
            Close
          </Button>
        </div>
      </div>
    </div>
  )
}
