"use client"

import React from "react"
import { FixtureRecord, CalendarEventRecord } from "@/lib/db/calendar-store"
import { Plus, Clock, MapPin, ShieldCheck, Users, FileText, AlertTriangle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface WeekViewProps {
  currentDate: Date
  fixtures: FixtureRecord[]
  events: CalendarEventRecord[]
  onSelectFixture: (f: FixtureRecord) => void
  onSelectEvent: (e: CalendarEventRecord) => void
  onCreateEventOnDate: (date: Date) => void
}

const COMPETITION_BADGES: Record<string, { label: string; badge: string }> = {
  "world-cup": { label: "FIFA World Cup", badge: "border-amber-500/30 bg-amber-500/10 text-amber-300" },
  "premier-league": { label: "Premier League", badge: "border-purple-500/30 bg-purple-500/10 text-purple-300" },
  "la-liga": { label: "La Liga", badge: "border-red-500/30 bg-red-500/10 text-red-300" },
  "serie-a": { label: "Serie A", badge: "border-blue-500/30 bg-blue-500/10 text-blue-300" },
}

export function WeekView({
  currentDate,
  fixtures,
  events,
  onSelectFixture,
  onSelectEvent,
  onCreateEventOnDate,
}: WeekViewProps) {
  // Compute start of week (Sunday)
  const startOfWeek = new Date(currentDate)
  const dayOfWeek = startOfWeek.getDay()
  startOfWeek.setDate(startOfWeek.getDate() - dayOfWeek)

  const weekDays = []
  for (let i = 0; i < 7; i++) {
    const d = new Date(startOfWeek)
    d.setDate(d.getDate() + i)
    weekDays.push(d)
  }

  const todayStr = new Date().toDateString()

  const getItemsForDay = (cellDate: Date) => {
    const y = cellDate.getFullYear()
    const m = String(cellDate.getMonth() + 1).padStart(2, "0")
    const d = String(cellDate.getDate()).padStart(2, "0")
    const key = `${y}-${m}-${d}`

    const dayFixtures = fixtures.filter((f) => {
      try {
        const fDate = new Date(f.kickoffTime)
        const fy = fDate.getFullYear()
        const fm = String(fDate.getMonth() + 1).padStart(2, "0")
        const fd = String(fDate.getDate()).padStart(2, "0")
        return `${fy}-${fm}-${fd}` === key
      } catch {
        return false
      }
    })

    const dayEvents = events.filter((e) => {
      try {
        const eDate = new Date(e.startDate)
        const ey = eDate.getFullYear()
        const em = String(eDate.getMonth() + 1).padStart(2, "0")
        const ed = String(eDate.getDate()).padStart(2, "0")
        return `${ey}-${em}-${ed}` === key
      } catch {
        return false
      }
    })

    return { dayFixtures, dayEvents }
  }

  const formatLocalTime = (iso: string) => {
    try {
      const d = new Date(iso)
      return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } catch {
      return ""
    }
  }

  return (
    <div className="flex flex-col bg-background overflow-x-auto">
      <div className="grid grid-cols-7 min-w-[850px] border-b border-border">
        {weekDays.map((dayDate, idx) => {
          const isToday = dayDate.toDateString() === todayStr
          const { dayFixtures, dayEvents } = getItemsForDay(dayDate)

          return (
            <div
              key={idx}
              className={`flex flex-col border-r border-border last:border-r-0 min-h-[500px] ${
                isToday ? "bg-primary/5" : "bg-card/20"
              }`}
            >
              {/* Day Header */}
              <div
                className={`sticky top-0 z-10 flex items-center justify-between border-b border-border p-2.5 backdrop-blur ${
                  isToday ? "bg-primary/10 text-primary" : "bg-card/80 text-foreground"
                }`}
              >
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {dayDate.toLocaleDateString("default", { weekday: "short" })}
                  </p>
                  <p className={`text-base font-bold ${isToday ? "text-primary" : "text-foreground"}`}>
                    {dayDate.getDate()}{" "}
                    <span className="text-xs font-normal text-muted-foreground">
                      {dayDate.toLocaleDateString("default", { month: "short" })}
                    </span>
                  </p>
                </div>

                <button
                  onClick={() => onCreateEventOnDate(dayDate)}
                  className="rounded-md p-1 hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
                  title="Add event or note on this day"
                >
                  <Plus className="size-4" />
                </button>
              </div>

              {/* Day Content */}
              <div className="flex-1 p-2 space-y-2 overflow-y-auto">
                {dayFixtures.length === 0 && dayEvents.length === 0 && (
                  <div className="py-8 text-center text-xs text-muted-foreground/60 italic">
                    No scheduled fixtures
                  </div>
                )}

                {/* Fixtures */}
                {dayFixtures.map((f) => {
                  const comp = COMPETITION_BADGES[f.competition] || {
                    label: f.competition,
                    badge: "border-border bg-secondary text-foreground",
                  }
                  const isPostponed = f.status === "POSTPONED"
                  const isLive = f.status === "LIVE"
                  const isFinished = f.status === "FINISHED"

                  return (
                    <div
                      key={f.id}
                      onClick={() => onSelectFixture(f)}
                      className="cursor-pointer rounded-lg border border-border bg-card/80 hover:bg-card p-2.5 shadow-xs transition-all hover:border-primary/50 group space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-1">
                        <Badge variant="outline" className={`text-[10px] py-0 px-1.5 ${comp.badge}`}>
                          {comp.label}
                        </Badge>
                        <span className="text-[11px] font-mono text-muted-foreground flex items-center gap-1">
                          <Clock className="size-3" />
                          {formatLocalTime(f.kickoffTime)}
                        </span>
                      </div>

                      <div className="space-y-0.5">
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span className="truncate">{f.homeTeam}</span>
                          {isFinished && <span className="font-mono">{f.homeScore}</span>}
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span className="truncate">{f.awayTeam}</span>
                          {isFinished && <span className="font-mono">{f.awayScore}</span>}
                        </div>
                      </div>

                      {f.venue && (
                        <p className="text-[10px] text-muted-foreground truncate flex items-center gap-1">
                          <MapPin className="size-2.5 shrink-0" />
                          {f.venue.split(",")[0]}
                        </p>
                      )}

                      {/* Status Badge */}
                      <div className="flex items-center justify-between pt-1 border-t border-border/40 text-[10px]">
                        {isPostponed ? (
                          <span className="text-amber-400 font-semibold flex items-center gap-1">
                            <AlertTriangle className="size-2.5" /> Postponed
                          </span>
                        ) : isLive ? (
                          <span className="text-emerald-400 font-semibold flex items-center gap-1 animate-pulse">
                            ● LIVE
                          </span>
                        ) : isFinished ? (
                          <span className="text-muted-foreground font-medium">FT</span>
                        ) : (
                          <span className="text-muted-foreground">{f.round}</span>
                        )}
                        <span className="text-[9px] text-muted-foreground/70 truncate max-w-[90px]" title={f.source}>
                          Verified
                        </span>
                      </div>
                    </div>
                  )
                })}

                {/* Personal & Shared Events */}
                {dayEvents.map((ev) => (
                  <div
                    key={ev.id}
                    onClick={() => onSelectEvent(ev)}
                    className="cursor-pointer rounded-lg border border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20 p-2.5 text-xs transition-all space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                        {ev.visibility === "shared" ? (
                          <>
                            <Users className="size-3 text-indigo-400" />
                            <span className="text-indigo-300">Shared</span>
                          </>
                        ) : (
                          <>
                            <FileText className="size-3" />
                            <span>Note</span>
                          </>
                        )}
                      </span>
                      <span className="text-[10px] text-muted-foreground font-mono">
                        {ev.allDay ? "All day" : formatLocalTime(ev.startDate)}
                      </span>
                    </div>
                    <p className="font-semibold text-foreground truncate">{ev.title}</p>
                    {ev.description && (
                      <p className="text-[11px] text-muted-foreground line-clamp-2">{ev.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
