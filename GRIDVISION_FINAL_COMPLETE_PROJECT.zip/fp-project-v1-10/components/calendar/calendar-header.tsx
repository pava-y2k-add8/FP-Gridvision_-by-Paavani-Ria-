"use client"

import React from "react"
import {
  CalendarDays,
  CalendarRange,
  ListFilter,
  ChevronLeft,
  ChevronRight,
  RefreshCw,
  Plus,
  ShieldCheck,
  Clock,
  Globe,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { SyncLogRecord } from "@/lib/db/calendar-store"

export type CalendarViewMode = "month" | "week" | "upcoming"

interface CalendarHeaderProps {
  currentDate: Date
  viewMode: CalendarViewMode
  onViewModeChange: (mode: CalendarViewMode) => void
  onNavigatePrev: () => void
  onNavigateNext: () => void
  onNavigateToday: () => void
  onOpenNewEvent: () => void
  onSyncFixtures: () => void
  isSyncing: boolean
  latestSync: SyncLogRecord | null
  user: { userId: number; name: string; email: string } | null
}

export function CalendarHeader({
  currentDate,
  viewMode,
  onViewModeChange,
  onNavigatePrev,
  onNavigateNext,
  onNavigateToday,
  onOpenNewEvent,
  onSyncFixtures,
  isSyncing,
  latestSync,
  user,
}: CalendarHeaderProps) {
  const monthName = currentDate.toLocaleString("default", {
    month: "long",
    year: "numeric",
  })

  // Format week range label if in week mode
  const getWeekLabel = () => {
    const start = new Date(currentDate)
    const day = start.getDay()
    start.setDate(start.getDate() - day)
    const end = new Date(start)
    end.setDate(end.getDate() + 6)
    return `${start.toLocaleDateString("default", { month: "short", day: "numeric" })} - ${end.toLocaleDateString("default", { month: "short", day: "numeric", year: "numeric" })}`
  }

  const formatLastSync = (iso?: string) => {
    if (!iso) return "Default verified fixture seed"
    try {
      const d = new Date(iso)
      return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) + " (" + d.toLocaleDateString() + ")"
    } catch {
      return iso
    }
  }

  return (
    <div className="space-y-4 border-b border-border bg-card/40 p-4 md:p-6 backdrop-blur">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        {/* Title & Navigation */}
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="grid size-9 place-items-center rounded-lg bg-primary/20 text-primary border border-primary/30">
              <CalendarDays className="size-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-foreground md:text-2xl">
                Events & Fixtures Calendar
              </h1>
              <p className="text-xs text-muted-foreground">
                Verified real fixtures, live status, and personal tactical scheduling
              </p>
            </div>
          </div>
        </div>

        {/* View Switcher and Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* View Mode Toggle Buttons */}
          <div className="flex rounded-lg border border-border bg-secondary/50 p-1">
            <button
              onClick={() => onViewModeChange("month")}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                viewMode === "month"
                  ? "bg-primary text-primary-foreground shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <CalendarDays className="size-3.5" />
              <span>Month</span>
            </button>
            <button
              onClick={() => onViewModeChange("week")}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                viewMode === "week"
                  ? "bg-primary text-primary-foreground shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <CalendarRange className="size-3.5" />
              <span>Week</span>
            </button>
            <button
              onClick={() => onViewModeChange("upcoming")}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                viewMode === "upcoming"
                  ? "bg-primary text-primary-foreground shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <ListFilter className="size-3.5" />
              <span>Upcoming</span>
            </button>
          </div>

          {/* Sync Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={onSyncFixtures}
            disabled={isSyncing}
            className="flex items-center gap-1.5 border-border bg-card hover:bg-secondary text-xs h-9"
            title="Sync with verified real sources (FPL, openfootball, FIFA)"
          >
            <RefreshCw className={`size-3.5 text-primary ${isSyncing ? "animate-spin" : ""}`} />
            <span>{isSyncing ? "Syncing..." : "Sync Live"}</span>
          </Button>

          {/* Create Event Button */}
          <Button
            size="sm"
            onClick={onOpenNewEvent}
            className="flex items-center gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90 text-xs h-9 font-medium"
          >
            <Plus className="size-4" />
            <span>New Event / Note</span>
          </Button>
        </div>
      </div>

      {/* Date Navigation & Attribution Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between pt-2 border-t border-border/50">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onNavigateToday}
            className="h-8 px-2.5 text-xs border-border text-foreground hover:bg-secondary"
          >
            Today
          </Button>
          <div className="flex items-center border border-border rounded-md bg-secondary/30">
            <Button
              variant="ghost"
              size="icon"
              onClick={onNavigatePrev}
              className="h-8 w-8 text-muted-foreground hover:text-foreground"
              title="Previous"
            >
              <ChevronLeft className="size-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onNavigateNext}
              className="h-8 w-8 text-muted-foreground hover:text-foreground"
              title="Next"
            >
              <ChevronRight className="size-4" />
            </Button>
          </div>
          <span className="font-semibold text-sm md:text-base text-foreground pl-1">
            {viewMode === "week" ? getWeekLabel() : monthName}
          </span>
        </div>

        {/* Verification Status Banner */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <Badge variant="outline" className="flex items-center gap-1.5 border-emerald-500/30 bg-emerald-500/10 text-emerald-400 py-0.5 px-2">
            <ShieldCheck className="size-3" />
            <span>Verified Sources Only</span>
          </Badge>
          <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
            <Clock className="size-3" />
            <span>Updated: {formatLastSync(latestSync?.timestamp)}</span>
          </div>
          <div className="hidden md:flex items-center gap-1 text-[11px] text-muted-foreground border-l border-border pl-2">
            <Globe className="size-3" />
            <span>Local Times (Browser Timezone)</span>
          </div>
        </div>
      </div>
    </div>
  )
}
