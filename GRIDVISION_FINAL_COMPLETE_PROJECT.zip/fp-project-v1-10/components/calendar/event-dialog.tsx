"use client"

import React, { useState, useEffect } from "react"
import { CalendarEventRecord, FixtureRecord } from "@/lib/db/calendar-store"
import {
  X,
  Calendar,
  Clock,
  Users,
  FileText,
  Lock,
  Share2,
  Trash2,
  Save,
  AlertCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

interface EventDialogProps {
  isOpen: boolean
  onClose: () => void
  onSave: (data: {
    id?: string
    title: string
    description?: string
    eventType: "match_note" | "scouting" | "watch_party" | "training" | "personal"
    startDate: string
    endDate?: string
    allDay: boolean
    linkedFixtureId?: string
    visibility: "private" | "shared"
    shares?: { userId: number; permission: "view" | "edit" }[]
  }) => Promise<{ success: boolean; error?: string }>
  onDelete?: (id: string) => Promise<{ success: boolean; error?: string }>
  initialEvent?: CalendarEventRecord | null
  initialDate?: Date | null
  initialFixture?: FixtureRecord | null
  fixtures: FixtureRecord[]
  availableUsers: { id: number; name: string; email: string }[]
  currentUserId: number | null
}

export function EventDialog({
  isOpen,
  onClose,
  onSave,
  onDelete,
  initialEvent,
  initialDate,
  initialFixture,
  fixtures,
  availableUsers,
  currentUserId,
}: EventDialogProps) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [eventType, setEventType] = useState<
    "match_note" | "scouting" | "watch_party" | "training" | "personal"
  >("personal")
  const [dateStr, setDateStr] = useState("")
  const [timeStr, setTimeStr] = useState("18:00")
  const [allDay, setAllDay] = useState(false)
  const [linkedFixtureId, setLinkedFixtureId] = useState<string>("")
  const [visibility, setVisibility] = useState<"private" | "shared">("private")
  const [selectedShares, setSelectedShares] = useState<
    Map<number, "view" | "edit">
  >(new Map())
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const isEditing = Boolean(initialEvent)
  const isOwner = !initialEvent || initialEvent.userId === currentUserId
  const canEdit = !initialEvent || Boolean(initialEvent.canEdit)

  useEffect(() => {
    if (!isOpen) return

    setError(null)
    if (initialEvent) {
      setTitle(initialEvent.title)
      setDescription(initialEvent.description || "")
      setEventType(initialEvent.eventType)
      const d = new Date(initialEvent.startDate)
      setDateStr(d.toISOString().split("T")[0])
      setTimeStr(d.toTimeString().slice(0, 5))
      setAllDay(initialEvent.allDay)
      setLinkedFixtureId(initialEvent.linkedFixtureId || "")
      setVisibility(initialEvent.visibility)

      const sharesMap = new Map<number, "view" | "edit">()
      if (initialEvent.shares) {
        for (const s of initialEvent.shares) {
          sharesMap.set(s.sharedWithUserId, s.permission)
        }
      }
      setSelectedShares(sharesMap)
    } else {
      const d = initialDate || new Date()
      setTitle(initialFixture ? `Note: ${initialFixture.homeTeam} vs ${initialFixture.awayTeam}` : "")
      setDescription("")
      setEventType(initialFixture ? "match_note" : "personal")
      setDateStr(d.toISOString().split("T")[0])
      setTimeStr(
        initialFixture
          ? new Date(initialFixture.kickoffTime).toTimeString().slice(0, 5)
          : "18:00",
      )
      setAllDay(false)
      setLinkedFixtureId(initialFixture ? initialFixture.id : "")
      setVisibility("private")
      setSelectedShares(new Map())
    }
  }, [isOpen, initialEvent, initialDate, initialFixture])

  if (!isOpen) return null

  const handleShareToggle = (userId: number) => {
    const next = new Map(selectedShares)
    if (next.has(userId)) {
      next.delete(userId)
    } else {
      next.set(userId, "view")
    }
    setSelectedShares(next)
  }

  const handlePermissionChange = (userId: number, perm: "view" | "edit") => {
    const next = new Map(selectedShares)
    next.set(userId, perm)
    setSelectedShares(next)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) {
      setError("Please provide a title for the event.")
      return
    }

    if (!dateStr) {
      setError("Please select a valid date.")
      return
    }

    setIsSubmitting(true)
    setError(null)

    try {
      const startIso = allDay
        ? new Date(`${dateStr}T00:00:00`).toISOString()
        : new Date(`${dateStr}T${timeStr}:00`).toISOString()

      const sharesList: { userId: number; permission: "view" | "edit" }[] = []
      if (visibility === "shared") {
        selectedShares.forEach((permission, userId) => {
          sharesList.push({ userId, permission })
        })
      }

      const res = await onSave({
        id: initialEvent?.id,
        title,
        description,
        eventType,
        startDate: startIso,
        allDay,
        linkedFixtureId: linkedFixtureId || undefined,
        visibility,
        shares: sharesList,
      })

      if (!res.success) {
        setError(res.error || "Failed to save event.")
      } else {
        onClose()
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err)
      setError(msg)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async () => {
    if (!initialEvent || !onDelete) return
    if (!confirm("Are you sure you want to delete this event? This action cannot be undone.")) return

    setIsSubmitting(true)
    try {
      const res = await onDelete(initialEvent.id)
      if (!res.success) {
        setError(res.error || "Failed to delete event.")
      } else {
        onClose()
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err)
      setError(msg)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-lg rounded-xl border border-border bg-card p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <div className="grid size-8 place-items-center rounded-lg bg-emerald-500/20 text-emerald-400">
              <Calendar className="size-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-foreground">
                {isEditing ? (canEdit ? "Edit Event / Note" : "View Shared Event") : "Create New Event / Note"}
              </h3>
              <p className="text-xs text-muted-foreground">
                Personal scouting, match notes, and tactical sessions
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <X className="size-4" />
          </button>
        </div>

        {/* View-only notification if not editable */}
        {!canEdit && (
          <div className="mt-3 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-300 flex items-center gap-2">
            <AlertCircle className="size-4 shrink-0" />
            <span>You have view-only access to this event shared with you.</span>
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="mt-3 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive flex items-center gap-2">
            <AlertCircle className="size-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
          {/* Title */}
          <div className="space-y-1">
            <label className="font-semibold text-foreground">Title *</label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              disabled={!canEdit}
              placeholder="e.g. Tactical Scouting vs Arsenal, Watch Party..."
              className="text-xs bg-secondary/30"
              required
            />
          </div>

          {/* Event Category */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-foreground">Category</label>
              <select
                value={eventType}
                onChange={(e) => setEventType(e.target.value as typeof eventType)}
                disabled={!canEdit}
                className="w-full rounded-md border border-border bg-secondary/40 px-3 py-2 text-xs text-foreground focus:outline-hidden focus:ring-1 focus:ring-primary"
              >
                <option value="personal">Personal Note</option>
                <option value="match_note">Match Note</option>
                <option value="scouting">Tactical Scouting</option>
                <option value="watch_party">Watch Party</option>
                <option value="training">Training Session</option>
              </select>
            </div>

            {/* Link with official fixture */}
            <div className="space-y-1">
              <label className="font-semibold text-foreground">Link to Fixture (Optional)</label>
              <select
                value={linkedFixtureId}
                onChange={(e) => setLinkedFixtureId(e.target.value)}
                disabled={!canEdit}
                className="w-full rounded-md border border-border bg-secondary/40 px-3 py-2 text-xs text-foreground focus:outline-hidden focus:ring-1 focus:ring-primary truncate"
              >
                <option value="">None (Independent Note)</option>
                {fixtures.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.homeTeam} vs {f.awayTeam} ({f.round})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-foreground">Date *</label>
              <Input
                type="date"
                value={dateStr}
                onChange={(e) => setDateStr(e.target.value)}
                disabled={!canEdit}
                className="text-xs bg-secondary/30"
                required
              />
            </div>

            {!allDay && (
              <div className="space-y-1">
                <label className="font-semibold text-foreground">Local Time</label>
                <Input
                  type="time"
                  value={timeStr}
                  onChange={(e) => setTimeStr(e.target.value)}
                  disabled={!canEdit}
                  className="text-xs bg-secondary/30"
                />
              </div>
            )}

            <div className="space-y-1 flex items-end pb-2">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-muted-foreground hover:text-foreground">
                <input
                  type="checkbox"
                  checked={allDay}
                  onChange={(e) => setAllDay(e.target.checked)}
                  disabled={!canEdit}
                  className="rounded border-border text-primary focus:ring-primary size-4"
                />
                <span>All-day event</span>
              </label>
            </div>
          </div>

          {/* Description & Detailed Notes */}
          <div className="space-y-1">
            <label className="font-semibold text-foreground">Notes & Tactical Observations</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              disabled={!canEdit}
              rows={4}
              placeholder="Add personal scouting analysis, key player assignments, formation observations, or event details..."
              className="w-full rounded-md border border-border bg-secondary/30 p-2.5 text-xs text-foreground focus:outline-hidden focus:ring-1 focus:ring-primary"
            />
          </div>

          {/* Privacy & Sharing Controls (Owner only) */}
          {isOwner && (
            <div className="space-y-2 border-t border-border pt-3">
              <label className="font-semibold text-foreground flex items-center justify-between">
                <span>Event Sharing & Permissions</span>
                <span className="text-[11px] font-normal text-muted-foreground">
                  Private notes remain visible only to you
                </span>
              </label>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setVisibility("private")}
                  className={`flex items-center gap-2 rounded-lg border p-2.5 text-left transition-all ${
                    visibility === "private"
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-secondary/30 text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Lock className="size-4 shrink-0" />
                  <div>
                    <p className="font-semibold">Private</p>
                    <p className="text-[10px]">Only you can see and edit</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setVisibility("shared")}
                  className={`flex items-center gap-2 rounded-lg border p-2.5 text-left transition-all ${
                    visibility === "shared"
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-secondary/30 text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Share2 className="size-4 shrink-0" />
                  <div>
                    <p className="font-semibold">Shared</p>
                    <p className="text-[10px]">Sync with authorised users</p>
                  </div>
                </button>
              </div>

              {/* Share User List */}
              {visibility === "shared" && (
                <div className="mt-2 rounded-lg border border-border bg-secondary/20 p-3 space-y-2">
                  <p className="text-[11px] font-medium text-foreground">
                    Authorised Users & Access Levels:
                  </p>
                  {availableUsers.length === 0 ? (
                    <p className="text-[11px] text-muted-foreground italic">
                      No other registered users found. When other team members register, you can share directly with them.
                    </p>
                  ) : (
                    <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                      {availableUsers.map((u) => {
                        const isSelected = selectedShares.has(u.id)
                        const currentPerm = selectedShares.get(u.id) || "view"

                        return (
                          <div
                            key={u.id}
                            className="flex items-center justify-between gap-2 rounded-md bg-card/60 p-2 border border-border/50 text-xs"
                          >
                            <label className="flex items-center gap-2 cursor-pointer flex-1 min-w-0">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => handleShareToggle(u.id)}
                                className="rounded border-border text-primary focus:ring-primary size-3.5"
                              />
                              <div className="truncate">
                                <span className="font-semibold text-foreground truncate block">{u.name}</span>
                                <span className="text-[10px] text-muted-foreground truncate block">{u.email}</span>
                              </div>
                            </label>

                            {isSelected && (
                              <select
                                value={currentPerm}
                                onChange={(e) =>
                                  handlePermissionChange(u.id, e.target.value as "view" | "edit")
                                }
                                className="rounded border border-border bg-secondary px-2 py-1 text-[11px] text-foreground"
                              >
                                <option value="view">Can View</option>
                                <option value="edit">Can Edit</option>
                              </select>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-between border-t border-border pt-4">
            {isEditing && isOwner ? (
              <Button
                type="button"
                variant="destructive"
                size="sm"
                onClick={handleDelete}
                disabled={isSubmitting}
                className="text-xs h-8 flex items-center gap-1.5"
              >
                <Trash2 className="size-3.5" />
                <span>Delete</span>
              </Button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={onClose}
                disabled={isSubmitting}
                className="text-xs h-8 border-border"
              >
                Cancel
              </Button>

              {canEdit && (
                <Button
                  type="submit"
                  size="sm"
                  disabled={isSubmitting}
                  className="text-xs h-8 bg-primary text-primary-foreground hover:bg-primary/90 flex items-center gap-1.5"
                >
                  <Save className="size-3.5" />
                  <span>{isSubmitting ? "Saving..." : isEditing ? "Save Changes" : "Create Event"}</span>
                </Button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}
