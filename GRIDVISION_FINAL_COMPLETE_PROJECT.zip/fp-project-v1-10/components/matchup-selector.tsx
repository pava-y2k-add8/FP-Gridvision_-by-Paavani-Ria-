"use client"

import { useEffect, useMemo, useState } from "react"
import {
  ArrowLeftRight,
  Users,
  Gauge,
  Percent,
  Trophy,
  Target,
  BrainCircuit,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { StatCard } from "@/components/stat-card"
import { useSeason } from "@/components/season-context"
import {
  eloMatchup,
  getSeason,
  teamAttack,
  teamColor,
  teamDefense,
  teamOverall,
  teamAggregates,
  type Team,
} from "@/lib/data"
import { gridVisionPredict } from "@/lib/prediction"

export function MatchupSelector() {
  const { season } = useSeason()
  const teams = useMemo(
    () => [...getSeason(season).teams].sort((a, b) => a.name.localeCompare(b.name)),
    [season],
  )
  const aggregates = useMemo(() => teamAggregates(season), [season])

  const [homeId, setHomeId] = useState(teams[0]?.id ?? 0)
  const [awayId, setAwayId] = useState(teams[1]?.id ?? 0)

  // Keep selections valid when the season (and its team list) changes
  useEffect(() => {
    if (!teams.some((t) => t.id === homeId)) setHomeId(teams[0]?.id ?? 0)
    if (!teams.some((t) => t.id === awayId)) setAwayId(teams[1]?.id ?? 0)
  }, [teams]) // eslint-disable-line react-hooks/exhaustive-deps

  const home = teams.find((t) => t.id === homeId) ?? teams[0]
  const away = teams.find((t) => t.id === awayId) ?? teams[1]
  const sameTeam = homeId === awayId

  const result = useMemo(() => (home && away ? eloMatchup(home, away) : null), [home, away])
  const prediction = useMemo(
    () => (home && away && !sameTeam ? gridVisionPredict(home, away) : null),
    [home, away, sameTeam],
  )
  const homeAgg = aggregates.find((a) => a.team.id === home?.id)
  const awayAgg = aggregates.find((a) => a.team.id === away?.id)

  if (!home || !away || !result) return null

  function swap() {
    setHomeId(awayId)
    setAwayId(homeId)
  }

  return (
    <Card className="overflow-hidden p-0 shadow-sm">
      <div className="grid grid-cols-1 items-end gap-3 sm:gap-4 border-b border-border p-4 sm:p-6 md:grid-cols-[1fr_auto_1fr]">
        <TeamSelect label="Home team" value={homeId} onChange={setHomeId} disabledId={awayId} teams={teams} team={home} />

        <div className="flex items-center justify-center pb-1">
          <Button type="button" variant="outline" size="icon" onClick={swap} aria-label="Swap home and away teams" className="rounded-full size-8 sm:size-9">
            <ArrowLeftRight className="size-4" />
          </Button>
        </div>

        <TeamSelect label="Away team" value={awayId} onChange={setAwayId} disabledId={homeId} teams={teams} team={away} align="right" />
      </div>

      {sameTeam ? (
        <div className="p-6 text-center text-sm text-muted-foreground">Pick two different teams to compare the matchup.</div>
      ) : (
        <div className="space-y-6 p-4 sm:p-6">
          <div className="flex items-center justify-between gap-2 sm:gap-4">
            <TeamBadge team={home} />
            <div className="text-center shrink-0 px-1 sm:px-2">
              <div className="font-mono text-[10px] sm:text-xs uppercase tracking-wide text-muted-foreground">Elo preview (Model Estimate)</div>
              <div className="font-mono text-xl sm:text-2xl font-semibold text-muted-foreground">vs</div>
            </div>
            <TeamBadge team={away} align="right" />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-medium">
              <span className="truncate max-w-[40%] text-left" style={{ color: teamColor(home.short) }}>
                {result.homeWin}% <span className="hidden sm:inline">{home.name} win</span><span className="sm:hidden">{home.short}</span>
              </span>
              <span className="shrink-0 text-muted-foreground px-1">{result.draw}% draw</span>
              <span className="truncate max-w-[40%] text-right" style={{ color: teamColor(away.short) }}>
                <span className="hidden sm:inline">{away.name} win </span><span className="sm:hidden">{away.short} </span>{result.awayWin}%
              </span>
            </div>
            <div className="flex h-3 overflow-hidden rounded-full bg-secondary">
              <div className="h-full" style={{ width: `${result.homeWin}%`, backgroundColor: teamColor(home.short) }} />
              <div className="h-full bg-muted-foreground/40" style={{ width: `${result.draw}%` }} />
              <div className="h-full flex-1" style={{ backgroundColor: teamColor(away.short) }} />
            </div>
            <p className="text-[11px] sm:text-xs text-muted-foreground">
              Estimated win probability from {season === "world-cup" ? "national team" : "club"} Elo ratings ({home.elo} vs {away.elo}) with home advantage.
            </p>
          </div>

          {prediction ? <GridVisionCard prediction={prediction} home={home} away={away} isNational={season === "world-cup"} /> : null}

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <StatCard icon={Trophy} label="Elo rating" value={home.elo} hint={`${away.name} ${away.elo}`} />
            <StatCard icon={Gauge} label="Attack" value={teamAttack(home)} accent="accent" hint={`${away.name} ${teamAttack(away)}`} />
            <StatCard icon={Users} label="Defense" value={teamDefense(home)} accent="chart-3" hint={`${away.name} ${teamDefense(away)}`} />
            <StatCard icon={Percent} label="Possession" value={result.possHome} unit="%" hint={`${result.possAway}% ${away.name}`} />
          </div>

          <div className="space-y-3">
            <CompareRow label="Elo rating" home={home} away={away} homeVal={home.elo} awayVal={away.elo} />
            <CompareRow label="Overall strength" home={home} away={away} homeVal={teamOverall(home)} awayVal={teamOverall(away)} />
            <CompareRow label="Attack" home={home} away={away} homeVal={teamAttack(home)} awayVal={teamAttack(away)} />
            <CompareRow label="Defense" home={home} away={away} homeVal={teamDefense(home)} awayVal={teamDefense(away)} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <TeamFooter agg={homeAgg} />
            <TeamFooter agg={awayAgg} align="right" />
          </div>
        </div>
      )}
    </Card>
  )
}

function GridVisionCard({
  prediction,
  home,
  away,
  isNational,
}: {
  prediction: ReturnType<typeof gridVisionPredict>
  home: Team
  away: Team
  isNational: boolean
}) {
  const accent = prediction.winner ? teamColor(prediction.winner.short) : "#8b95a5"
  return (
    <div className="rounded-lg border border-primary/30 bg-primary/5 p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="grid size-7 place-items-center rounded-md bg-primary/15 text-primary">
            <BrainCircuit className="size-4" />
          </span>
          <div>
            <p className="text-sm font-semibold">
              GridVision prediction <span className="text-xs font-normal text-muted-foreground">(Model Estimate)</span>
            </p>
            <p className="text-[11px] text-muted-foreground">Tactical model call derived from {isNational ? "national team" : "club"} Elo, attack &amp; defense ratings</p>
          </div>
        </div>
        <div className="text-right">
          <div className="font-mono text-xl font-semibold tabular-nums" style={{ color: accent }}>
            {prediction.confidence}%
          </div>
          <div className="text-[11px] text-muted-foreground">estimated confidence</div>
        </div>
      </div>

      <div className="mt-3 h-2 overflow-hidden rounded-full bg-secondary">
        <div className="h-full rounded-full transition-all" style={{ width: `${prediction.confidence}%`, backgroundColor: accent }} />
      </div>

      <p className="mt-3 text-sm font-medium">{prediction.headline}</p>
      <p className="mt-1 text-xs text-muted-foreground">
        <span className="font-medium text-foreground">Game plan:</span> {prediction.strategy}
      </p>
      <ul className="mt-2 space-y-1">
        {prediction.rationale.map((line, i) => (
          <li key={i} className="flex gap-2 text-[11px] text-muted-foreground">
            <span className="mt-1 size-1 shrink-0 rounded-full bg-primary/60" aria-hidden />
            {line}
          </li>
        ))}
      </ul>
    </div>
  )
}

function TeamSelect({
  label,
  value,
  onChange,
  disabledId,
  teams,
  team,
  align = "left",
}: {
  label: string
  value: number
  onChange: (v: number) => void
  disabledId: number
  teams: Team[]
  team: Team
  align?: "left" | "right"
}) {
  return (
    <div className="space-y-1.5">
      <label className={`block text-xs font-medium text-muted-foreground ${align === "right" ? "text-right" : ""}`}>{label}</label>
      <Select value={String(value)} onValueChange={(v) => onChange(Number(v))}>
        <SelectTrigger className="w-full">
          <SelectValue aria-label={team.name}>
            <span className="flex items-center gap-2">
              <span className="size-3 shrink-0 rounded-sm" style={{ backgroundColor: teamColor(team.short) }} aria-hidden />
              {team.name}
            </span>
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {teams.map((t) => (
            <SelectItem key={t.id} value={String(t.id)} disabled={t.id === disabledId}>
              <span className="flex items-center gap-2">
                <span className="size-3 shrink-0 rounded-sm" style={{ backgroundColor: teamColor(t.short) }} aria-hidden />
                {t.name}
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

function TeamBadge({ team, align = "left" }: { team: Team; align?: "left" | "right" }) {
  return (
    <div className={`flex flex-1 min-w-0 items-center gap-2 sm:gap-3 ${align === "right" ? "flex-row-reverse text-right" : ""}`}>
      <span className="grid size-10 sm:size-12 shrink-0 place-items-center rounded-lg font-mono text-xs sm:text-sm font-bold text-black" style={{ backgroundColor: teamColor(team.short) }}>
        {team.short}
      </span>
      <div className={`min-w-0 flex-1 ${align === "right" ? "text-right" : ""}`}>
        <div className="text-xs sm:text-sm font-semibold leading-tight truncate">{team.name}</div>
        <div className="font-mono text-[11px] sm:text-xs text-muted-foreground">Elo {team.elo}</div>
      </div>
    </div>
  )
}

function CompareRow({
  label,
  home,
  away,
  homeVal,
  awayVal,
}: {
  label: string
  home: Team
  away: Team
  homeVal: number
  awayVal: number
}) {
  const total = homeVal + awayVal || 1
  const homePct = (homeVal / total) * 100
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between font-mono text-xs">
        <span className="tabular-nums" style={{ color: teamColor(home.short) }}>{homeVal}</span>
        <span className="text-muted-foreground">{label}</span>
        <span className="tabular-nums" style={{ color: teamColor(away.short) }}>{awayVal}</span>
      </div>
      <div className="flex h-2 overflow-hidden rounded-full bg-secondary">
        <div className="h-full" style={{ width: `${homePct}%`, backgroundColor: teamColor(home.short) }} />
        <div className="h-full flex-1" style={{ backgroundColor: teamColor(away.short) }} />
      </div>
    </div>
  )
}

function TeamFooter({
  agg,
  align = "left",
}: {
  agg: ReturnType<typeof teamAggregates>[number] | undefined
  align?: "left" | "right"
}) {
  if (!agg) return null
  return (
    <div className={`space-y-1.5 ${align === "right" ? "text-right" : ""}`}>
      <div className="text-xs font-medium text-muted-foreground">{agg.team.name} squad</div>
      <div className={`flex items-center gap-2 ${align === "right" ? "justify-end" : ""}`}>
        <Target className="size-3.5 text-[var(--color-accent)]" />
        <span className="font-mono text-sm tabular-nums">{agg.avgOverall} avg OVR</span>
      </div>
      {agg.topPlayer ? (
        <p className="text-[11px] text-muted-foreground">
          Top: {agg.topPlayer.name} ({agg.topPlayer.overall} OVR)
        </p>
      ) : null}
    </div>
  )
}
