export function Pitch({ children }: { children?: React.ReactNode }) {
  return (
    <div className="relative aspect-[68/105] w-full overflow-hidden rounded-xl bg-[linear-gradient(180deg,#12692c_0%,#0f5c26_100%)] ring-1 ring-inset ring-white/10">
      {/* mowing stripes */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            "repeating-linear-gradient(180deg, transparent 0 9%, rgba(255,255,255,0.16) 9% 18%)",
        }}
      />
      <svg className="absolute inset-0 h-full w-full" viewBox="0 0 68 105" preserveAspectRatio="none">
        <g fill="none" stroke="white" strokeOpacity="0.5" strokeWidth="0.4">
          <rect x="2" y="2" width="64" height="101" />
          <line x1="2" y1="52.5" x2="66" y2="52.5" />
          <circle cx="34" cy="52.5" r="9" />
          <circle cx="34" cy="52.5" r="0.6" fill="white" stroke="none" />
          {/* top box */}
          <rect x="15.5" y="2" width="37" height="16" />
          <rect x="25" y="2" width="18" height="6" />
          <circle cx="34" cy="12" r="0.6" fill="white" stroke="none" />
          {/* bottom box */}
          <rect x="15.5" y="87" width="37" height="16" />
          <rect x="25" y="97" width="18" height="6" />
          <circle cx="34" cy="93" r="0.6" fill="white" stroke="none" />
        </g>
      </svg>
      {children}
    </div>
  )
}
