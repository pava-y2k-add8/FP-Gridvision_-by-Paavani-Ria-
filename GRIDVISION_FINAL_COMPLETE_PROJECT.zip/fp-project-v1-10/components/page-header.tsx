import type React from "react"

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string
  title: string
  description?: string
  actions?: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-4 border-b border-border px-4 py-5 sm:flex-row sm:items-end sm:justify-between sm:px-6 sm:py-6 md:px-8">
      <div className="min-w-0 space-y-1">
        {eyebrow ? (
          <p className="font-mono text-xs uppercase tracking-widest text-primary">{eyebrow}</p>
        ) : null}
        <h1 className="text-xl font-semibold tracking-tight text-balance sm:text-2xl md:text-3xl break-words">{title}</h1>
        {description ? (
          <p className="max-w-2xl text-xs sm:text-sm text-muted-foreground text-pretty">{description}</p>
        ) : null}
      </div>
      {actions ? <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  )
}
