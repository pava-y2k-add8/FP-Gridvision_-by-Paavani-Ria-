"use client"

import { useMemo } from "react"
import { Crosshair, ArrowUp, ArrowDown, Minus } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  evaluateShot,
  RECOMMENDATION_TONE,
  type AssistMethod,
  type BodyPart,
  type KeeperPosition,
  type Pressure,
  type ShotContext,
  type ShotLocation,
  type Situation,
} from "@/lib/bayesian"

const TONE_CLASS: Record<"good" | "warn" | "bad", string> = {
  good: "bg-[oklch(0.75_0.17_150)] text-black",
  warn: "bg-[oklch(0.8_0.15_85)] text-black",
  bad: "bg-[oklch(0.65_0.2_25)] text-white",
}

const LOCATIONS: { v: ShotLocation; label: string }[] = [
  { v: "six-yard", label: "Six-yard box" },
  { v: "penalty-spot", label: "Penalty spot" },
  { v: "box-edge", label: "Edge of box" },
  { v: "outside-box", label: "Outside box" },
  { v: "long-range", label: "Long range" },
]
const ASSISTS: { v: AssistMethod; label: string }[] = [
  { v: "through-ball", label: "Through ball" },
  { v: "pass", label: "Lay-off pass" },
  { v: "solo", label: "Solo run" },
  { v: "cross", label: "Cross" },
  { v: "headed-pass", label: "Headed pass" },
]
const SITUATIONS: { v: Situation; label: string }[] = [
  { v: "open-play", label: "Open play" },
  { v: "fast-break", label: "Fast break" },
  { v: "set-piece", label: "Set piece" },
  { v: "corner", label: "Corner" },
]
const BODIES: { v: BodyPart; label: string }[] = [
  { v: "strong-foot", label: "Strong foot" },
  { v: "weak-foot", label: "Weak foot" },
  { v: "head", label: "Header" },
]
const KEEPERS: { v: KeeperPosition; label: string }[] = [
  { v: "rushing-out", label: "Rushing out" },
  { v: "off-line", label: "Off the line" },
  { v: "on-line", label: "On the line" },
  { v: "well-set", label: "Well set" },
]
const PRESSURES: { v: Pressure; label: string }[] = [
  { v: "none", label: "No pressure" },
  { v: "light", label: "Light pressure" },
  { v: "heavy", label: "Heavy pressure" },
]

function Row<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string
  value: T
  options: { v: T; label: string }[]
  onChange: (v: T) => void
}) {
  return (
    <div className="space-y-1">
      <label className="font-mono text-[10px] uppercase tracking-wide text-muted-foreground">{label}</label>
      <Select value={value} onValueChange={(v) => onChange(v as T)}>
        <SelectTrigger className="h-8 w-full text-xs">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {options.map((o) => (
            <SelectItem key={o.v} value={o.v} className="text-xs">
              {o.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

export function ShootingAdvisor({
  ctx,
  onChange,
  shooter,
}: {
  ctx: ShotContext
  onChange: (ctx: ShotContext) => void
  shooter?: string
}) {
  const verdict = useMemo(() => evaluateShot(ctx), [ctx])
  const tone = RECOMMENDATION_TONE[verdict.recommendation]
  const set = (patch: Partial<ShotContext>) => onChange({ ...ctx, ...patch })

  return (
    <Card className="gap-4 p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Crosshair className="size-4 text-[var(--color-accent)]" />
          <h3 className="text-sm font-semibold">Bayesian shot advisor</h3>
        </div>
        <Badge variant="secondary" className="font-mono text-[10px]">
          {shooter ? shooter : "select a scenario"}
        </Badge>
      </div>

      <p className="text-[11px] leading-relaxed text-muted-foreground">
        A Bayesian decision network weighs location, assist, keeper position and pressure to advise whether to shoot —
        adapted from the football decision-making tool. Tune the scenario and it updates on the pitch.
      </p>

      <div className="grid grid-cols-2 gap-2.5">
        <Row label="Location" value={ctx.location} options={LOCATIONS} onChange={(v) => set({ location: v })} />
        <Row label="Assist" value={ctx.assist} options={ASSISTS} onChange={(v) => set({ assist: v })} />
        <Row label="Situation" value={ctx.situation} options={SITUATIONS} onChange={(v) => set({ situation: v })} />
        <Row label="Contact" value={ctx.body} options={BODIES} onChange={(v) => set({ body: v })} />
        <Row label="Keeper" value={ctx.keeper} options={KEEPERS} onChange={(v) => set({ keeper: v })} />
        <Row label="Pressure" value={ctx.pressure} options={PRESSURES} onChange={(v) => set({ pressure: v })} />
      </div>

      <div className="flex items-center gap-4 rounded-lg border border-border bg-secondary/40 p-3">
        <div className="flex flex-col items-center">
          <span className={`rounded-md px-2.5 py-1 text-sm font-bold ${TONE_CLASS[tone]}`}>
            {verdict.recommendation}
          </span>
          <span className="mt-1 font-mono text-[9px] uppercase tracking-wide text-muted-foreground" title="Bayesian model estimate">
            {Math.round(verdict.confidence * 100)}% estimated
          </span>
        </div>
        <div className="flex-1 space-y-2">
          <Meter label="Goal chance (est.)" value={verdict.goalProbability} accent="var(--color-primary)" />
          <Meter label="Keep possession (est.)" value={verdict.passSuccess} accent="var(--color-muted-foreground)" />
        </div>
      </div>

      <div className="space-y-1">
        {verdict.drivers.map((d, i) => (
          <div key={i} className="flex items-start gap-2 text-[11px]">
            <span className="mt-0.5">
              {d.effect === "boost" ? (
                <ArrowUp className="size-3 text-[oklch(0.75_0.17_150)]" />
              ) : d.effect === "drag" ? (
                <ArrowDown className="size-3 text-[oklch(0.65_0.2_25)]" />
              ) : (
                <Minus className="size-3 text-muted-foreground" />
              )}
            </span>
            <span className="text-foreground/85">
              <span className="font-medium text-foreground">{d.label}:</span> {d.detail}
            </span>
          </div>
        ))}
      </div>
    </Card>
  )
}

function Meter({ label, value, accent }: { label: string; value: number; accent: string }) {
  return (
    <div>
      <div className="mb-0.5 flex items-center justify-between text-[10px]">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono font-semibold tabular-nums">{Math.round(value * 100)}%</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-background">
        <div className="h-full rounded-full" style={{ width: `${Math.round(value * 100)}%`, backgroundColor: accent }} />
      </div>
    </div>
  )
}
