"use client"

import type React from "react"
import { Star, TrendingUp, AlertTriangle, Compass, Gauge, Zap } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { FOCUS_LABEL, PRESS_LABEL, TEMPO_LABEL, type TacticalPlan } from "@/lib/tactics"

export function TacticalPlanView({ plan }: { plan: TacticalPlan }) {
  return (
    <div className="space-y-4">
      <p className="text-sm font-medium leading-relaxed text-foreground">{plan.summary}</p>

      <div className="grid grid-cols-3 gap-2">
        <Chip icon={Compass} label="Focus" value={FOCUS_LABEL[plan.attackFocus]} />
        <Chip icon={Gauge} label="Shape" value={PRESS_LABEL[plan.press]} />
        <Chip icon={Zap} label="Tempo" value={TEMPO_LABEL[plan.tempo]} />
      </div>

      <p className="text-[13px] leading-relaxed text-foreground/85">{plan.shape}</p>

      <div className="flex items-start gap-2 rounded-lg border border-[var(--color-accent)]/30 bg-[var(--color-accent)]/10 p-3">
        <Star className="mt-0.5 size-4 shrink-0 text-[var(--color-accent)]" />
        <p className="text-[13px] leading-relaxed">
          <span className="font-semibold">Key player: </span>
          {plan.keyPlayer}
        </p>
      </div>

      <div className="space-y-1.5">
        <p className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wide text-muted-foreground">
          <TrendingUp className="size-3.5 text-[oklch(0.75_0.17_150)]" /> Strengths
        </p>
        {plan.strengths.map((s, i) => (
          <p key={i} className="pl-5 text-[13px] leading-relaxed text-foreground/85">
            {s}
          </p>
        ))}
      </div>

      <div className="space-y-1.5">
        <p className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wide text-muted-foreground">
          <AlertTriangle className="size-3.5 text-[oklch(0.8_0.15_85)]" /> Watch-outs
        </p>
        {plan.watchOuts.map((s, i) => (
          <p key={i} className="pl-5 text-[13px] leading-relaxed text-foreground/85">
            {s}
          </p>
        ))}
      </div>
    </div>
  )
}

function Chip({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
}) {
  return (
    <div className="rounded-lg border border-border bg-secondary/40 p-2.5">
      <div className="flex items-center gap-1 text-muted-foreground">
        <Icon className="size-3" />
        <span className="font-mono text-[9px] uppercase tracking-wide">{label}</span>
      </div>
      <p className="mt-1 text-[11px] font-semibold leading-tight">{value}</p>
    </div>
  )
}
