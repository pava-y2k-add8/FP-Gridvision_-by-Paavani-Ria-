"use client"

import type React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import useSWR, { mutate } from "swr"
import {
  LayoutDashboard,
  Users,
  Trophy,
  Hexagon,
  BrainCircuit,
  Swords,
  CalendarDays,
  CheckCircle2,
  AlertCircle,
  LogIn,
  LogOut,
  UserCheck,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { SeasonProvider, SeasonSwitcher } from "@/components/season-context"
import { getCurrentUserAction, logoutAction } from "@/app/actions/auth"

const NAV = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/calendar", label: "Events Calendar", icon: CalendarDays },
  { href: "/players", label: "Player Explorer", icon: Users },
  { href: "/strategy", label: "Strategy Builder", icon: Swords },
  { href: "/overview", label: "Clubs & Leagues", icon: Trophy },
]

export function AppFrame({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const { data: user } = useSWR("user-session", getCurrentUserAction)

  async function handleLogout() {
    await logoutAction()
    mutate("user-session", null)
    window.location.href = "/"
  }

  return (
    <SeasonProvider>
      <div className="flex min-h-screen bg-background">
        <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-border bg-sidebar md:flex">
          <div className="flex items-center gap-2.5 px-5 py-5">
            <div className="grid size-9 place-items-center rounded-lg bg-primary text-primary-foreground">
              <Hexagon className="size-5" />
            </div>
            <div className="leading-tight">
              <p className="font-mono text-sm font-semibold tracking-tight">GridVision</p>
              <p className="text-[11px] text-muted-foreground">Player Ratings Analytics</p>
            </div>
          </div>

          <div className="px-3 pb-2">
            <SeasonSwitcher className="w-full" />
          </div>

          <nav className="flex flex-1 flex-col gap-1 px-3 py-2">
            {NAV.map((item) => {
              const active = pathname === item.href
              const Icon = item.icon
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                    active
                      ? "bg-primary/15 text-primary"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                  )}
                >
                  <Icon className="size-[18px]" />
                  {item.label}
                </Link>
              )
            })}
          </nav>

          <div className="mx-3 mb-3 rounded-lg border border-border bg-card p-3">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <BrainCircuit className="size-3.5 text-[var(--color-accent)]" />
              GridVision AI coaching
            </div>
            <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
              Adjust your lineup and click &quot;Evaluate Strategy&quot; to receive tactical analysis and chemistry feedback.
            </p>
          </div>

          {/* User Account / Auth Section */}
          <div className="mx-3 mb-4 border-t border-border pt-3">
            {user ? (
              <div className="space-y-2 rounded-lg bg-card/60 p-2.5 border border-border">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="grid size-7 shrink-0 place-items-center rounded-full bg-primary/20 text-xs font-bold text-primary">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1 leading-tight">
                      <p className="truncate text-xs font-semibold text-foreground">{user.name}</p>
                      <p className="truncate text-[10px] text-muted-foreground">{user.email}</p>
                    </div>
                  </div>
                  {user.emailVerified ? (
                    <span title="Email Verified" className="flex items-center text-[10px] text-emerald-400 font-medium">
                      <CheckCircle2 className="size-3.5" />
                    </span>
                  ) : (
                    <Link
                      href="/verify-email"
                      title="Verify your email"
                      className="flex items-center text-[10px] text-amber-400 hover:underline"
                    >
                      <AlertCircle className="size-3.5" />
                    </Link>
                  )}
                </div>

                <div className="flex items-center justify-between pt-1 text-[11px]">
                  <span className="text-muted-foreground">
                    {user.emailVerified ? "Verified Account" : "Pending Verification"}
                  </span>
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <LogOut className="size-3" /> Log out
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex gap-2">
                <Link
                  href="/login"
                  className="flex-1 flex items-center justify-center gap-1 rounded-md border border-border px-2 py-1.5 text-xs font-medium text-foreground hover:bg-secondary transition-colors"
                >
                  <LogIn className="size-3.5" /> Log In
                </Link>
                <Link
                  href="/signup"
                  className="flex-1 flex items-center justify-center gap-1 rounded-md bg-primary px-2 py-1.5 text-xs font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
                >
                  <UserCheck className="size-3.5" /> Sign Up
                </Link>
              </div>
            )}
          </div>
        </aside>

        {/* Main content column with horizontal overflow shielding */}
        <div className="flex min-w-0 flex-1 flex-col overflow-x-hidden">
          <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-border bg-sidebar/80 px-4 py-3 backdrop-blur md:hidden">
            <div className="grid size-8 place-items-center rounded-lg bg-primary text-primary-foreground">
              <Hexagon className="size-4" />
            </div>
            <span className="font-mono text-sm font-semibold">GridVision</span>
            <div className="ml-auto flex items-center gap-2">
              <SeasonSwitcher className="h-9" />
              {user ? (
                <button
                  onClick={handleLogout}
                  className="rounded-md border border-border px-2 py-1 text-xs text-muted-foreground hover:text-foreground"
                >
                  Log out
                </button>
              ) : (
                <Link
                  href="/login"
                  className="rounded-md bg-primary px-2.5 py-1 text-xs font-medium text-primary-foreground"
                >
                  Log In
                </Link>
              )}
            </div>
          </header>

          <nav className="sticky top-[57px] z-10 flex gap-1 overflow-x-auto border-b border-border bg-sidebar/80 px-3 py-2 backdrop-blur md:hidden [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
            {NAV.map((item) => {
              const active = pathname === item.href
              const Icon = item.icon
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors",
                    active ? "bg-primary/15 text-primary" : "text-muted-foreground",
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              )
            })}
          </nav>

          <main className="min-w-0 flex-1">{children}</main>
        </div>
      </div>
    </SeasonProvider>
  )
}
