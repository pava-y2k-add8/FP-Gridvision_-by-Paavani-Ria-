"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import {
  X,
  Globe,
  Shield,
  Zap,
  Sparkles,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  AlertCircle,
  Swords,
  Users,
  Info,
  BarChart3,
  ShieldCheck,
  Flame,
  Compass,
  ArrowRight,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { PlayerAvatar } from "@/components/player-avatar"
import { teamColor, type Season, type Team } from "@/lib/data"
import { findRealPlayerByName } from "@/lib/players"
import { analyzeSquadStyle, type StyleType } from "@/lib/style-analysis"

interface ClubStylePanelProps {
  team: Team | null
  season: Season
  onClose: () => void
}

const STYLE_ICONS: Record<StyleType, typeof Compass> = {
  Possession: Compass,
  Counterattack: Zap,
  "High Pressing": Flame,
  "Defensive Organisation": ShieldCheck,
}

export function ClubStylePanel({ team, season, onClose }: ClubStylePanelProps) {
  const [showHowCalculated, setShowHowCalculated] = useState(false)

  // Close on Escape key press
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") onClose()
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [onClose])

  // Prevent background scroll when panel is open
  useEffect(() => {
    if (team) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }
    return () => {
      document.body.style.overflow = ""
    }
  }, [team])

  const analysis = useMemo(() => {
    if (!team) return null
    return analyzeSquadStyle(team, season)
  }, [team, season])

  if (!team || !analysis) return null

  const PrimaryIcon = STYLE_ICONS[analysis.primaryStyle.type]
  const AlternativeIcon = analysis.alternativeStyle
    ? STYLE_ICONS[analysis.alternativeStyle.type]
    : null

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Side Panel Drawer */}
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="club-style-title"
        className="relative z-50 flex h-full w-full max-w-2xl flex-col bg-card border-l border-border shadow-2xl overflow-hidden animate-in slide-in-from-right duration-200"
      >
        {/* Panel Header */}
        <div className="flex items-center justify-between border-b border-border bg-sidebar/50 px-5 py-4">
          <div className="flex items-center gap-3 min-w-0">
            <span
              className="grid size-9 shrink-0 place-items-center rounded-lg font-mono text-xs font-bold text-black shadow-xs"
              style={{ backgroundColor: teamColor(team.short) }}
            >
              {team.short}
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2
                  id="club-style-title"
                  className="truncate text-base font-bold text-foreground"
                >
                  {team.name}
                </h2>
                <Badge
                  variant="outline"
                  className="text-[11px] font-mono gap-1 border-border/80"
                >
                  {analysis.isNationalTeam ? (
                    <>
                      <Globe className="size-3 text-primary" />
                      <span>National Team</span>
                    </>
                  ) : (
                    <>
                      <Shield className="size-3 text-primary" />
                      <span>Club</span>
                    </>
                  )}
                </Badge>
                <Badge variant="secondary" className="text-[11px] font-mono">
                  {analysis.datasetSeason}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                {analysis.totalSquadSize} players analyzed • {analysis.activeCount} active in 2026
                {analysis.retiredCount > 0 ? ` (${analysis.retiredCount} retired)` : ""}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            aria-label="Close panel"
            className="rounded-full size-8 shrink-0 text-muted-foreground hover:text-foreground"
          >
            <X className="size-4" />
          </Button>
        </div>

        {/* Panel Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 [scrollbar-width:thin]">
          {/* Section: Data Accuracy & Source Disclaimer */}
          <div className="rounded-lg border border-primary/20 bg-primary/5 p-3.5 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-primary">
              <Info className="size-4 shrink-0" />
              <span>Suggested style based on squad ratings—not verified match tactics.</span>
            </div>
            <p className="text-[11px] leading-relaxed text-muted-foreground">
              {analysis.historicalNotice}
            </p>
            <div className="pt-1 flex items-center justify-between text-[11px] font-mono text-muted-foreground/80 border-t border-border/40">
              <span>Source: {analysis.datasetLabel}</span>
              <span>Elo: {team.elo}</span>
            </div>
          </div>

          {/* Section: Suggested Playing Style */}
          <div className="space-y-3.5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold tracking-tight">What style suits this squad?</h3>
                <p className="text-xs text-muted-foreground">
                  Derived from player attributes across positional lines.
                </p>
              </div>
            </div>

            {/* Primary Suggested Style */}
            <Card className="p-4 border-primary/30 bg-card shadow-sm space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="grid size-9 place-items-center rounded-lg bg-primary/10 text-primary">
                    <PrimaryIcon className="size-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold">{analysis.primaryStyle.label}</span>
                      <Badge className="bg-primary text-primary-foreground text-[10px] uppercase font-mono tracking-wider h-5 px-1.5">
                        Primary Style
                      </Badge>
                    </div>
                    <span className="font-mono text-xs text-muted-foreground">
                      Index Score: {analysis.primaryStyle.score} / 100
                    </span>
                  </div>
                </div>
              </div>

              <p className="text-xs leading-relaxed text-muted-foreground">
                {analysis.primaryStyle.description}
              </p>

              <div className="rounded-md bg-secondary/50 p-2.5 space-y-1">
                <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  Supporting Attributes
                </span>
                <ul className="space-y-0.5">
                  {analysis.primaryStyle.keyFactors.map((f, i) => (
                    <li key={i} className="text-[11px] text-foreground/90 flex items-center gap-1.5">
                      <span className="size-1 rounded-full bg-primary" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Card>

            {/* Alternative Suggested Style (if available) */}
            {analysis.alternativeStyle && (
              <Card className="p-4 border-border bg-card shadow-xs space-y-2.5">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="grid size-8 place-items-center rounded-lg bg-secondary text-foreground">
                      {AlternativeIcon && <AlternativeIcon className="size-4" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold">{analysis.alternativeStyle.label}</span>
                        <Badge variant="outline" className="text-[10px] font-mono border-border h-5 px-1.5">
                          Alternative Option
                        </Badge>
                      </div>
                      <span className="font-mono text-xs text-muted-foreground">
                        Index Score: {analysis.alternativeStyle.score} / 100
                      </span>
                    </div>
                  </div>
                </div>

                <p className="text-xs leading-relaxed text-muted-foreground">
                  {analysis.alternativeStyle.description}
                </p>
              </Card>
            )}

            {/* Four-Style Metric Comparison */}
            <div className="rounded-lg border border-border p-3 space-y-2.5">
              <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground block">
                Tactical Style Profile Breakdown
              </span>
              <div className="space-y-2">
                {analysis.allStyles.map((s) => (
                  <div key={s.type} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-medium">
                      <span>{s.label}</span>
                      <span className="font-mono tabular-nums text-muted-foreground">{s.score} / 100</span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                      <div
                        className="h-full rounded-full bg-primary transition-all"
                        style={{
                          width: `${s.score}%`,
                          opacity: s.type === analysis.primaryStyle.type ? 1 : 0.6,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Expandable: "How this is calculated" */}
            <div className="border border-border/80 rounded-lg overflow-hidden bg-card/50">
              <button
                type="button"
                onClick={() => setShowHowCalculated((prev) => !prev)}
                className="w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/30 transition-colors"
              >
                <span className="flex items-center gap-1.5">
                  <BarChart3 className="size-3.5 text-primary" />
                  How this is calculated
                </span>
                {showHowCalculated ? <ChevronUp className="size-4" /> : <ChevronDown className="size-4" />}
              </button>

              {showHowCalculated && (
                <div className="border-t border-border/80 p-3.5 text-xs text-muted-foreground space-y-2 bg-card">
                  <p className="leading-relaxed">
                    Style recommendations are computed transparently from the squad’s recorded ratings and do not represent arbitrary win probabilities or live real-world match tactics:
                  </p>
                  <ul className="space-y-1.5 list-disc list-inside text-[11px] leading-relaxed">
                    {analysis.methodologyNotes.map((note, idx) => (
                      <li key={idx}>{note}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* Section: Strengths and Limitations */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold tracking-tight">Strengths & Relative Limitations</h3>

            <div className="grid gap-3 sm:grid-cols-2">
              {/* Strengths */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wide text-emerald-500">
                  <CheckCircle2 className="size-3.5" />
                  <span>Key Squad Strengths</span>
                </div>
                {analysis.strengths.length > 0 ? (
                  analysis.strengths.map((st, i) => (
                    <div key={i} className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-foreground">{st.title}</span>
                        <span className="font-mono text-[10px] text-emerald-400 font-bold tabular-nums">
                          {st.teamValue}
                        </span>
                      </div>
                      <p className="text-[11px] leading-relaxed text-muted-foreground">{st.detail}</p>
                    </div>
                  ))
                ) : (
                  <div className="rounded-lg border border-border p-3 text-xs text-muted-foreground italic">
                    {analysis.hasSufficientData ? "Balanced squad profile without extreme statistical outliers." : "Insufficient data"}
                  </div>
                )}
              </div>

              {/* Relative Limitations */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wide text-amber-500">
                  <AlertCircle className="size-3.5" />
                  <span>Relative Limitations</span>
                </div>
                {analysis.limitations.length > 0 ? (
                  analysis.limitations.map((lim, i) => (
                    <div key={i} className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-foreground">{lim.title}</span>
                        <span className="font-mono text-[10px] text-amber-400 font-bold tabular-nums">
                          {lim.teamValue}
                        </span>
                      </div>
                      <p className="text-[11px] leading-relaxed text-muted-foreground">{lim.detail}</p>
                    </div>
                  ))
                ) : (
                  <div className="rounded-lg border border-border p-3 text-xs text-muted-foreground italic">
                    {analysis.hasSufficientData ? "No statistically pronounced relative weaknesses." : "Insufficient data"}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Section: Key Players Supporting This Style */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold tracking-tight">
              Key Players Supporting {analysis.primaryStyle.label}
            </h3>
            <p className="text-xs text-muted-foreground">
              Highest-rated squad members whose attribute profiles anchor this playing style.
            </p>

            <div className="grid gap-2.5 sm:grid-cols-3">
              {analysis.keyPlayers.map(({ player, roleExplanation, keyAttributes }) => {
                const real = findRealPlayerByName(player.name, player.club, player.nationality)
                return (
                  <Card key={player.id} className="p-3 space-y-2.5 border-border bg-card shadow-xs">
                    <div className="flex items-center gap-2.5">
                      <PlayerAvatar
                        name={player.name}
                        image={real?.image}
                        color={teamColor(player.team)}
                        size="sm"
                        shape="circle"
                      />
                      <div className="min-w-0 flex-1 leading-tight">
                      <p className="truncate text-xs font-semibold text-foreground">{player.name}</p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 font-mono">
                          {player.pos}
                        </Badge>
                        <span className="font-mono text-[11px] font-semibold text-primary">
                          {player.overall} OVR
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-[11px] text-muted-foreground leading-snug line-clamp-2">
                    {roleExplanation}
                  </p>

                  <div className="flex flex-wrap gap-1 border-t border-border/50 pt-2">
                    {keyAttributes.map((attr, idx) => (
                      <span
                        key={idx}
                        className="font-mono text-[9px] rounded bg-secondary px-1.5 py-0.5 text-foreground/80 tabular-nums"
                      >
                        {attr.name.split(" ")[0]}: {attr.value}
                      </span>
                    ))}
                  </div>
                </Card>
              )
            })}
          </div>
          </div>

          {/* Section: Strategy Builder Connection */}
          <Card className="p-4 border-border bg-card/60 space-y-3">
            <div className="flex items-center gap-2">
              <Swords className="size-4 text-primary" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-foreground">
                Tactical Pitch Simulation
              </h4>
            </div>

            <p className="text-xs text-muted-foreground leading-relaxed">
              Open {team.name} in the Strategy Builder to test this {analysis.primaryStyle.label.toLowerCase()} style on a virtual tactical pitch. Shape the XI, position roles, and click “Evaluate Strategy” to get tactical feedback.
            </p>

            {analysis.activeCount < 11 && (
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200 flex items-start gap-2">
                <AlertCircle className="size-4 shrink-0 text-amber-400 mt-0.5" />
                <p className="leading-relaxed">
                  <strong className="text-amber-300">Limited Active Players:</strong> This historical squad has only {analysis.activeCount} verified active players in 2026 ({analysis.retiredCount} retired players are excluded to respect active-player eligibility rules).
                </p>
              </div>
            )}

            <div className="pt-1">
              <Link href={`/strategy?teamId=${team.id}&season=${season}`}>
                <Button className="w-full font-semibold gap-2">
                  <Swords className="size-4" />
                  <span>Build a strategy with {team.name}</span>
                  <ArrowRight className="size-4 ml-auto" />
                </Button>
              </Link>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
