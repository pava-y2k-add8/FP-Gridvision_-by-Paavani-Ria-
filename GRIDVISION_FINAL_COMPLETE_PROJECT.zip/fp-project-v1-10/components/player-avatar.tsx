"use client"

import { useState } from "react"
import { initials } from "@/lib/players"
import { cn } from "@/lib/utils"

export interface PlayerAvatarProps {
  name: string
  image?: string | null
  color?: string
  size?: "xs" | "sm" | "md" | "list" | "lg" | "xl" | "profile"
  shape?: "portrait" | "square" | "circle"
  fit?: "cover" | "contain"
  className?: string
  alt?: string
}

// Portrait sizes preserve the natural 10:13 aspect ratio of football headshots
const PORTRAIT_CLASSES: Record<string, string> = {
  xs: "w-7 h-8 text-[9px] rounded-md",
  sm: "w-9 h-11 text-[10px] rounded-md",
  list: "w-12 h-14 text-xs rounded-lg", // 48px width x 56px height
  md: "w-12 h-14 text-xs rounded-lg",   // 48px width x 56px height
  lg: "w-14 h-16 text-sm rounded-xl",   // 56px width x 64px height
  xl: "w-20 h-24 text-base rounded-xl font-bold",
  profile: "w-28 h-36 sm:w-32 sm:h-40 md:w-36 md:h-44 text-2xl rounded-2xl font-bold shadow-lg",
}

const SQUARE_CLASSES: Record<string, string> = {
  xs: "size-7 text-[9px] rounded-md",
  sm: "size-9 text-[10px] rounded-md",
  list: "size-12 text-xs rounded-lg", // 48px x 48px
  md: "size-12 text-xs rounded-lg",
  lg: "size-14 text-sm rounded-xl",  // 56px x 56px
  xl: "size-20 text-base rounded-xl font-bold",
  profile: "size-32 sm:size-40 text-2xl rounded-2xl font-bold shadow-lg",
}

export function PlayerAvatar({
  name,
  image,
  color,
  size = "list",
  shape = "portrait",
  fit = "cover",
  className,
  alt = "",
}: PlayerAvatarProps) {
  // If size is profile, try the original resolution first if available
  const initialUrl = (size === "profile" && image && image.includes("/portrait/big/"))
    ? image.replace("/portrait/big/", "/portrait/original/")
    : (image || null)

  const [currentUrl, setCurrentUrl] = useState<string | null>(initialUrl)
  const [triedFallback, setTriedFallback] = useState(false)
  const [hasError, setHasError] = useState(false)

  const sizeClass = (shape === "square" || shape === "circle")
    ? (SQUARE_CLASSES[size] || SQUARE_CLASSES.list)
    : (PORTRAIT_CLASSES[size] || PORTRAIT_CLASSES.list)

  const shapeClass = shape === "circle" ? "!rounded-full" : ""

  const handleImageError = () => {
    // If we tried original resolution on profile, fall back to big resolution
    if (size === "profile" && !triedFallback && currentUrl && currentUrl.includes("/portrait/original/")) {
      setTriedFallback(true)
      setCurrentUrl(currentUrl.replace("/portrait/original/", "/portrait/big/"))
      return
    }
    setHasError(true)
  }

  const showImage = Boolean(currentUrl && currentUrl.trim() && !hasError)

  return (
    <span
      className={cn(
        "grid shrink-0 place-items-center overflow-hidden border border-border/80 bg-secondary/80 font-mono font-semibold select-none",
        sizeClass,
        shapeClass,
        className
      )}
      style={color ? { color } : undefined}
    >
      {showImage ? (
        // eslint-disable-next-line @next/next/no-img-element
          <img
            src={currentUrl!}
            alt={alt || name}
            loading="lazy"
            referrerPolicy="no-referrer"
            style={{ objectPosition: fit === "contain" ? "center" : "50% 14%" }}
            className={cn(
              "size-full transition-opacity duration-200",
              fit === "contain"
                ? "object-contain object-center p-0.5"
                : "object-cover object-[center_14%]"
            )}
            onError={handleImageError}
          />
      ) : (
        <span className="leading-none">{initials(name)}</span>
      )}
    </span>
  )
}
