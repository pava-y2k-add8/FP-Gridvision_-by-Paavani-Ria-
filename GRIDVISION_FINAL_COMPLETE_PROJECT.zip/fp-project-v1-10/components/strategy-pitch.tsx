"use client"

import { useRef, useState } from "react"
import { teamColor, type CareerPlayer } from "@/lib/data"
import { findRealPlayerByName, isCareerPlayerRetired } from "@/lib/players"
import {
  FOCUS_BAND,
  FOCUS_LABEL,
  PRESS_LABEL,
  PRESS_LINE_Y,
  type TacticalPlan,
} from "@/lib/tactics"

export interface Slot {
  id: string
  line: "GK" | "DEF" | "MID" | "FWD"
  label: string
  x: number
  y: number
}

export interface ShotMarker {
  x: number
  y: number
  label: string
  tone: "good" | "warn" | "bad"
}

const SHOT_COLOR: Record<ShotMarker["tone"], string> = {
  good: "oklch(0.75 0.17 150)",
  warn: "oklch(0.8 0.15 85)",
  bad: "oklch(0.65 0.2 25)",
}

export function StrategyPitch({
  slots,
  assignments,
  plan,
  shot,
  onSwap,
  onMove,
}: {
  slots: Slot[]
  assignments: Record<string, CareerPlayer | undefined>
  plan?: TacticalPlan | null
  shot?: ShotMarker | null
  onSwap: (a: string, b: string) => void
  onMove: (id: string, x: number, y: number) => void
}) {
  const boardRef = useRef<HTMLDivElement>(null)
  const [dragId, setDragId] = useState<string | null>(null)
  const [dragPos, setDragPos] = useState<{ x: number; y: number } | null>(null)
  const [overId, setOverId] = useState<string | null>(null)
  const movedRef = useRef(false)

  const focusBand = plan ? FOCUS_BAND[plan.attackFocus] : null
  const pressY = plan ? PRESS_LINE_Y[plan.press] : null

  function pointFromEvent(e: React.PointerEvent) {
    const rect = boardRef.current?.getBoundingClientRect()
    if (!rect) return null
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    return { x: Math.max(4, Math.min(96, x)), y: Math.max(4, Math.min(96, y)) }
  }

  function nearestSlot(x: number, y: number, excludeId: string) {
    let best: { id: string; d: number } | null = null
    for (const s of slots) {
      if (s.id === excludeId || !assignments[s.id]) continue
      const px = dragId === s.id ? x : s.x
      const py = dragId === s.id ? y : s.y
      const d = Math.hypot(px - x, py - y)
      if (!best || d < best.d) best = { id: s.id, d }
    }
    return best && best.d < 9 ? best.id : null
  }

  function onPointerDown(e: React.PointerEvent, id: string) {
    if (!assignments[id]) return
    e.preventDefault()
    ;(e.target as HTMLElement).setPointerCapture?.(e.pointerId)
    setDragId(id)
    movedRef.current = false
    const p = pointFromEvent(e)
    if (p) setDragPos(p)
  }

  function onPointerMove(e: React.PointerEvent) {
    if (!dragId) return
    const p = pointFromEvent(e)
    if (!p) return
    movedRef.current = true
    setDragPos(p)
    setOverId(nearestSlot(p.x, p.y, dragId))
  }

  function onPointerUp() {
    if (!dragId || !dragPos) {
      setDragId(null)
      setDragPos(null)
      setOverId(null)
      return
    }
    if (overId && overId !== dragId) {
      onSwap(dragId, overId)
    } else if (movedRef.current) {
      onMove(dragId, dragPos.x, dragPos.y)
    }
    setDragId(null)
    setDragPos(null)
    setOverId(null)
  }

  return (
    <div
      ref={boardRef}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      className="relative aspect-[3/4] w-full max-w-lg md:max-w-xl mx-auto touch-none select-none overflow-hidden rounded-xl border border-border shadow-inner"
      style={{
        background:
          "repeating-linear-gradient(0deg, oklch(0.42 0.09 150) 0 12.5%, oklch(0.39 0.09 150) 12.5% 25%)",
      }}
    >
      {/* pitch markings */}
      <div className="pointer-events-none absolute inset-3 rounded-md border-2 border-white/25" />
      <div className="pointer-events-none absolute left-3 right-3 top-1/2 h-px -translate-y-1/2 bg-white/25" />
      <div className="pointer-events-none absolute left-1/2 top-1/2 size-20 sm:size-24 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white/25" />
      <div className="pointer-events-none absolute left-1/2 top-3 h-14 sm:h-16 w-32 sm:w-40 -translate-x-1/2 border-2 border-t-0 border-white/25" />
      <div className="pointer-events-none absolute bottom-3 left-1/2 h-14 sm:h-16 w-32 sm:w-40 -translate-x-1/2 border-2 border-b-0 border-white/25" />

      {/* Tactical overlay: attacking channel */}
      {focusBand && (
        <div
          className="pointer-events-none absolute bottom-3 top-3 rounded-md border border-[var(--color-accent)]/40 bg-[var(--color-accent)]/12"
          style={{ left: `${focusBand.x}%`, width: `${focusBand.width}%` }}
        >
          <span className="absolute left-1/2 top-2 -translate-x-1/2 whitespace-nowrap rounded bg-[var(--color-accent)]/85 px-1.5 py-0.5 font-mono text-[9px] font-semibold text-black">
            {plan ? FOCUS_LABEL[plan.attackFocus] : ""}
          </span>
        </div>
      )}

      {/* Tactical overlay: pressing line */}
      {pressY != null && (
        <div
          className="pointer-events-none absolute left-3 right-3 flex items-center"
          style={{ top: `${pressY}%` }}
        >
          <div className="h-0 flex-1 border-t-2 border-dashed border-primary/70" />
          <span className="ml-1 rounded bg-primary/85 px-1.5 py-0.5 font-mono text-[9px] font-semibold text-primary-foreground">
            {plan ? PRESS_LABEL[plan.press] : ""}
          </span>
        </div>
      )}

      {/* Bayesian shot marker */}
      {shot && (
        <div
          className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2"
          style={{ left: `${shot.x}%`, top: `${shot.y}%` }}
        >
          <span
            className="grid size-5 animate-pulse place-items-center rounded-full shadow-lg ring-2 ring-white/80"
            style={{ backgroundColor: SHOT_COLOR[shot.tone] }}
          >
            <span className="size-1.5 rounded-full bg-black/70" />
          </span>
          <span
            className="absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded px-1.5 py-0.5 font-mono text-[9px] font-semibold text-black"
            style={{ backgroundColor: SHOT_COLOR[shot.tone] }}
          >
            {shot.label}
          </span>
        </div>
      )}

      {slots.map((slot) => {
        const player = assignments[slot.id]
        const isDragging = dragId === slot.id
        const isOver = overId === slot.id && dragId !== slot.id
        const pos = isDragging && dragPos ? dragPos : { x: slot.x, y: slot.y }
        const real = player ? findRealPlayerByName(player.name, player.club, player.nationality) : undefined
        const isRetired = player ? isCareerPlayerRetired(player) : false

        return (
          <div
            key={slot.id}
            onPointerDown={(e) => onPointerDown(e, slot.id)}
            className={`absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-0.5 sm:gap-1 ${
              player ? "cursor-grab active:cursor-grabbing" : ""
            } ${isDragging ? "z-20" : "z-10"}`}
            style={{
              left: `${pos.x}%`,
              top: `${pos.y}%`,
              transition: isDragging ? "none" : "left 0.18s, top 0.18s",
            }}
          >
            {isRetired && (
              <span className="rounded bg-destructive px-1.5 py-0.5 text-center font-mono text-[7px] sm:text-[8px] font-bold uppercase leading-tight text-destructive-foreground shadow animate-pulse">
                Retired · Replace
              </span>
            )}
            {real && real.image ? (
              <span
                className={`grid size-8 sm:size-9 md:size-11 place-items-center overflow-hidden rounded-full shadow-md transition-transform bg-secondary ${
                  isRetired
                    ? "ring-2 ring-destructive animate-pulse"
                    : isOver
                    ? "scale-115 ring-2 ring-primary"
                    : isDragging
                    ? "scale-110 ring-2 ring-[var(--color-accent)]"
                    : "ring-1.5 sm:ring-2 ring-white/70"
                }`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={real.image}
                  alt={player!.name}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  style={{ objectPosition: "50% 14%" }}
                  className="size-full object-cover pointer-events-none select-none"
                />
              </span>
            ) : (
              <span
                className={`grid size-8 sm:size-9 md:size-11 place-items-center rounded-full font-mono text-[9px] sm:text-[10px] md:text-[11px] font-bold text-black shadow-md transition-transform ${
                  isRetired
                    ? "ring-2 ring-destructive animate-pulse"
                    : isOver
                    ? "scale-115 ring-2 ring-primary"
                    : isDragging
                    ? "scale-110 ring-2 ring-[var(--color-accent)]"
                    : "ring-1.5 sm:ring-2 ring-white/50"
                }`}
                style={{ backgroundColor: isRetired ? "#ef4444" : player ? teamColor(player.team) : "oklch(0.7 0 0)" }}
              >
                {player ? (isRetired ? "!" : player.team) : slot.label}
              </span>
            )}
            <span className="rounded bg-black/60 px-1 py-0.5 text-center font-mono text-[8px] sm:text-[9px] uppercase leading-tight tracking-wider text-white/80">
              {slot.label}
            </span>
            <span className="max-w-[48px] sm:max-w-[64px] md:max-w-[76px] truncate text-center text-[9px] sm:text-[10px] font-medium text-white drop-shadow">
              {player ? player.name : "—"}
            </span>
            {player && (
              <span className={`rounded px-1 font-mono text-[8px] sm:text-[9px] font-semibold leading-tight ${
                isRetired ? "bg-destructive text-destructive-foreground" : "bg-primary/90 text-primary-foreground"
              }`}>
                {player.rating}
              </span>
            )}
          </div>
        )
      })}
    </div>
  )
}
