"use client"

import { createContext, useContext, useState } from "react"
import { Trophy } from "lucide-react"
import { DEFAULT_SEASON, SEASON_LABELS, SEASONS, type Season } from "@/lib/data"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const SeasonContext = createContext<{
  season: Season
  setSeason: (s: Season) => void
} | null>(null)

export function SeasonProvider({ children }: { children: React.ReactNode }) {
  const [season, setSeason] = useState<Season>(DEFAULT_SEASON)
  return <SeasonContext.Provider value={{ season, setSeason }}>{children}</SeasonContext.Provider>
}

export function useSeason() {
  const ctx = useContext(SeasonContext)
  if (!ctx) throw new Error("useSeason must be used within SeasonProvider")
  return ctx
}

export function SeasonSwitcher({ className }: { className?: string }) {
  const { season, setSeason } = useSeason()
  return (
    <Select value={season} onValueChange={(v) => setSeason(v as Season)}>
      <SelectTrigger className={className} aria-label="Select league">
        <Trophy className="size-4 text-primary" />
        <SelectValue>{SEASON_LABELS[season]}</SelectValue>
      </SelectTrigger>
      <SelectContent>
        {SEASONS.map((s) => (
          <SelectItem key={s} value={s}>
            {SEASON_LABELS[s]}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
