// Real player data sourced from github.com/salimt/football-datasets (Transfermarkt datalake).
// Aggregated via a one-off pipeline joining player_profiles + player_latest_market_value +
// career player_performances totals, then trimmed to the most notable players
// (top by latest market value, career goals, and career appearances).
// This powers the Player Explorer only; the rest of the app keeps its own data source.
import raw from "./players/players.json"

export type PositionGroup = "Goalkeeper" | "Defender" | "Midfield" | "Attack" | "N/A"

export interface RealPlayer {
  id: number
  name: string
  slug: string
  image: string
  position: PositionGroup
  detailedPosition: string
  foot: string
  dob: string
  age: number | null
  nationality: string
  nationalities: string[]
  birthPlace: string
  birthCountry: string
  heightCm: number
  club: string
  clubId: number
  retired: boolean
  retirementYear?: number | null
  careerStatus?: "active" | "retired" | "uncertain"
  statusSource?: string
  verificationDate?: string
  statusFlag?: string | null
  dod: string
  marketValueEur: number
  marketValueDate: string
  apps: number
  goals: number
  assists: number
  yellowCards: number
  redCards: number
  firstYear: number | null
  lastYear: number | null
  competitions: string[]
}

export const PLAYERS = raw as unknown as RealPlayer[]

export const POSITION_GROUPS: PositionGroup[] = ["Goalkeeper", "Defender", "Midfield", "Attack"]

export const POSITION_LABELS: Record<PositionGroup, string> = {
  Goalkeeper: "Goalkeepers",
  Defender: "Defenders",
  Midfield: "Midfielders",
  Attack: "Attackers",
  "N/A": "Unclassified",
}

// Stable palette for a position group (used for the badge chip).
export const POSITION_COLORS: Record<PositionGroup, string> = {
  Goalkeeper: "#f59e0b",
  Defender: "#38bdf8",
  Midfield: "#34d399",
  Attack: "#f472b6",
  "N/A": "#8b95a5",
}

let CLUBS_CACHE: string[] | null = null
export function getClubs(): string[] {
  if (CLUBS_CACHE) return CLUBS_CACHE
  const set = new Set<string>()
  for (const p of PLAYERS) {
    if (
      p.club &&
      !p.retired &&
      p.careerStatus === "active" &&
      p.club !== "Without Club" &&
      p.club !== "Retired" &&
      p.club !== "Deceased" &&
      p.club !== "Career break" &&
      p.club !== "---" &&
      p.club.trim().length > 1
    ) {
      set.add(p.club)
    }
  }
  CLUBS_CACHE = [...set].sort((a, b) => a.localeCompare(b))
  return CLUBS_CACHE
}

let NATIONS_CACHE: string[] | null = null
export function getNations(): string[] {
  if (NATIONS_CACHE) return NATIONS_CACHE
  const set = new Set<string>()
  for (const p of PLAYERS) if (p.nationality) set.add(p.nationality)
  NATIONS_CACHE = [...set].sort((a, b) => a.localeCompare(b))
  return NATIONS_CACHE
}

const BY_ID = new Map<number, RealPlayer>(PLAYERS.map((p) => [p.id, p]))
export function getPlayerById(id: number): RealPlayer | undefined {
  return BY_ID.get(id)
}

// Compact euro formatter (preserved for legacy utilities).
export function formatEuro(v: number): string {
  if (!v || v <= 0) return "—"
  if (v >= 1_000_000) return `€${(v / 1_000_000).toFixed(v >= 10_000_000 ? 0 : 1)}M`
  if (v >= 1_000) return `€${Math.round(v / 1_000)}K`
  return `€${Math.round(v)}`
}

function normalizeName(s: string): string {
  return (s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
}

// Index of verified retired players for O(1) retirement checking in Strategy Builder
let RETIRED_INDEX: {
  byName: Map<string, RealPlayer>
  tokenList: {
    player: RealPlayer
    nameTokens: string[]
    nat: string
    club: string
  }[]
} | null = null

function getRetiredIndex() {
  if (RETIRED_INDEX) return RETIRED_INDEX
  const byName = new Map<string, RealPlayer>()
  const tokenList: {
    player: RealPlayer
    nameTokens: string[]
    nat: string
    club: string
  }[] = []

  for (const p of PLAYERS) {
    if (p.retired || p.careerStatus === "retired") {
      const norm = normalizeName(p.name)
      byName.set(norm, p)
      if (p.slug) byName.set(normalizeName(p.slug), p)
      tokenList.push({
        player: p,
        nameTokens: norm.split(" "),
        nat: normalizeName(p.nationality),
        club: normalizeName(p.club),
      })
    }
  }

  RETIRED_INDEX = { byName, tokenList }
  return RETIRED_INDEX
}

const CAREER_RETIRED_CACHE = new Map<string, boolean>()

/**
 * Check whether a squad or strategy player is verified retired as of 15 October 2026.
 * Uses verified career status and never infers retirement from age or stats cutoff.
 */
export function isCareerPlayerRetired(p: {
  name: string
  longName?: string
  nationality?: string
  club?: string
}): boolean {
  if (!p || !p.name) return false
  const cacheKey = `${p.name}|${p.longName || ""}|${p.nationality || ""}|${p.club || ""}`
  if (CAREER_RETIRED_CACHE.has(cacheKey)) {
    return CAREER_RETIRED_CACHE.get(cacheKey)!
  }

  const { byName, tokenList } = getRetiredIndex()
  const normName = normalizeName(p.name)
  const normLong = normalizeName(p.longName || "")
  const normNat = normalizeName(p.nationality || "")

  // 1. Direct name match against verified retired players
  if (byName.has(normName)) {
    const r = byName.get(normName)!
    if (!normNat || !r.nationality || normalizeName(r.nationality).includes(normNat) || normNat.includes(normalizeName(r.nationality))) {
      CAREER_RETIRED_CACHE.set(cacheKey, true)
      return true
    }
  }
  if (normLong && byName.has(normLong)) {
    const r = byName.get(normLong)!
    if (!normNat || !r.nationality || normalizeName(r.nationality).includes(normNat) || normNat.includes(normalizeName(r.nationality))) {
      CAREER_RETIRED_CACHE.set(cacheKey, true)
      return true
    }
  }

  // 2. Token match for abbreviated names (e.g. "T. Kroos", "R. van Persie")
  const tokens = normName.split(" ")
  const isAbbrev = tokens.length > 1 && tokens[0].length === 1
  const surname = tokens[tokens.length - 1]

  for (const r of tokenList) {
    if (normNat && r.nat && !r.nat.includes(normNat) && !normNat.includes(r.nat)) {
      continue
    }

    const rTokens = r.nameTokens
    const rSurname = rTokens[rTokens.length - 1]

    if (isAbbrev) {
      const initial = tokens[0]
      const rInitial = rTokens[0][0]
      if (initial === rInitial && surname === rSurname) {
        CAREER_RETIRED_CACHE.set(cacheKey, true)
        return true
      }
    } else {
      if (rTokens.length === 1 && tokens.length === 1 && rTokens[0] === tokens[0]) {
        CAREER_RETIRED_CACHE.set(cacheKey, true)
        return true
      }
      if (rTokens.length > 1 && tokens.length > 1 && rSurname === surname) {
        let matching = 0
        for (const t of tokens) {
          if (rTokens.includes(t)) matching++
        }
        if (matching >= 2) {
          CAREER_RETIRED_CACHE.set(cacheKey, true)
          return true
        }
      }
    }
  }

  CAREER_RETIRED_CACHE.set(cacheKey, false)
  return false
}

// Initials for the avatar fallback when no portrait is available.
export function initials(name: string): string {
  const parts = name.split(" ").filter(Boolean)
  if (parts.length === 0) return "?"
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

/**
 * Format player career span:
 * - Active careers: "[start year]–Present"
 * - Retired careers: "[start year]–[verified retirement year]"
 * Never confuses statistics coverage limit (e.g. 2025) with career status.
 */
export function careerSpan(p: RealPlayer): string {
  const start = p.firstYear
  if (p.retired) {
    const end = p.retirementYear || p.lastYear
    if (start && end) {
      return start === end ? `${start}` : `${start}–${end}`
    }
    return end ? `${end}` : (start ? `${start}` : "—")
  }
  // Active career or unattached
  if (start) {
    return `${start}–Present`
  }
  return "Present"
}

function cleanTokens(s: string): string[] {
  return (s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 1)
}

// Memory cache for player name matching to keep UI rendering fast
const MATCH_CACHE = new Map<string, RealPlayer | null>()

/**
 * Deterministically match a player to a verified RealPlayer profile.
 * Only returns a match if multiple tokens align with high confidence.
 */
export function findRealPlayerByName(name: string, club?: string, nationality?: string): RealPlayer | undefined {
  if (!name) return undefined
  const cacheKey = `${name}|${club || ""}|${nationality || ""}`
  if (MATCH_CACHE.has(cacheKey)) {
    return MATCH_CACHE.get(cacheKey) || undefined
  }

  const fTokens = cleanTokens(name)
  const fNat = (nationality || "").toLowerCase()
  const fClub = (club || "").toLowerCase()

  let best: RealPlayer | null = null
  let bestScore = 0

  for (const r of PLAYERS) {
    const rTokens = cleanTokens(r.name)
    let matchCount = 0
    for (const t of rTokens) {
      if (fTokens.includes(t)) matchCount++
    }

    if (matchCount >= 2 || (rTokens.length === 1 && matchCount === 1)) {
      let bonus = 0
      const rNat = (r.nationality || "").toLowerCase()
      if (rNat && fNat && (rNat.includes(fNat) || fNat.includes(rNat))) bonus += 3

      const rClub = (r.club || "").toLowerCase()
      if (rClub && fClub && (rClub.includes(fClub) || fClub.includes(rClub))) bonus += 2

      const score = matchCount * 2 + bonus
      if (score > bestScore) {
        bestScore = score
        best = r
      }
    }
  }

  const result = bestScore >= 4 ? best : null
  MATCH_CACHE.set(cacheKey, result)
  return result || undefined
}

