import {
  getSeason,
  SEASON_LABELS,
  type Player,
  type Season,
  type Team,
} from "./data"
import { isCareerPlayerRetired } from "./players"

export type StyleType = "Possession" | "Counterattack" | "High Pressing" | "Defensive Organisation"

export interface StyleScore {
  type: StyleType
  label: string
  score: number
  description: string
  keyFactors: string[]
}

export interface SquadStrength {
  title: string
  detail: string
  teamValue: number
  benchmarkValue: number
}

export interface SquadLimitation {
  title: string
  detail: string
  teamValue: number
  benchmarkValue: number
}

export interface KeyPlayer {
  player: Player
  roleExplanation: string
  keyAttributes: { name: string; value: number }[]
}

export interface TacticalAnalysis {
  team: Team
  season: Season
  isNationalTeam: boolean
  datasetLabel: string
  datasetSeason: string
  historicalNotice: string
  totalSquadSize: number
  activeCount: number
  retiredCount: number
  hasSufficientData: boolean
  primaryStyle: StyleScore
  alternativeStyle: StyleScore | null
  allStyles: StyleScore[]
  strengths: SquadStrength[]
  limitations: SquadLimitation[]
  keyPlayers: KeyPlayer[]
  methodologyNotes: string[]
}

function mean(nums: number[]): number {
  if (!nums || nums.length === 0) return 0
  return Math.round(nums.reduce((a, b) => a + b, 0) / nums.length)
}

function computeLeagueBenchmarks(players: Player[]) {
  const outfield = players.filter((p) => p.pos !== "GKP")
  const mids = players.filter((p) => p.pos === "MID")
  const fwds = players.filter((p) => p.pos === "FWD")
  const defs = players.filter((p) => p.pos === "DEF")

  return {
    midPassing: mean(mids.map((p) => p.attacking?.shortPassing ?? p.passing)),
    midControl: mean(mids.map((p) => p.skill?.ballControl ?? p.dribbling)),
    fwdPace: mean(fwds.map((p) => p.pace)),
    fwdFinishing: mean(fwds.map((p) => p.attacking?.finishing ?? p.shooting)),
    defTackling: mean(defs.map((p) => p.defense?.standing ?? p.defending)),
    defPace: mean(defs.map((p) => p.pace)),
    defStrength: mean(defs.map((p) => p.power?.strength ?? p.physic)),
    outfieldStamina: mean(outfield.map((p) => p.power?.stamina ?? p.physic)),
    outfieldInterceptions: mean(outfield.map((p) => p.mentality?.interceptions ?? p.defending)),
  }
}

// Memory cache for league benchmarks
const BENCHMARK_CACHE = new Map<Season, ReturnType<typeof computeLeagueBenchmarks>>()

function getBenchmarks(season: Season) {
  if (!BENCHMARK_CACHE.has(season)) {
    const { players } = getSeason(season)
    BENCHMARK_CACHE.set(season, computeLeagueBenchmarks(players))
  }
  return BENCHMARK_CACHE.get(season)!
}

/**
 * Analyse a squad's available player attributes to suggest the most suitable tactical style.
 * Uses only real attributes existing in the dataset and accounts for player positions.
 */
export function analyzeSquadStyle(team: Team, season: Season): TacticalAnalysis {
  const { players } = getSeason(season)
  const squad = players.filter((p) => p.teamId === team.id)
  const isNationalTeam = season === "world-cup"
  const benchmarks = getBenchmarks(season)

  const outfield = squad.filter((p) => p.pos !== "GKP")
  const mids = squad.filter((p) => p.pos === "MID")
  const fwds = squad.filter((p) => p.pos === "FWD")
  const defs = squad.filter((p) => p.pos === "DEF")

  // Check data sufficiency
  const hasSufficientData = squad.length >= 11 && outfield.length >= 8

  // Career verification counts
  let activeCount = 0
  let retiredCount = 0
  for (const p of squad) {
    if (isCareerPlayerRetired(p)) {
      retiredCount++
    } else {
      activeCount++
    }
  }

  // 1. POSSESSION
  // Attributes: passing, ball control, dribbling, vision.
  // Position weighting: Midfielders and defenders handle build-up; goalkeepers excluded.
  const teamMidPassing = mean(mids.map((p) => p.attacking?.shortPassing ?? p.passing))
  const teamMidControl = mean(mids.map((p) => p.skill?.ballControl ?? p.dribbling))
  const teamOutfieldDribbling = mean(outfield.map((p) => p.dribbling))
  const teamVision = mean(mids.concat(fwds).map((p) => p.mentality?.vision ?? p.passing))
  const teamLongPassing = mean(mids.concat(defs).map((p) => p.skill?.longPassing ?? p.passing))

  const possessionScore = Math.min(
    99,
    Math.round(
      teamMidPassing * 0.3 +
        teamMidControl * 0.25 +
        teamOutfieldDribbling * 0.2 +
        teamVision * 0.15 +
        teamLongPassing * 0.1,
    ),
  )

  // 2. COUNTERATTACK
  // Attributes: pace, attacking movement (positioning & reactions), passing, finishing.
  // Position weighting: Forwards & attacking midfielders lead transition; deep passers initiate.
  const teamFwdPace = mean(fwds.map((p) => p.pace)) || mean(outfield.map((p) => p.pace))
  const teamFwdFinishing = mean(fwds.map((p) => p.attacking?.finishing ?? p.shooting)) || mean(outfield.map((p) => p.shooting))
  const teamPositioning = mean(fwds.concat(mids).map((p) => p.mentality?.positioning ?? p.overall))
  const teamTransitionPass = mean(defs.concat(mids).map((p) => p.skill?.longPassing ?? p.passing))
  const teamReactions = mean(fwds.concat(mids).map((p) => p.movement?.reactions ?? p.overall))

  const counterattackScore = Math.min(
    99,
    Math.round(
      teamFwdPace * 0.35 +
        teamPositioning * 0.2 +
        teamFwdFinishing * 0.2 +
        teamTransitionPass * 0.15 +
        teamReactions * 0.1,
    ),
  )

  // 3. HIGH PRESSING
  // Attributes: stamina, work rate, aggression, interceptions.
  // Position weighting: Outfield pressing unit across all three lines.
  const teamStamina = mean(outfield.map((p) => p.power?.stamina ?? p.physic))
  const teamAggression = mean(outfield.map((p) => p.mentality?.aggression ?? p.defending))
  const teamInterceptions = mean(mids.concat(defs).map((p) => p.mentality?.interceptions ?? p.defending))
  const teamOutfieldPace = mean(outfield.map((p) => p.pace))

  // Work rate evaluation: percentage of outfield players with High work rate
  const highWorkRateOutfield = outfield.filter((p) => (p.workRate || "").includes("High")).length
  const workRateScore = Math.min(100, Math.round((highWorkRateOutfield / (outfield.length || 1)) * 100))

  const highPressingScore = Math.min(
    99,
    Math.round(
      teamStamina * 0.35 +
        teamAggression * 0.25 +
        teamInterceptions * 0.2 +
        teamOutfieldPace * 0.1 +
        workRateScore * 0.1,
    ),
  )

  // 4. DEFENSIVE ORGANISATION
  // Attributes: defensive awareness (marking), tackling, interceptions, strength.
  // Position weighting: Backline defenders and holding midfielders.
  const teamMarking = mean(defs.concat(mids).map((p) => p.defense?.marking ?? p.defending))
  const teamTackling = mean(defs.concat(mids).map((p) => p.defense?.standing ?? p.defending))
  const teamDefInterceptions = mean(defs.concat(mids).map((p) => p.mentality?.interceptions ?? p.defending))
  const teamStrength = mean(defs.concat(mids).map((p) => p.power?.strength ?? p.physic))
  const teamPhysic = mean(defs.map((p) => p.physic))

  const defensiveOrgScore = Math.min(
    99,
    Math.round(
      teamMarking * 0.3 +
        teamTackling * 0.25 +
        teamDefInterceptions * 0.2 +
        teamStrength * 0.15 +
        teamPhysic * 0.1,
    ),
  )

  // Build style descriptions linked directly to squad ratings
  const styleDescriptions: Record<StyleType, { desc: string; factors: string[] }> = {
    Possession: {
      desc: `${team.name}'s squad features an average of ${teamMidPassing} short passing and ${teamMidControl} ball control across the midfield. With reliable distribution and close ball control, the group is well structured to retain possession and dictate game tempo.`,
      factors: [
        `Midfield short passing: ${teamMidPassing} (benchmark: ${benchmarks.midPassing})`,
        `Midfield ball control: ${teamMidControl} (benchmark: ${benchmarks.midControl})`,
        `Outfield dribbling: ${teamOutfieldDribbling}`,
      ],
    },
    Counterattack: {
      desc: `With front-line pace averaging ${teamFwdPace} and attacking finishing at ${teamFwdFinishing}, ${team.name} can strike rapidly on the break. Deep distribution (${teamTransitionPass} long passing) allows direct release into offensive space.`,
      factors: [
        `Forward pace: ${teamFwdPace} (benchmark: ${benchmarks.fwdPace})`,
        `Forward finishing: ${teamFwdFinishing} (benchmark: ${benchmarks.fwdFinishing})`,
        `Deep long passing: ${teamTransitionPass}`,
      ],
    },
    "High Pressing": {
      desc: `${team.name}'s outfield players average ${teamStamina} stamina and ${teamAggression} aggression, enabling sustained physical engagement. Quick closing speed (${teamOutfieldPace} pace) supports proactive pressure on opponents.`,
      factors: [
        `Outfield stamina: ${teamStamina} (benchmark: ${benchmarks.outfieldStamina})`,
        `Outfield aggression: ${teamAggression}`,
        `Interceptions: ${teamInterceptions} (benchmark: ${benchmarks.outfieldInterceptions})`,
      ],
    },
    "Defensive Organisation": {
      desc: `The backline and holding unit average ${teamMarking} marking awareness and ${teamTackling} tackling. Coupled with ${teamStrength} physical strength, the squad excels at maintaining disciplined compact shape and denying central penetration.`,
      factors: [
        `Defensive marking: ${teamMarking}`,
        `Standing tackle: ${teamTackling} (benchmark: ${benchmarks.defTackling})`,
        `Defender strength: ${teamStrength} (benchmark: ${benchmarks.defStrength})`,
      ],
    },
  }

  const allStyles: StyleScore[] = [
    {
      type: "Possession" as StyleType,
      label: "Possession Control",
      score: possessionScore,
      description: styleDescriptions.Possession.desc,
      keyFactors: styleDescriptions.Possession.factors,
    },
    {
      type: "Counterattack" as StyleType,
      label: "Rapid Counterattack",
      score: counterattackScore,
      description: styleDescriptions.Counterattack.desc,
      keyFactors: styleDescriptions.Counterattack.factors,
    },
    {
      type: "High Pressing" as StyleType,
      label: "High Pressing",
      score: highPressingScore,
      description: styleDescriptions["High Pressing"].desc,
      keyFactors: styleDescriptions["High Pressing"].factors,
    },
    {
      type: "Defensive Organisation" as StyleType,
      label: "Defensive Organisation",
      score: defensiveOrgScore,
      description: styleDescriptions["Defensive Organisation"].desc,
      keyFactors: styleDescriptions["Defensive Organisation"].factors,
    },
  ].sort((a, b) => b.score - a.score)

  const primaryStyle = allStyles[0]
  // Alternative style supported if secondary style is robust
  const runnerUp = allStyles[1]
  const alternativeStyle = runnerUp && runnerUp.score >= 60 ? runnerUp : null

  // 3. STRENGTHS AND LIMITATIONS
  // Derived via documented comparison against league benchmarks
  const candidateStrengths: SquadStrength[] = []
  const candidateLimitations: SquadLimitation[] = []

  // Check 1: Midfield Passing
  const passDiff = teamMidPassing - benchmarks.midPassing
  if (passDiff >= 2) {
    candidateStrengths.push({
      title: "Midfield Distribution & Security",
      detail: `Midfield short passing averages ${teamMidPassing}, ${passDiff > 0 ? `+${passDiff}` : passDiff} relative to the ${SEASON_LABELS[season]} average (${benchmarks.midPassing}).`,
      teamValue: teamMidPassing,
      benchmarkValue: benchmarks.midPassing,
    })
  } else if (passDiff <= -2) {
    candidateLimitations.push({
      title: "Midfield Build-up Press Resistance",
      detail: `Midfield short passing averages ${teamMidPassing} (${passDiff} points compared to the ${SEASON_LABELS[season]} average of ${benchmarks.midPassing}), indicating relative vulnerability when building through heavy pressure.`,
      teamValue: teamMidPassing,
      benchmarkValue: benchmarks.midPassing,
    })
  }

  // Check 2: Forward Pace
  const paceDiff = teamFwdPace - benchmarks.fwdPace
  if (paceDiff >= 2) {
    candidateStrengths.push({
      title: "Front-Line Transition Pace",
      detail: `Attackers average ${teamFwdPace} pace, ${paceDiff > 0 ? `+${paceDiff}` : paceDiff} points above the league benchmark (${benchmarks.fwdPace}), offering direct breakaway threat.`,
      teamValue: teamFwdPace,
      benchmarkValue: benchmarks.fwdPace,
    })
  } else if (paceDiff <= -2) {
    candidateLimitations.push({
      title: "Breakaway Foot Speed",
      detail: `Attackers average ${teamFwdPace} pace (${paceDiff} relative to the league average of ${benchmarks.fwdPace}), making quick foot-race counterattacks less effective.`,
      teamValue: teamFwdPace,
      benchmarkValue: benchmarks.fwdPace,
    })
  }

  // Check 3: Defensive Tackling & Backline
  const tackleDiff = teamTackling - benchmarks.defTackling
  if (tackleDiff >= 2) {
    candidateStrengths.push({
      title: "Defensive Tackling & 1v1 Ground Duels",
      detail: `Defensive unit averages ${teamTackling} standing tackle, ${tackleDiff > 0 ? `+${tackleDiff}` : tackleDiff} points above the league standard (${benchmarks.defTackling}).`,
      teamValue: teamTackling,
      benchmarkValue: benchmarks.defTackling,
    })
  } else if (tackleDiff <= -2) {
    candidateLimitations.push({
      title: "1v1 Ground Challenge Success",
      detail: `Defenders average ${teamTackling} standing tackle (${tackleDiff} compared to the league benchmark of ${benchmarks.defTackling}), pointing to potential exposure in isolated 1v1 matchups.`,
      teamValue: teamTackling,
      benchmarkValue: benchmarks.defTackling,
    })
  }

  // Check 4: Stamina
  const staminaDiff = teamStamina - benchmarks.outfieldStamina
  if (staminaDiff >= 2) {
    candidateStrengths.push({
      title: "High-Energy Work Capacity",
      detail: `Outfield players average ${teamStamina} stamina (${staminaDiff > 0 ? `+${staminaDiff}` : staminaDiff} relative to the league average of ${benchmarks.outfieldStamina}), sustaining tactical tempo over 90 minutes.`,
      teamValue: teamStamina,
      benchmarkValue: benchmarks.outfieldStamina,
    })
  } else if (staminaDiff <= -2) {
    candidateLimitations.push({
      title: "Late-Match Physical Endurance",
      detail: `Outfield stamina averages ${teamStamina} (${staminaDiff} vs league benchmark of ${benchmarks.outfieldStamina}), suggesting physical fatigue may impact late-match pressing intensity.`,
      teamValue: teamStamina,
      benchmarkValue: benchmarks.outfieldStamina,
    })
  }

  // Check 5: Defensive Pace (Recovery)
  const defPaceDiff = mean(defs.map((p) => p.pace)) - benchmarks.defPace
  if (defPaceDiff >= 2) {
    candidateStrengths.push({
      title: "Defensive Recovery Speed",
      detail: `Backline pace averages ${mean(defs.map((p) => p.pace))}, ${defPaceDiff > 0 ? `+${defPaceDiff}` : defPaceDiff} above the league standard (${benchmarks.defPace}), allowing confident deployment of a higher defensive block.`,
      teamValue: mean(defs.map((p) => p.pace)),
      benchmarkValue: benchmarks.defPace,
    })
  } else if (defPaceDiff <= -2) {
    candidateLimitations.push({
      title: "Defensive Recovery Speed",
      detail: `Backline pace averages ${mean(defs.map((p) => p.pace))} (${defPaceDiff} points below the league average of ${benchmarks.defPace}), suggesting caution when holding an aggressive high defensive line.`,
      teamValue: mean(defs.map((p) => p.pace)),
      benchmarkValue: benchmarks.defPace,
    })
  }

  // Check 6: Forward Finishing
  const finishingDiff = teamFwdFinishing - benchmarks.fwdFinishing
  if (finishingDiff >= 2) {
    candidateStrengths.push({
      title: "Box Finishing Efficiency",
      detail: `Forward finishing averages ${teamFwdFinishing} (${finishingDiff > 0 ? `+${finishingDiff}` : finishingDiff} above the league benchmark of ${benchmarks.fwdFinishing}), indicating strong conversion inside the penalty area.`,
      teamValue: teamFwdFinishing,
      benchmarkValue: benchmarks.fwdFinishing,
    })
  } else if (finishingDiff <= -2) {
    candidateLimitations.push({
      title: "Penalty Box Conversion",
      detail: `Forward finishing averages ${teamFwdFinishing} (${finishingDiff} compared to the league benchmark of ${benchmarks.fwdFinishing}), meaning goals may depend on sustained volume rather than isolated clinical finishes.`,
      teamValue: teamFwdFinishing,
      benchmarkValue: benchmarks.fwdFinishing,
    })
  }

  // If squad has fewer than 11 players or missing data, display "Insufficient data"
  const strengths = hasSufficientData ? candidateStrengths.slice(0, 3) : []
  const limitations = hasSufficientData ? candidateLimitations.slice(0, 3) : []

  // 4. KEY PLAYERS SUPPORTING THE SUGGESTED STYLE
  const scoredPlayers = outfield.map((p) => {
    let score = 0
    let keyAttributes: { name: string; value: number }[] = []
    let roleExplanation = ""

    if (primaryStyle.type === "Possession") {
      const sp = p.attacking?.shortPassing ?? p.passing
      const bc = p.skill?.ballControl ?? p.dribbling
      const vi = p.mentality?.vision ?? p.passing
      score = sp * 0.4 + bc * 0.35 + vi * 0.25
      keyAttributes = [
        { name: "Short Passing", value: sp },
        { name: "Ball Control", value: bc },
        { name: "Vision", value: vi },
      ]
      roleExplanation = `Anchors possession with ${bc} ball control and ${sp} short distribution under pressure.`
    } else if (primaryStyle.type === "Counterattack") {
      const pc = p.pace
      const fn = p.attacking?.finishing ?? p.shooting
      const pos = p.mentality?.positioning ?? p.overall
      score = pc * 0.4 + fn * 0.35 + pos * 0.25
      keyAttributes = [
        { name: "Pace", value: pc },
        { name: "Finishing", value: fn },
        { name: "Positioning", value: pos },
      ]
      roleExplanation = `Drives rapid transitions with ${pc} pace and ${fn} finishing inside the box.`
    } else if (primaryStyle.type === "High Pressing") {
      const st = p.power?.stamina ?? p.physic
      const ag = p.mentality?.aggression ?? p.defending
      const it = p.mentality?.interceptions ?? p.defending
      score = st * 0.4 + ag * 0.3 + it * 0.3
      keyAttributes = [
        { name: "Stamina", value: st },
        { name: "Aggression", value: ag },
        { name: "Interceptions", value: it },
      ]
      roleExplanation = `Triggers team pressing with ${st} stamina and relentless ${ag} aggression.`
    } else {
      // Defensive Organisation
      const tk = p.defense?.standing ?? p.defending
      const mk = p.defense?.marking ?? p.defending
      const str = p.power?.strength ?? p.physic
      score = tk * 0.35 + mk * 0.35 + str * 0.3
      keyAttributes = [
        { name: "Tackling", value: tk },
        { name: "Marking", value: mk },
        { name: "Strength", value: str },
      ]
      roleExplanation = `Maintains defensive stability through ${mk} marking awareness and ${tk} standing tackles.`
    }

    return { player: p, score, keyAttributes, roleExplanation }
  })

  scoredPlayers.sort((a, b) => b.score - a.score)
  const keyPlayers: KeyPlayer[] = scoredPlayers.slice(0, 3).map((item) => ({
    player: item.player,
    roleExplanation: item.roleExplanation,
    keyAttributes: item.keyAttributes,
  }))

  // 5. METHODOLOGY NOTES
  const methodologyNotes = [
    "Positional weighting: Goalkeeper attributes are excluded from outfield metrics (passing, dribbling, pace, finishing) so goalkeeper baselines do not distort attacking evaluations.",
    "Possession scoring combines Midfield Short Passing (30%), Ball Control (25%), Outfield Dribbling (20%), Vision (15%), and Long Passing (10%).",
    "Counterattack scoring combines Forward Pace & Acceleration (35%), Attacking Positioning (20%), Finishing (20%), Deep Transition Passing (15%), and Reactions (10%).",
    "High Pressing scoring combines Outfield Stamina (35%), Aggression (25%), Interceptions (20%), Closing Pace (10%), and Work Rate ratio (10%).",
    "Defensive Organisation scoring combines Backline Marking (30%), Standing Tackles (25%), Interceptions (20%), Physical Strength (15%), and Defender Physic (10%).",
    "Strengths and relative limitations are evaluated exclusively against the mathematical benchmark of all teams in the selected league.",
  ]

  return {
    team,
    season,
    isNationalTeam,
    datasetLabel: isNationalTeam ? "FIFA World Cup Squad Ratings Dataset" : "Historical FIFA Squad Ratings Archive",
    datasetSeason: SEASON_LABELS[season],
    historicalNotice: isNationalTeam
      ? "Tournament squad ratings from the FIFA World Cup dataset. Player statistics represent tournament squad profiles."
      : "Historical squad ratings from the FIFA dataset archive. Not reflective of active 2026 real-world transfer rosters or live match tactics.",
    totalSquadSize: squad.length,
    activeCount,
    retiredCount,
    hasSufficientData,
    primaryStyle,
    alternativeStyle,
    allStyles,
    strengths,
    limitations,
    keyPlayers,
    methodologyNotes,
  }
}
