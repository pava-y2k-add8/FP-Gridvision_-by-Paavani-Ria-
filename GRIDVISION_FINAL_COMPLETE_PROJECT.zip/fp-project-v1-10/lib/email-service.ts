export interface SendVerificationEmailParams {
  to: string
  name: string
  verificationUrl: string
}

export interface SendVerificationEmailResult {
  success: boolean
  providerAccepted: boolean
  isConfigured: boolean
  messageId?: string
  error?: string
  devLink?: string
}

export async function sendVerificationEmail({
  to,
  name,
  verificationUrl,
}: SendVerificationEmailParams): Promise<SendVerificationEmailResult> {
  const isDev = process.env.NODE_ENV !== "production"
  const resendApiKey = process.env.RESEND_API_KEY

  console.log("\n=======================================================")
  console.log("📧 [EMAIL SERVICE] Verification Email Request")
  console.log(`To: ${name} <${to}>`)
  console.log(`Verification URL: ${verificationUrl}`)
  console.log("Expires in: 1 hour")
  console.log("=======================================================\n")

  if (!resendApiKey || resendApiKey.trim() === "") {
    console.warn("[email-service] BLOCKED: No RESEND_API_KEY found in environment variables. Email was not dispatched.")
    return {
      success: false,
      providerAccepted: false,
      isConfigured: false,
      error: "Email delivery is not configured. Missing RESEND_API_KEY environment variable on the server.",
      devLink: isDev ? verificationUrl : undefined,
    }
  }

  try {
    const fromAddress = process.env.EMAIL_FROM || "GridVision <onboarding@resend.dev>"
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${resendApiKey.trim()}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: fromAddress,
        to: [to],
        subject: "Verify your GridVision email address",
        html: `
          <div style="font-family: sans-serif; max-width: 560px; margin: 0 auto; padding: 24px; background: #0f172a; color: #f8fafc; border-radius: 12px;">
            <h2 style="color: #fbbf24; margin-top: 0;">Welcome to GridVision, ${name}!</h2>
            <p style="color: #cbd5e1; font-size: 15px; line-height: 1.6;">
              Thanks for creating an account. Please click the button below to verify your email address and unlock all platform features.
            </p>
            <div style="margin: 28px 0;">
              <a href="${verificationUrl}" style="background: #fbbf24; color: #000; padding: 12px 24px; font-weight: bold; text-decoration: none; border-radius: 8px; display: inline-block;">
                Verify Email Address
              </a>
            </div>
            <p style="color: #94a3b8; font-size: 13px;">
              Or copy and paste this link in your browser:<br/>
              <a href="${verificationUrl}" style="color: #38bdf8;">${verificationUrl}</a>
            </p>
            <hr style="border: 0; border-top: 1px solid #334155; margin: 24px 0;" />
            <p style="color: #64748b; font-size: 12px; margin-bottom: 0;">
              This link will expire in 1 hour. If you didn't create a GridVision account, you can safely ignore this email.
            </p>
          </div>
        `,
      }),
    })

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({ message: res.statusText }))
      const errorMessage = errorData?.message || `HTTP ${res.status}: ${res.statusText}`
      console.error(`[email-service] Email provider rejected request (HTTP ${res.status}):`, errorMessage)

      let friendlyError = `Email provider rejected sending request: ${errorMessage}`
      if (res.status === 403 && fromAddress.includes("onboarding@resend.dev")) {
        friendlyError = `Email provider rejected sending (HTTP 403): With the default Resend onboarding domain (${fromAddress}), you can only send verification emails to the email address registered with your Resend account. To send to any recipient, verify a custom domain in your Resend dashboard.`
      }

      return {
        success: false,
        providerAccepted: false,
        isConfigured: true,
        error: friendlyError,
      }
    }

    const data = await res.json().catch(() => ({}))
    console.log(`[email-service] Email provider accepted sending request. Message ID: ${data?.id}`)
    return {
      success: true,
      providerAccepted: true,
      isConfigured: true,
      messageId: data?.id,
    }
  } catch (err: any) {
    console.error("[email-service] Failed to contact email provider:", err)
    return {
      success: false,
      providerAccepted: false,
      isConfigured: true,
      error: `Failed to contact email service provider: ${err?.message || "Network error"}`,
    }
  }
}
