import fs from "fs"
import path from "path"
import { eq, and, or, desc, inArray } from "drizzle-orm"
import { db } from "./index"
import { fixtures, calendarEvents, eventShares, syncLogs } from "./schema"

const hasDbUrl = Boolean(process.env.DATABASE_URL && process.env.DATABASE_URL.trim() !== "")

export interface FixtureRecord {
  id: string
  competition: string // "world-cup" | "premier-league" | "la-liga" | "serie-a"
  season: string
  round: string
  homeTeam: string
  awayTeam: string
  homeTeamId?: number | null
  awayTeamId?: number | null
  homeScore?: number | null
  awayScore?: number | null
  status: "SCHEDULED" | "TIMED" | "LIVE" | "IN_PLAY" | "FINISHED" | "POSTPONED" | "CANCELLED"
  kickoffTime: string // ISO UTC string
  venue?: string | null
  source: string
  lastUpdated: string // ISO string
  dedupKey: string
}

export interface CalendarEventRecord {
  id: string
  userId: number
  title: string
  description?: string | null
  eventType: "match_note" | "scouting" | "watch_party" | "training" | "personal"
  startDate: string // ISO string
  endDate?: string | null
  allDay: boolean
  linkedFixtureId?: string | null
  competition?: string | null
  teamId?: number | null
  visibility: "private" | "shared"
  createdAt: string
  updatedAt: string
  // Virtual joined fields for UI
  ownerName?: string
  ownerEmail?: string
  shares?: EventShareRecord[]
  canEdit?: boolean
}

export interface EventShareRecord {
  id?: number
  eventId: string
  sharedWithUserId: number
  sharedWithEmail?: string
  sharedWithName?: string
  permission: "view" | "edit"
  createdAt?: string
}

export interface SyncLogRecord {
  id?: number
  competition: string
  status: "SUCCESS" | "FAILED" | "PARTIAL"
  fixturesCount: number
  message?: string | null
  timestamp: string
}

interface LocalCalendarStore {
  fixtures: FixtureRecord[]
  events: CalendarEventRecord[]
  shares: EventShareRecord[]
  syncLogs: SyncLogRecord[]
}

const STORE_PATH = path.join(process.cwd(), ".data", "calendar-store.json")

function getLocalStore(): LocalCalendarStore {
  try {
    if (!fs.existsSync(STORE_PATH)) {
      const dir = path.dirname(STORE_PATH)
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
      const initial: LocalCalendarStore = {
        fixtures: [],
        events: [],
        shares: [],
        syncLogs: [],
      }
      fs.writeFileSync(STORE_PATH, JSON.stringify(initial, null, 2), "utf-8")
      return initial
    }
    const data = fs.readFileSync(STORE_PATH, "utf-8")
    return JSON.parse(data) as LocalCalendarStore
  } catch (err) {
    console.error("Failed to read local calendar store:", err)
    return { fixtures: [], events: [], shares: [], syncLogs: [] }
  }
}

function saveLocalStore(store: LocalCalendarStore): void {
  try {
    const dir = path.dirname(STORE_PATH)
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), "utf-8")
  } catch (err) {
    console.error("Failed to save local calendar store:", err)
  }
}

// ---------------------------------------------------------------------------
// FIXTURES
// ---------------------------------------------------------------------------

export async function getAllFixtures(filter?: {
  competition?: string
  team?: string
  status?: string
}): Promise<FixtureRecord[]> {
  if (hasDbUrl) {
    try {
      const rows = await db.select().from(fixtures)
      let result: FixtureRecord[] = rows.map((r) => ({
        id: r.id,
        competition: r.competition,
        season: r.season,
        round: r.round,
        homeTeam: r.homeTeam,
        awayTeam: r.awayTeam,
        homeTeamId: r.homeTeamId,
        awayTeamId: r.awayTeamId,
        homeScore: r.homeScore,
        awayScore: r.awayScore,
        status: r.status as FixtureRecord["status"],
        kickoffTime: r.kickoffTime.toISOString(),
        venue: r.venue,
        source: r.source,
        lastUpdated: r.lastUpdated.toISOString(),
        dedupKey: r.dedupKey,
      }))

      if (filter?.competition && filter.competition !== "all") {
        result = result.filter((f) => f.competition === filter.competition)
      }
      if (filter?.team) {
        const t = filter.team.toLowerCase()
        result = result.filter(
          (f) =>
            f.homeTeam.toLowerCase().includes(t) ||
            f.awayTeam.toLowerCase().includes(t),
        )
      }
      if (filter?.status && filter.status !== "all") {
        result = result.filter((f) => f.status === filter.status)
      }
      return result.sort(
        (a, b) => new Date(a.kickoffTime).getTime() - new Date(b.kickoffTime).getTime(),
      )
    } catch (err) {
      console.warn("DB query for fixtures failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  let result = store.fixtures || []
  if (filter?.competition && filter.competition !== "all") {
    result = result.filter((f) => f.competition === filter.competition)
  }
  if (filter?.team) {
    const t = filter.team.toLowerCase()
    result = result.filter(
      (f) =>
        f.homeTeam.toLowerCase().includes(t) ||
        f.awayTeam.toLowerCase().includes(t),
    )
  }
  if (filter?.status && filter.status !== "all") {
    result = result.filter((f) => f.status === filter.status)
  }
  return result.sort(
    (a, b) => new Date(a.kickoffTime).getTime() - new Date(b.kickoffTime).getTime(),
  )
}

export async function upsertFixtures(
  newFixtures: Omit<FixtureRecord, "lastUpdated">[],
): Promise<{ added: number; updated: number }> {
  const now = new Date()
  let added = 0
  let updated = 0

  if (hasDbUrl) {
    try {
      for (const item of newFixtures) {
        const existing = await db
          .select()
          .from(fixtures)
          .where(eq(fixtures.dedupKey, item.dedupKey))

        if (existing.length > 0) {
          await db
            .update(fixtures)
            .set({
              competition: item.competition,
              season: item.season,
              round: item.round,
              homeTeam: item.homeTeam,
              awayTeam: item.awayTeam,
              homeTeamId: item.homeTeamId,
              awayTeamId: item.awayTeamId,
              homeScore: item.homeScore,
              awayScore: item.awayScore,
              status: item.status,
              kickoffTime: new Date(item.kickoffTime),
              venue: item.venue,
              source: item.source,
              lastUpdated: now,
            })
            .where(eq(fixtures.dedupKey, item.dedupKey))
          updated++
        } else {
          await db.insert(fixtures).values({
            id: item.id,
            competition: item.competition,
            season: item.season,
            round: item.round,
            homeTeam: item.homeTeam,
            awayTeam: item.awayTeam,
            homeTeamId: item.homeTeamId,
            awayTeamId: item.awayTeamId,
            homeScore: item.homeScore,
            awayScore: item.awayScore,
            status: item.status,
            kickoffTime: new Date(item.kickoffTime),
            venue: item.venue,
            source: item.source,
            lastUpdated: now,
            dedupKey: item.dedupKey,
          })
          added++
        }
      }
      return { added, updated }
    } catch (err) {
      console.warn("DB upsert fixtures failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  for (const item of newFixtures) {
    const idx = store.fixtures.findIndex((f) => f.dedupKey === item.dedupKey)
    const rec: FixtureRecord = {
      ...item,
      lastUpdated: now.toISOString(),
    }
    if (idx !== -1) {
      store.fixtures[idx] = rec
      updated++
    } else {
      store.fixtures.push(rec)
      added++
    }
  }
  saveLocalStore(store)
  return { added, updated }
}

// ---------------------------------------------------------------------------
// PERSONAL & SHARED CALENDAR EVENTS
// ---------------------------------------------------------------------------

export async function getUserEvents(
  userId: number | null,
): Promise<CalendarEventRecord[]> {
  if (!userId) return []

  if (hasDbUrl) {
    try {
      const owned = await db
        .select()
        .from(calendarEvents)
        .where(eq(calendarEvents.userId, userId))

      const sharedRows = await db
        .select()
        .from(eventShares)
        .where(eq(eventShares.sharedWithUserId, userId))

      const sharedEventIds = sharedRows.map((s) => s.eventId)
      let sharedEvents: (typeof calendarEvents.$inferSelect)[] = []
      if (sharedEventIds.length > 0) {
        sharedEvents = await db
          .select()
          .from(calendarEvents)
          .where(inArray(calendarEvents.id, sharedEventIds))
      }

      const allEvents = [...owned, ...sharedEvents]
      // deduplicate
      const uniqueMap = new Map<string, typeof calendarEvents.$inferSelect>()
      for (const ev of allEvents) {
        uniqueMap.set(ev.id, ev)
      }

      return Array.from(uniqueMap.values()).map((ev) => {
        const isOwner = ev.userId === userId
        const share = sharedRows.find((s) => s.eventId === ev.id)
        const canEdit = isOwner || share?.permission === "edit"
        return {
          id: ev.id,
          userId: ev.userId,
          title: ev.title,
          description: ev.description,
          eventType: ev.eventType as CalendarEventRecord["eventType"],
          startDate: ev.startDate.toISOString(),
          endDate: ev.endDate ? ev.endDate.toISOString() : null,
          allDay: ev.allDay,
          linkedFixtureId: ev.linkedFixtureId,
          competition: ev.competition,
          teamId: ev.teamId,
          visibility: ev.visibility as CalendarEventRecord["visibility"],
          createdAt: ev.createdAt.toISOString(),
          updatedAt: ev.updatedAt.toISOString(),
          canEdit,
        }
      })
    } catch (err) {
      console.warn("DB getUserEvents failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  const userShares = store.shares.filter((s) => s.sharedWithUserId === userId)
  const sharedIds = new Set(userShares.map((s) => s.eventId))

  const visible = store.events.filter(
    (e) => e.userId === userId || sharedIds.has(e.id),
  )

  return visible.map((e) => {
    const isOwner = e.userId === userId
    const share = userShares.find((s) => s.eventId === e.id)
    const canEdit = isOwner || share?.permission === "edit"
    const eventSharesList = isOwner
      ? store.shares.filter((s) => s.eventId === e.id)
      : []
    return {
      ...e,
      canEdit,
      shares: eventSharesList,
    }
  })
}

export async function createEvent(
  userId: number,
  data: Omit<
    CalendarEventRecord,
    "id" | "userId" | "createdAt" | "updatedAt" | "canEdit" | "shares"
  >,
  shares?: { userId: number; permission: "view" | "edit" }[],
): Promise<CalendarEventRecord> {
  const id = "evt_" + Date.now() + "_" + Math.random().toString(36).slice(2, 7)
  const now = new Date()

  if (hasDbUrl) {
    try {
      const inserted = await db
        .insert(calendarEvents)
        .values({
          id,
          userId,
          title: data.title,
          description: data.description,
          eventType: data.eventType,
          startDate: new Date(data.startDate),
          endDate: data.endDate ? new Date(data.endDate) : null,
          allDay: data.allDay,
          linkedFixtureId: data.linkedFixtureId,
          competition: data.competition,
          teamId: data.teamId,
          visibility: data.visibility,
          createdAt: now,
          updatedAt: now,
        })
        .returning()

      if (shares && shares.length > 0) {
        for (const s of shares) {
          await db.insert(eventShares).values({
            eventId: id,
            sharedWithUserId: s.userId,
            permission: s.permission,
            createdAt: now,
          })
        }
      }

      const ev = inserted[0]
      return {
        id: ev.id,
        userId: ev.userId,
        title: ev.title,
        description: ev.description,
        eventType: ev.eventType as CalendarEventRecord["eventType"],
        startDate: ev.startDate.toISOString(),
        endDate: ev.endDate ? ev.endDate.toISOString() : null,
        allDay: ev.allDay,
        linkedFixtureId: ev.linkedFixtureId,
        competition: ev.competition,
        teamId: ev.teamId,
        visibility: ev.visibility as CalendarEventRecord["visibility"],
        createdAt: ev.createdAt.toISOString(),
        updatedAt: ev.updatedAt.toISOString(),
        canEdit: true,
      }
    } catch (err) {
      console.warn("DB createEvent failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  const record: CalendarEventRecord = {
    ...data,
    id,
    userId,
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
    canEdit: true,
  }

  store.events.push(record)

  if (shares && shares.length > 0) {
    for (const s of shares) {
      store.shares.push({
        eventId: id,
        sharedWithUserId: s.userId,
        permission: s.permission,
        createdAt: now.toISOString(),
      })
    }
  }

  saveLocalStore(store)
  return record
}

export async function updateEvent(
  userId: number,
  eventId: string,
  data: Partial<
    Omit<
      CalendarEventRecord,
      "id" | "userId" | "createdAt" | "updatedAt" | "canEdit" | "shares"
    >
  >,
  shares?: { userId: number; permission: "view" | "edit" }[],
): Promise<CalendarEventRecord | null> {
  const now = new Date()

  if (hasDbUrl) {
    try {
      // Check permission
      const evRows = await db
        .select()
        .from(calendarEvents)
        .where(eq(calendarEvents.id, eventId))
      if (evRows.length === 0) return null
      const ev = evRows[0]
      const isOwner = ev.userId === userId
      if (!isOwner) {
        const shareRows = await db
          .select()
          .from(eventShares)
          .where(
            and(
              eq(eventShares.eventId, eventId),
              eq(eventShares.sharedWithUserId, userId),
            ),
          )
        if (shareRows.length === 0 || shareRows[0].permission !== "edit") {
          throw new Error("Unauthorized: you do not have permission to edit this event.")
        }
      }

      const updateValues: Record<string, unknown> = { updatedAt: now }
      if (data.title !== undefined) updateValues.title = data.title
      if (data.description !== undefined) updateValues.description = data.description
      if (data.eventType !== undefined) updateValues.eventType = data.eventType
      if (data.startDate !== undefined)
        updateValues.startDate = new Date(data.startDate)
      if (data.endDate !== undefined)
        updateValues.endDate = data.endDate ? new Date(data.endDate) : null
      if (data.allDay !== undefined) updateValues.allDay = data.allDay
      if (data.linkedFixtureId !== undefined)
        updateValues.linkedFixtureId = data.linkedFixtureId
      if (data.competition !== undefined) updateValues.competition = data.competition
      if (data.teamId !== undefined) updateValues.teamId = data.teamId
      if (data.visibility !== undefined) updateValues.visibility = data.visibility

      const updated = await db
        .update(calendarEvents)
        .set(updateValues)
        .where(eq(calendarEvents.id, eventId))
        .returning()

      if (isOwner && shares !== undefined) {
        await db.delete(eventShares).where(eq(eventShares.eventId, eventId))
        for (const s of shares) {
          await db.insert(eventShares).values({
            eventId,
            sharedWithUserId: s.userId,
            permission: s.permission,
            createdAt: now,
          })
        }
      }

      const res = updated[0]
      return {
        id: res.id,
        userId: res.userId,
        title: res.title,
        description: res.description,
        eventType: res.eventType as CalendarEventRecord["eventType"],
        startDate: res.startDate.toISOString(),
        endDate: res.endDate ? res.endDate.toISOString() : null,
        allDay: res.allDay,
        linkedFixtureId: res.linkedFixtureId,
        competition: res.competition,
        teamId: res.teamId,
        visibility: res.visibility as CalendarEventRecord["visibility"],
        createdAt: res.createdAt.toISOString(),
        updatedAt: res.updatedAt.toISOString(),
        canEdit: true,
      }
    } catch (err) {
      console.warn("DB updateEvent failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  const idx = store.events.findIndex((e) => e.id === eventId)
  if (idx === -1) return null

  const existing = store.events[idx]
  const isOwner = existing.userId === userId
  if (!isOwner) {
    const share = store.shares.find(
      (s) => s.eventId === eventId && s.sharedWithUserId === userId,
    )
    if (!share || share.permission !== "edit") {
      throw new Error("Unauthorized: you do not have permission to edit this event.")
    }
  }

  store.events[idx] = {
    ...existing,
    ...data,
    updatedAt: now.toISOString(),
  }

  if (isOwner && shares !== undefined) {
    store.shares = store.shares.filter((s) => s.eventId !== eventId)
    for (const s of shares) {
      store.shares.push({
        eventId,
        sharedWithUserId: s.userId,
        permission: s.permission,
        createdAt: now.toISOString(),
      })
    }
  }

  saveLocalStore(store)
  return store.events[idx]
}

export async function deleteEvent(
  userId: number,
  eventId: string,
): Promise<boolean> {
  if (hasDbUrl) {
    try {
      const evRows = await db
        .select()
        .from(calendarEvents)
        .where(eq(calendarEvents.id, eventId))
      if (evRows.length === 0) return false
      if (evRows[0].userId !== userId) {
        throw new Error("Unauthorized: only the event creator can delete this event.")
      }
      await db.delete(eventShares).where(eq(eventShares.eventId, eventId))
      await db.delete(calendarEvents).where(eq(calendarEvents.id, eventId))
      return true
    } catch (err) {
      console.warn("DB deleteEvent failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  const existing = store.events.find((e) => e.id === eventId)
  if (!existing) return false
  if (existing.userId !== userId) {
    throw new Error("Unauthorized: only the event creator can delete this event.")
  }

  store.events = store.events.filter((e) => e.id !== eventId)
  store.shares = store.shares.filter((s) => s.eventId !== eventId)
  saveLocalStore(store)
  return true
}

// ---------------------------------------------------------------------------
// SYNC LOGS
// ---------------------------------------------------------------------------

export async function logSync(log: SyncLogRecord): Promise<void> {
  if (hasDbUrl) {
    try {
      await db.insert(syncLogs).values({
        competition: log.competition,
        status: log.status,
        fixturesCount: log.fixturesCount,
        message: log.message,
        timestamp: new Date(log.timestamp),
      })
      return
    } catch (err) {
      console.warn("DB logSync failed:", err)
    }
  }

  const store = getLocalStore()
  store.syncLogs.unshift(log)
  if (store.syncLogs.length > 50) store.syncLogs.pop()
  saveLocalStore(store)
}

export async function getLatestSyncLog(
  competition?: string,
): Promise<SyncLogRecord | null> {
  if (hasDbUrl) {
    try {
      const q = db.select().from(syncLogs).orderBy(desc(syncLogs.timestamp))
      const rows = competition
        ? await q.where(eq(syncLogs.competition, competition)).limit(1)
        : await q.limit(1)
      if (rows.length > 0) {
        const r = rows[0]
        return {
          id: r.id,
          competition: r.competition,
          status: r.status as SyncLogRecord["status"],
          fixturesCount: r.fixturesCount,
          message: r.message,
          timestamp: r.timestamp.toISOString(),
        }
      }
    } catch (err) {
      console.warn("DB getLatestSyncLog failed:", err)
    }
  }

  const store = getLocalStore()
  const list = competition
    ? store.syncLogs.filter((l) => l.competition === competition)
    : store.syncLogs
  return list.length > 0 ? list[0] : null
}
