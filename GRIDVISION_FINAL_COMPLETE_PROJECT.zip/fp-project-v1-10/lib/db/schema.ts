import { pgTable, serial, text, timestamp, boolean, integer } from "drizzle-orm/pg-core"

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  salt: text("salt").notNull(),
  emailVerified: boolean("email_verified").notNull().default(false),
  emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

export const emailVerificationTokens = pgTable("email_verification_tokens", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

export const fixtures = pgTable("fixtures", {
  id: text("id").primaryKey(),
  competition: text("competition").notNull(),
  season: text("season").notNull(),
  round: text("round").notNull(),
  homeTeam: text("home_team").notNull(),
  awayTeam: text("away_team").notNull(),
  homeTeamId: integer("home_team_id"),
  awayTeamId: integer("away_team_id"),
  homeScore: integer("home_score"),
  awayScore: integer("away_score"),
  status: text("status").notNull().default("SCHEDULED"),
  kickoffTime: timestamp("kickoff_time", { withTimezone: true }).notNull(),
  venue: text("venue"),
  source: text("source").notNull(),
  lastUpdated: timestamp("last_updated", { withTimezone: true }).notNull().defaultNow(),
  dedupKey: text("dedup_key").notNull().unique(),
})

export const calendarEvents = pgTable("calendar_events", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  eventType: text("event_type").notNull().default("personal"),
  startDate: timestamp("start_date", { withTimezone: true }).notNull(),
  endDate: timestamp("end_date", { withTimezone: true }),
  allDay: boolean("all_day").notNull().default(false),
  linkedFixtureId: text("linked_fixture_id"),
  competition: text("competition"),
  teamId: integer("team_id"),
  visibility: text("visibility").notNull().default("private"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
})

export const eventShares = pgTable("event_shares", {
  id: serial("id").primaryKey(),
  eventId: text("event_id").notNull(),
  sharedWithUserId: integer("shared_with_user_id").notNull(),
  permission: text("permission").notNull().default("view"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
})

export const syncLogs = pgTable("sync_logs", {
  id: serial("id").primaryKey(),
  competition: text("competition").notNull(),
  status: text("status").notNull(),
  fixturesCount: integer("fixtures_count").notNull().default(0),
  message: text("message"),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
})

export const savedStrategies = pgTable("saved_strategies", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  notes: text("notes"),
  mode: text("mode").notNull().default("club"),
  season: text("season").notNull(),
  teamId: integer("team_id"),
  teamName: text("team_name").notNull(),
  formation: text("formation").notNull(),
  lineup: text("lineup").notNull(),
  tacticalPlan: text("tactical_plan"),
  verdict: text("verdict"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
})

