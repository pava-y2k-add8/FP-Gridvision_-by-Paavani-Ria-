import fs from "fs"
import path from "path"
import crypto from "crypto"
import { eq, and, desc } from "drizzle-orm"
import { db } from "./index"
import { savedStrategies } from "./schema"

const hasDbUrl = Boolean(process.env.DATABASE_URL && process.env.DATABASE_URL.trim() !== "")

export interface SavedSlotSetup {
  slotId: string
  line: "GK" | "DEF" | "MID" | "FWD"
  label: string
  x: number
  y: number
  playerId: number | null
  playerName?: string
  playerClub?: string
  playerPos?: string
  playerRating?: number
}

export interface SavedStrategyRecord {
  id: string
  userId: number
  name: string
  notes?: string | null
  mode: "club" | "dream"
  season: string
  teamId?: number | null
  teamName: string
  formation: string
  slots: SavedSlotSetup[]
  tacticalPlan?: any | null
  verdict?: string | null
  createdAt: string
  updatedAt: string
}

interface LocalStrategyStore {
  strategies: SavedStrategyRecord[]
}

const STORE_PATH = path.join(process.cwd(), ".data", "strategy-store.json")

function getLocalStore(): LocalStrategyStore {
  try {
    if (!fs.existsSync(STORE_PATH)) {
      const dir = path.dirname(STORE_PATH)
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
      const initial: LocalStrategyStore = { strategies: [] }
      fs.writeFileSync(STORE_PATH, JSON.stringify(initial, null, 2), "utf-8")
      return initial
    }
    const data = fs.readFileSync(STORE_PATH, "utf-8")
    return JSON.parse(data) as LocalStrategyStore
  } catch (err) {
    console.error("Failed to read local strategy store:", err)
    return { strategies: [] }
  }
}

function saveLocalStore(store: LocalStrategyStore): void {
  try {
    const dir = path.dirname(STORE_PATH)
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), "utf-8")
  } catch (err) {
    console.error("Failed to save local strategy store:", err)
    throw new Error("Local storage write failed: Unable to persist strategy data.")
  }
}

function generateId(): string {
  return "strat_" + crypto.randomUUID().replace(/-/g, "").slice(0, 16)
}

/**
 * Get all strategies belonging to a specific user.
 * Strictly enforced: Only records with userId === input userId are returned.
 */
export async function getUserStrategies(userId: number): Promise<SavedStrategyRecord[]> {
  if (hasDbUrl) {
    try {
      const rows = await db
        .select()
        .from(savedStrategies)
        .where(eq(savedStrategies.userId, userId))
        .orderBy(desc(savedStrategies.updatedAt))

      return rows.map((r) => ({
        id: r.id,
        userId: r.userId,
        name: r.name,
        notes: r.notes,
        mode: r.mode as "club" | "dream",
        season: r.season,
        teamId: r.teamId,
        teamName: r.teamName,
        formation: r.formation,
        slots: JSON.parse(r.lineup) as SavedSlotSetup[],
        tacticalPlan: r.tacticalPlan ? JSON.parse(r.tacticalPlan) : null,
        verdict: r.verdict,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
      }))
    } catch (err) {
      console.warn("DB getUserStrategies failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  return store.strategies
    .filter((s) => s.userId === userId)
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
}

/**
 * Get a single strategy by ID with strict user ownership verification.
 * Returns null if not found or if the strategy belongs to another user.
 */
export async function getStrategyById(id: string, userId: number): Promise<SavedStrategyRecord | null> {
  if (hasDbUrl) {
    try {
      const rows = await db
        .select()
        .from(savedStrategies)
        .where(and(eq(savedStrategies.id, id), eq(savedStrategies.userId, userId)))

      if (rows.length === 0) return null
      const r = rows[0]
      return {
        id: r.id,
        userId: r.userId,
        name: r.name,
        notes: r.notes,
        mode: r.mode as "club" | "dream",
        season: r.season,
        teamId: r.teamId,
        teamName: r.teamName,
        formation: r.formation,
        slots: JSON.parse(r.lineup) as SavedSlotSetup[],
        tacticalPlan: r.tacticalPlan ? JSON.parse(r.tacticalPlan) : null,
        verdict: r.verdict,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
      }
    } catch (err) {
      console.warn("DB getStrategyById failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  const found = store.strategies.find((s) => s.id === id)
  if (!found || found.userId !== userId) {
    return null
  }
  return found
}

/**
 * Create a new saved strategy linked to an authenticated user.
 */
export async function createStrategy(data: {
  userId: number
  name: string
  notes?: string | null
  mode: "club" | "dream"
  season: string
  teamId?: number | null
  teamName: string
  formation: string
  slots: SavedSlotSetup[]
  tacticalPlan?: any | null
  verdict?: string | null
}): Promise<SavedStrategyRecord> {
  const id = generateId()
  const now = new Date()

  if (hasDbUrl) {
    try {
      const [inserted] = await db
        .insert(savedStrategies)
        .values({
          id,
          userId: data.userId,
          name: data.name.trim(),
          notes: data.notes ? data.notes.trim() : null,
          mode: data.mode,
          season: data.season,
          teamId: data.teamId ?? null,
          teamName: data.teamName,
          formation: data.formation,
          lineup: JSON.stringify(data.slots),
          tacticalPlan: data.tacticalPlan ? JSON.stringify(data.tacticalPlan) : null,
          verdict: data.verdict ?? null,
          createdAt: now,
          updatedAt: now,
        })
        .returning()

      if (inserted) {
        return {
          id: inserted.id,
          userId: inserted.userId,
          name: inserted.name,
          notes: inserted.notes,
          mode: inserted.mode as "club" | "dream",
          season: inserted.season,
          teamId: inserted.teamId,
          teamName: inserted.teamName,
          formation: inserted.formation,
          slots: JSON.parse(inserted.lineup) as SavedSlotSetup[],
          tacticalPlan: inserted.tacticalPlan ? JSON.parse(inserted.tacticalPlan) : null,
          verdict: inserted.verdict,
          createdAt: inserted.createdAt.toISOString(),
          updatedAt: inserted.updatedAt.toISOString(),
        }
      }
    } catch (err) {
      console.warn("DB createStrategy failed, falling back to local store:", err)
    }
  }

  const record: SavedStrategyRecord = {
    id,
    userId: data.userId,
    name: data.name.trim(),
    notes: data.notes ? data.notes.trim() : null,
    mode: data.mode,
    season: data.season,
    teamId: data.teamId ?? null,
    teamName: data.teamName,
    formation: data.formation,
    slots: data.slots,
    tacticalPlan: data.tacticalPlan ?? null,
    verdict: data.verdict ?? null,
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
  }

  const store = getLocalStore()
  store.strategies.push(record)
  saveLocalStore(store)
  return record
}

/**
 * Update an existing strategy. Strictly enforces that the caller owns this strategy.
 */
export async function updateStrategy(
  id: string,
  userId: number,
  data: Partial<{
    name: string
    notes?: string | null
    mode: "club" | "dream"
    season: string
    teamId?: number | null
    teamName: string
    formation: string
    slots: SavedSlotSetup[]
    tacticalPlan?: any | null
    verdict?: string | null
  }>
): Promise<SavedStrategyRecord> {
  const now = new Date()

  if (hasDbUrl) {
    try {
      // Check ownership first
      const existing = await db
        .select()
        .from(savedStrategies)
        .where(eq(savedStrategies.id, id))

      if (existing.length === 0) {
        throw new Error("Strategy not found.")
      }
      if (existing[0].userId !== userId) {
        throw new Error("Unauthorized: You do not have permission to modify this strategy.")
      }

      const updateValues: Record<string, any> = {
        updatedAt: now,
      }
      if (data.name !== undefined) updateValues.name = data.name.trim()
      if (data.notes !== undefined) updateValues.notes = data.notes ? data.notes.trim() : null
      if (data.mode !== undefined) updateValues.mode = data.mode
      if (data.season !== undefined) updateValues.season = data.season
      if (data.teamId !== undefined) updateValues.teamId = data.teamId
      if (data.teamName !== undefined) updateValues.teamName = data.teamName
      if (data.formation !== undefined) updateValues.formation = data.formation
      if (data.slots !== undefined) updateValues.lineup = JSON.stringify(data.slots)
      if (data.tacticalPlan !== undefined) {
        updateValues.tacticalPlan = data.tacticalPlan ? JSON.stringify(data.tacticalPlan) : null
      }
      if (data.verdict !== undefined) updateValues.verdict = data.verdict

      const [updated] = await db
        .update(savedStrategies)
        .set(updateValues)
        .where(and(eq(savedStrategies.id, id), eq(savedStrategies.userId, userId)))
        .returning()

      if (updated) {
        return {
          id: updated.id,
          userId: updated.userId,
          name: updated.name,
          notes: updated.notes,
          mode: updated.mode as "club" | "dream",
          season: updated.season,
          teamId: updated.teamId,
          teamName: updated.teamName,
          formation: updated.formation,
          slots: JSON.parse(updated.lineup) as SavedSlotSetup[],
          tacticalPlan: updated.tacticalPlan ? JSON.parse(updated.tacticalPlan) : null,
          verdict: updated.verdict,
          createdAt: updated.createdAt.toISOString(),
          updatedAt: updated.updatedAt.toISOString(),
        }
      }
    } catch (err) {
      if ((err as Error).message.startsWith("Unauthorized") || (err as Error).message.startsWith("Strategy not found")) {
        throw err
      }
      console.warn("DB updateStrategy failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  const idx = store.strategies.findIndex((s) => s.id === id)
  if (idx === -1) {
    throw new Error("Strategy not found.")
  }

  const existing = store.strategies[idx]
  if (existing.userId !== userId) {
    throw new Error("Unauthorized: You do not have permission to modify this strategy.")
  }

  const updatedRecord: SavedStrategyRecord = {
    ...existing,
    ...(data.name !== undefined && { name: data.name.trim() }),
    ...(data.notes !== undefined && { notes: data.notes ? data.notes.trim() : null }),
    ...(data.mode !== undefined && { mode: data.mode }),
    ...(data.season !== undefined && { season: data.season }),
    ...(data.teamId !== undefined && { teamId: data.teamId }),
    ...(data.teamName !== undefined && { teamName: data.teamName }),
    ...(data.formation !== undefined && { formation: data.formation }),
    ...(data.slots !== undefined && { slots: data.slots }),
    ...(data.tacticalPlan !== undefined && { tacticalPlan: data.tacticalPlan }),
    ...(data.verdict !== undefined && { verdict: data.verdict }),
    updatedAt: now.toISOString(),
  }

  store.strategies[idx] = updatedRecord
  saveLocalStore(store)
  return updatedRecord
}

/**
 * Duplicate a strategy. Checks caller ownership and creates an identical copy with a new ID and '(Copy)' appended.
 */
export async function duplicateStrategy(id: string, userId: number): Promise<SavedStrategyRecord> {
  const existing = await getStrategyById(id, userId)
  if (!existing) {
    throw new Error("Strategy not found or you do not have permission to duplicate it.")
  }

  return createStrategy({
    userId,
    name: `${existing.name} (Copy)`,
    notes: existing.notes,
    mode: existing.mode,
    season: existing.season,
    teamId: existing.teamId,
    teamName: existing.teamName,
    formation: existing.formation,
    slots: existing.slots,
    tacticalPlan: existing.tacticalPlan,
    verdict: existing.verdict,
  })
}

/**
 * Delete a strategy. Strictly enforces caller ownership.
 */
export async function deleteStrategy(id: string, userId: number): Promise<boolean> {
  if (hasDbUrl) {
    try {
      const existing = await db
        .select()
        .from(savedStrategies)
        .where(eq(savedStrategies.id, id))

      if (existing.length === 0) {
        throw new Error("Strategy not found.")
      }
      if (existing[0].userId !== userId) {
        throw new Error("Unauthorized: You do not have permission to delete this strategy.")
      }

      await db
        .delete(savedStrategies)
        .where(and(eq(savedStrategies.id, id), eq(savedStrategies.userId, userId)))

      return true
    } catch (err) {
      if ((err as Error).message.startsWith("Unauthorized") || (err as Error).message.startsWith("Strategy not found")) {
        throw err
      }
      console.warn("DB deleteStrategy failed, falling back to local store:", err)
    }
  }

  const store = getLocalStore()
  const idx = store.strategies.findIndex((s) => s.id === id)
  if (idx === -1) {
    throw new Error("Strategy not found.")
  }

  if (store.strategies[idx].userId !== userId) {
    throw new Error("Unauthorized: You do not have permission to delete this strategy.")
  }

  store.strategies.splice(idx, 1)
  saveLocalStore(store)
  return true
}
