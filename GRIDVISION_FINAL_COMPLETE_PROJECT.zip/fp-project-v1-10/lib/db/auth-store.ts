import fs from "fs"
import path from "path"
import { db } from "./index"
import { users, emailVerificationTokens } from "./schema"
import { eq, desc } from "drizzle-orm"

export interface UserRecord {
  id: number
  email: string
  name: string
  passwordHash: string
  salt: string
  emailVerified: boolean
  emailVerifiedAt: string | null
  createdAt: string
}

export interface TokenRecord {
  id: number
  email: string
  token: string
  expiresAt: string
  createdAt: string
}

interface LocalStoreData {
  users: UserRecord[]
  tokens: TokenRecord[]
}

const DATA_DIR = path.join(process.cwd(), ".data")
const STORE_FILE = path.join(DATA_DIR, "auth-store.json")

function getLocalStore(): LocalStoreData {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true })
    }
    if (!fs.existsSync(STORE_FILE)) {
      const initial: LocalStoreData = { users: [], tokens: [] }
      fs.writeFileSync(STORE_FILE, JSON.stringify(initial, null, 2), "utf-8")
      return initial
    }
    const raw = fs.readFileSync(STORE_FILE, "utf-8")
    return JSON.parse(raw) as LocalStoreData
  } catch (err) {
    console.error("[auth-store] Failed to read local store:", err)
    return { users: [], tokens: [] }
  }
}

function saveLocalStore(data: LocalStoreData): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true })
    }
    fs.writeFileSync(STORE_FILE, JSON.stringify(data, null, 2), "utf-8")
  } catch (err) {
    console.error("[auth-store] Failed to write local store:", err)
  }
}

const hasDbUrl = Boolean(process.env.DATABASE_URL && process.env.DATABASE_URL.trim() !== "")

export async function findUserByEmail(email: string): Promise<UserRecord | null> {
  const normalized = email.toLowerCase().trim()
  if (hasDbUrl) {
    try {
      const rows = await db.select().from(users).where(eq(users.email, normalized))
      if (rows.length > 0) {
        const u = rows[0]
        return {
          id: u.id,
          email: u.email,
          name: u.name,
          passwordHash: u.passwordHash,
          salt: u.salt,
          emailVerified: u.emailVerified,
          emailVerifiedAt: u.emailVerifiedAt ? u.emailVerifiedAt.toISOString() : null,
          createdAt: u.createdAt.toISOString(),
        }
      }
    } catch {
      // Fallback to local store if DB is down or unreachable
    }
  }

  const store = getLocalStore()
  return store.users.find((u) => u.email.toLowerCase() === normalized) || null
}

export async function findUserById(id: number): Promise<UserRecord | null> {
  if (hasDbUrl) {
    try {
      const rows = await db.select().from(users).where(eq(users.id, id))
      if (rows.length > 0) {
        const u = rows[0]
        return {
          id: u.id,
          email: u.email,
          name: u.name,
          passwordHash: u.passwordHash,
          salt: u.salt,
          emailVerified: u.emailVerified,
          emailVerifiedAt: u.emailVerifiedAt ? u.emailVerifiedAt.toISOString() : null,
          createdAt: u.createdAt.toISOString(),
        }
      }
    } catch {
      // Fallback
    }
  }

  const store = getLocalStore()
  return store.users.find((u) => u.id === id) || null
}

export async function createUser(data: {
  email: string
  name: string
  passwordHash: string
  salt: string
}): Promise<UserRecord> {
  const normalized = data.email.toLowerCase().trim()
  if (hasDbUrl) {
    try {
      const inserted = await db
        .insert(users)
        .values({
          email: normalized,
          name: data.name,
          passwordHash: data.passwordHash,
          salt: data.salt,
          emailVerified: false,
        })
        .returning()
      if (inserted.length > 0) {
        const u = inserted[0]
        return {
          id: u.id,
          email: u.email,
          name: u.name,
          passwordHash: u.passwordHash,
          salt: u.salt,
          emailVerified: u.emailVerified,
          emailVerifiedAt: null,
          createdAt: u.createdAt.toISOString(),
        }
      }
    } catch {
      // Fallback to local store
    }
  }

  const store = getLocalStore()
  const newId = store.users.length > 0 ? Math.max(...store.users.map((u) => u.id)) + 1 : 1
  const record: UserRecord = {
    id: newId,
    email: normalized,
    name: data.name,
    passwordHash: data.passwordHash,
    salt: data.salt,
    emailVerified: false,
    emailVerifiedAt: null,
    createdAt: new Date().toISOString(),
  }
  store.users.push(record)
  saveLocalStore(store)
  return record
}

export async function updateUserPassword(
  email: string,
  passwordHash: string,
  salt: string,
): Promise<UserRecord | null> {
  const normalized = email.toLowerCase().trim()
  if (hasDbUrl) {
    try {
      const updated = await db
        .update(users)
        .set({ passwordHash, salt })
        .where(eq(users.email, normalized))
        .returning()
      if (updated.length > 0) {
        const u = updated[0]
        return {
          id: u.id,
          email: u.email,
          name: u.name,
          passwordHash: u.passwordHash,
          salt: u.salt,
          emailVerified: u.emailVerified,
          emailVerifiedAt: u.emailVerifiedAt ? u.emailVerifiedAt.toISOString() : null,
          createdAt: u.createdAt.toISOString(),
        }
      }
    } catch {
      // Fallback
    }
  }

  const store = getLocalStore()
  const idx = store.users.findIndex((u) => u.email.toLowerCase() === normalized)
  if (idx !== -1) {
    store.users[idx].passwordHash = passwordHash
    store.users[idx].salt = salt
    saveLocalStore(store)
    return store.users[idx]
  }
  return null
}

export async function setUserEmailVerified(email: string): Promise<UserRecord | null> {
  const normalized = email.toLowerCase().trim()
  const now = new Date()
  if (hasDbUrl) {
    try {
      const updated = await db
        .update(users)
        .set({ emailVerified: true, emailVerifiedAt: now })
        .where(eq(users.email, normalized))
        .returning()
      if (updated.length > 0) {
        const u = updated[0]
        return {
          id: u.id,
          email: u.email,
          name: u.name,
          passwordHash: u.passwordHash,
          salt: u.salt,
          emailVerified: u.emailVerified,
          emailVerifiedAt: u.emailVerifiedAt ? u.emailVerifiedAt.toISOString() : null,
          createdAt: u.createdAt.toISOString(),
        }
      }
    } catch {
      // Fallback
    }
  }

  const store = getLocalStore()
  const idx = store.users.findIndex((u) => u.email.toLowerCase() === normalized)
  if (idx !== -1) {
    store.users[idx].emailVerified = true
    store.users[idx].emailVerifiedAt = now.toISOString()
    saveLocalStore(store)
    return store.users[idx]
  }
  return null
}

export async function createVerificationToken(
  email: string,
  token: string,
  expiresAt: Date,
): Promise<TokenRecord> {
  const normalized = email.toLowerCase().trim()
  if (hasDbUrl) {
    try {
      const inserted = await db
        .insert(emailVerificationTokens)
        .values({
          email: normalized,
          token,
          expiresAt,
        })
        .returning()
      if (inserted.length > 0) {
        const t = inserted[0]
        return {
          id: t.id,
          email: t.email,
          token: t.token,
          expiresAt: t.expiresAt.toISOString(),
          createdAt: t.createdAt.toISOString(),
        }
      }
    } catch {
      // Fallback
    }
  }

  const store = getLocalStore()
  const newId = store.tokens.length > 0 ? Math.max(...store.tokens.map((t) => t.id)) + 1 : 1
  const record: TokenRecord = {
    id: newId,
    email: normalized,
    token,
    expiresAt: expiresAt.toISOString(),
    createdAt: new Date().toISOString(),
  }
  store.tokens.push(record)
  saveLocalStore(store)
  return record
}

export async function findVerificationToken(token: string): Promise<TokenRecord | null> {
  if (hasDbUrl) {
    try {
      const rows = await db
        .select()
        .from(emailVerificationTokens)
        .where(eq(emailVerificationTokens.token, token))
      if (rows.length > 0) {
        const t = rows[0]
        return {
          id: t.id,
          email: t.email,
          token: t.token,
          expiresAt: t.expiresAt.toISOString(),
          createdAt: t.createdAt.toISOString(),
        }
      }
    } catch {
      // Fallback
    }
  }

  const store = getLocalStore()
  return store.tokens.find((t) => t.token === token) || null
}

export async function deleteVerificationToken(token: string): Promise<void> {
  if (hasDbUrl) {
    try {
      await db
        .delete(emailVerificationTokens)
        .where(eq(emailVerificationTokens.token, token))
    } catch {
      // Fallback
    }
  }

  const store = getLocalStore()
  store.tokens = store.tokens.filter((t) => t.token !== token)
  saveLocalStore(store)
}

export async function getRecentTokenForEmail(email: string): Promise<TokenRecord | null> {
  const normalized = email.toLowerCase().trim()
  if (hasDbUrl) {
    try {
      const rows = await db
        .select()
        .from(emailVerificationTokens)
        .where(eq(emailVerificationTokens.email, normalized))
        .orderBy(desc(emailVerificationTokens.createdAt))
        .limit(1)
      if (rows.length > 0) {
        const t = rows[0]
        return {
          id: t.id,
          email: t.email,
          token: t.token,
          expiresAt: t.expiresAt.toISOString(),
          createdAt: t.createdAt.toISOString(),
        }
      }
    } catch {
      // Fallback
    }
  }

  const store = getLocalStore()
  const matching = store.tokens.filter((t) => t.email.toLowerCase() === normalized)
  if (matching.length === 0) return null
  return matching[matching.length - 1]
}
