import crypto from "crypto"

/**
 * Hash a password using PBKDF2 with a secure random salt.
 */
export function hashPassword(password: string): { hash: string; salt: string } {
  const salt = crypto.randomBytes(16).toString("hex")
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, "sha512").toString("hex")
  return { hash, salt }
}

/**
 * Verify a plaintext password against a stored hash and salt.
 */
export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const verifyHash = crypto.pbkdf2Sync(password, salt, 10000, 64, "sha512").toString("hex")
  return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(verifyHash, "hex"))
}

/**
 * Generate a cryptographically secure random token for email verification.
 */
export function generateVerificationToken(): string {
  return crypto.randomBytes(32).toString("hex")
}
