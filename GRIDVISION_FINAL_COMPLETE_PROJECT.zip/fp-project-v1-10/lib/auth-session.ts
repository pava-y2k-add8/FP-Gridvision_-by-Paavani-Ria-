import { cookies } from "next/headers"
import crypto from "crypto"

const COOKIE_NAME = "fifa_scout_session"
const SECRET = process.env.AUTH_SECRET || "fifa-scout-dev-secret-key-928131"

export interface SessionPayload {
  userId: number
  email: string
  name: string
  emailVerified: boolean
  exp: number
}

function sign(payload: string): string {
  return crypto.createHmac("sha256", SECRET).update(payload).digest("hex")
}

export function createToken(payload: SessionPayload): string {
  const json = JSON.stringify(payload)
  const base64 = Buffer.from(json).toString("base64url")
  const signature = sign(base64)
  return `${base64}.${signature}`
}

export function verifyToken(token: string): SessionPayload | null {
  try {
    const parts = token.split(".")
    if (parts.length !== 2) return null
    const [base64, signature] = parts
    const expectedSig = sign(base64)
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) {
      return null
    }
    const json = Buffer.from(base64, "base64url").toString("utf-8")
    const payload = JSON.parse(json) as SessionPayload
    if (Date.now() > payload.exp) {
      return null
    }
    return payload
  } catch {
    return null
  }
}

export async function setAuthSession(user: {
  id: number
  email: string
  name: string
  emailVerified: boolean
}): Promise<void> {
  const cookieStore = await cookies()
  const exp = Date.now() + 7 * 24 * 60 * 60 * 1000 // 7 days
  const payload: SessionPayload = {
    userId: user.id,
    email: user.email,
    name: user.name,
    emailVerified: user.emailVerified,
    exp,
  }
  const token = createToken(payload)
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 7 * 24 * 60 * 60,
  })
}

export async function getAuthSession(): Promise<SessionPayload | null> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(COOKIE_NAME)?.value
    if (!token) return null
    return verifyToken(token)
  } catch {
    return null
  }
}

export async function clearAuthSession(): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.delete(COOKIE_NAME)
}
