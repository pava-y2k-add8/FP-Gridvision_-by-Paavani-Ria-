import { eloMatchup, teamAttack, teamDefense, type Team } from "./data"

export type Outcome = "home" | "draw" | "away"

export interface GridVisionPrediction {
  pick: Outcome
  winner: Team | null // null when the model favours a draw
  confidence: number // model's projected success rate for the pick, %
  headline: string
  strategy: string // the tactical approach GridVision expects to decide it
  rationale: string[]
}

// GridVision's tactical prediction model. Reads the clubs' real season-derived
// ratings (Elo, attack, defense) and turns them into a favoured outcome,
// a projected confidence level, and the tactical game plan behind it.
export function gridVisionPredict(home: Team, away: Team): GridVisionPrediction {
  const { homeWin, draw, awayWin, possHome } = eloMatchup(home, away)

  const outcomes: { key: Outcome; value: number }[] = [
    { key: "home", value: homeWin },
    { key: "draw", value: draw },
    { key: "away", value: awayWin },
  ]
  outcomes.sort((a, b) => b.value - a.value)
  const top = outcomes[0]

  const pick = top.key
  const winner = pick === "home" ? home : pick === "away" ? away : null
  const confidence = top.value

  if (!winner) {
    return {
      pick,
      winner: null,
      confidence,
      headline: `${home.name} and ${away.name} are too evenly matched to separate`,
      strategy: "Cagey, low-margin game decided by set pieces",
      rationale: [
        `Elo is near-level (${home.name} ${home.elo} vs ${away.name} ${away.elo}).`,
        `Projected possession is split ${possHome}% / ${100 - possHome}%.`,
        "Neither side's attack clears the other's defense by a decisive margin.",
      ],
    }
  }

  const loser = winner === home ? away : home
  const atk = teamAttack(winner)
  const def = teamDefense(winner)
  const oppDef = teamDefense(loser)
  const oppAtk = teamAttack(loser)

  let strategy: string
  if (atk - oppDef >= 8) {
    strategy = "High press with wide overloads to exploit a weaker back line"
  } else if (def - oppAtk >= 8) {
    strategy = "Compact block that soaks pressure and springs fast counters"
  } else {
    strategy = "Patient possession, controlling tempo and territory"
  }

  return {
    pick,
    winner,
    confidence,
    headline: `${winner.name} to beat ${loser.name}`,
    strategy,
    rationale: [
      `${winner.name} hold the Elo edge (${winner.elo} vs ${loser.elo}).`,
      `Attack ${atk} vs ${loser.name}'s defense ${oppDef} tilts the chances created.`,
      pick === "home"
        ? `Home advantage lifts projected possession to ${possHome}%.`
        : `${winner.name} are backed to control the game away from home.`,
    ],
  }
}
