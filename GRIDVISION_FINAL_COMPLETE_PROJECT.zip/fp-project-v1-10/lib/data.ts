// Real FIFA player ratings dataset
// (source: github.com/tkarim45/Beginner-Data-Science-Projects — FIFA Player Statistics Analysis/data/fifa.csv)
// Trimmed into lib/fifa/*.json via scripts/generate-fifa.mjs, one slot per flagship league.
import teamsWC from "./fifa/teams-world-cup.json"
import teamsPL from "./fifa/teams-premier-league.json"
import teamsLL from "./fifa/teams-la-liga.json"
import teamsSA from "./fifa/teams-serie-a.json"
import playersWC from "./fifa/players-world-cup.json"
import playersPL from "./fifa/players-premier-league.json"
import playersLL from "./fifa/players-la-liga.json"
import playersSA from "./fifa/players-serie-a.json"

export type Position = "GKP" | "DEF" | "MID" | "FWD"

export interface Team {
  id: number
  name: string
  short: string
  color: string
  // Ratings derived from the club's real FIFA player ratings
  attack: number
  defense: number
  overall: number
  elo: number
  eloChange?: number
  eloPeak?: number
  eloMatches?: number
  isLiveElo?: boolean
}

export interface AttributeGroup {
  [key: string]: number
}

export interface Player {
  id: number
  name: string
  longName: string
  pos: Position
  positions: string
  teamId: number
  team: string
  club: string
  nationality: string
  age: number
  dob: string
  heightCm: number
  weightKg: number
  overall: number
  potential: number
  valueEur: number
  wageEur: number
  releaseClauseEur: number
  preferredFoot: string
  weakFoot: number
  skillMoves: number
  intReputation: number
  workRate: string
  bodyType: string
  jerseyNumber: number
  traits: string
  // main FIFA face stats (PAC SHO PAS DRI DEF PHY; GK equivalents for keepers)
  pace: number
  shooting: number
  passing: number
  dribbling: number
  defending: number
  physic: number
  attacking: AttributeGroup
  skill: AttributeGroup
  movement: AttributeGroup
  power: AttributeGroup
  mentality: AttributeGroup
  defense: AttributeGroup
  goalkeeping: AttributeGroup
}

// The dataset slots the UI switches between: the FIFA World Cup 2026 national
// teams plus three flagship club leagues, newest FIFA snapshot.
export const SEASONS = ["world-cup", "premier-league", "la-liga", "serie-a"] as const
export type Season = (typeof SEASONS)[number]
export const DEFAULT_SEASON: Season = "world-cup"

export const SEASON_LABELS: Record<Season, string> = {
  "world-cup": "FIFA World Cup",
  "premier-league": "Premier League",
  "la-liga": "La Liga",
  "serie-a": "Serie A",
}

export const SEASON_SHORT: Record<Season, string> = {
  "world-cup": "WC26",
  "premier-league": "ENG",
  "la-liga": "ESP",
  "serie-a": "ITA",
}

interface RawTeam {
  id: number
  name: string
  short: string
  color: string
}

function scale(v: number, min: number, max: number, lo: number, hi: number) {
  if (max === min) return Math.round((lo + hi) / 2)
  return Math.round(lo + ((hi - lo) * (v - min)) / (max - min))
}

function mean(nums: number[]) {
  if (nums.length === 0) return 0
  return nums.reduce((s, n) => s + n, 0) / nums.length
}

// Club ratings are derived from the real FIFA ratings of each squad: the
// attacking third's shooting/dribbling drives attack, the back line's defending
// (plus the keeper) drives defense, then both are scaled across the league.
function enrichTeams(rawTeams: RawTeam[], players: Player[]): Team[] {
  const raw = rawTeams.map((t) => {
    const squad = players.filter((p) => p.teamId === t.id)
    const attackers = squad
      .filter((p) => p.pos === "FWD" || p.pos === "MID")
      .sort((a, b) => b.overall - a.overall)
      .slice(0, 6)
    const defenders = squad
      .filter((p) => p.pos === "DEF" || p.pos === "GKP")
      .sort((a, b) => b.overall - a.overall)
      .slice(0, 6)
    const attackRaw = mean(attackers.map((p) => (p.shooting + p.dribbling + p.pace) / 3))
    const defenseRaw = mean(defenders.map((p) => (p.defending + p.physic) / 2))
    return { t, attackRaw, defenseRaw }
  })

  const aVals = raw.map((r) => r.attackRaw)
  const dVals = raw.map((r) => r.defenseRaw)
  const aMin = Math.min(...aVals)
  const aMax = Math.max(...aVals)
  const dMin = Math.min(...dVals)
  const dMax = Math.max(...dVals)

  return raw.map(({ t, attackRaw, defenseRaw }) => {
    const attack = scale(attackRaw, aMin, aMax, 58, 94)
    const defense = scale(defenseRaw, dMin, dMax, 58, 94)
    const overall = Math.round((attack + defense) / 2)
    const elo = Math.round(1300 + ((overall - 55) / 40) * 450)
    return { id: t.id, name: t.name, short: t.short, color: t.color, attack, defense, overall, elo }
  })
}

function buildSeason(rawTeams: unknown, rawPlayers: unknown) {
  const players = rawPlayers as Player[]
  return { teams: enrichTeams(rawTeams as RawTeam[], players), players }
}

const DATA: Record<Season, { teams: Team[]; players: Player[] }> = {
  "world-cup": buildSeason(teamsWC, playersWC),
  "premier-league": buildSeason(teamsPL, playersPL),
  "la-liga": buildSeason(teamsLL, playersLL),
  "serie-a": buildSeason(teamsSA, playersSA),
}

export function getSeason(season: Season) {
  return DATA[season]
}

export function applyLiveEloRatings(liveEloMap: Record<string, any>) {
  if (!liveEloMap) return
  for (const season of SEASONS) {
    for (const team of DATA[season].teams) {
      const keyName = team.name.toLowerCase()
      const keyShort = team.short.toLowerCase()
      const keyCode = team.short.toUpperCase()

      let match = liveEloMap[keyName] || liveEloMap[keyShort] || liveEloMap[keyCode]
      if (!match) {
        const cleanName = keyName.replace(/\s+(fc|cf|ud|cd|rc|sd|afc)$/i, "").trim()
        for (const [k, v] of Object.entries(liveEloMap)) {
          if (k.length >= 3 && (cleanName.includes(k) || k.includes(cleanName))) {
            match = v as any
            break
          }
        }
      }

      if (match && typeof match.elo === "number") {
        team.elo = Math.round(match.elo)
        team.eloChange = match.last_elo_change
        team.eloPeak = match.peak_elo
        team.eloMatches = match.matches_played
        team.isLiveElo = true
      }
    }
  }
}


export const POSITIONS: Position[] = ["GKP", "DEF", "MID", "FWD"]
export const POSITION_LABELS: Record<Position, string> = {
  GKP: "Goalkeepers",
  DEF: "Defenders",
  MID: "Midfielders",
  FWD: "Forwards",
}

// Every club carries its own generated badge colour; index them by short code.
const COLOR_BY_SHORT: Record<string, string> = {}
for (const season of SEASONS) {
  for (const t of DATA[season].teams) COLOR_BY_SHORT[t.short] = t.color
}

export function teamColor(short: string) {
  return COLOR_BY_SHORT[short] ?? "#8b95a5"
}

export function teamAttack(t: Team) {
  return t.attack
}
export function teamDefense(t: Team) {
  return t.defense
}
export function teamOverall(t: Team) {
  return t.overall
}

// Compact euro formatter for values/wages (e.g. €40.5M, €210K).
export function formatEuro(v: number) {
  if (v >= 1_000_000) return `€${(v / 1_000_000).toFixed(v >= 10_000_000 ? 0 : 1)}M`
  if (v >= 1_000) return `€${Math.round(v / 1_000)}K`
  return `€${v}`
}

export interface MatchupResult {
  homeWin: number
  draw: number
  awayWin: number
  possHome: number
  possAway: number
}

// Elo-based match projection with home advantage
export function eloMatchup(home: Team, away: Team): MatchupResult {
  const HOME_ADV = 70
  const diff = home.elo + HOME_ADV - away.elo
  const eHome = 1 / (1 + Math.pow(10, -diff / 400))

  const drawShare = 0.27 * (1 - 2 * Math.abs(eHome - 0.5))
  let homeWin = (1 - drawShare) * eHome
  let awayWin = (1 - drawShare) * (1 - eHome)
  let draw = drawShare

  homeWin = Math.round(homeWin * 100)
  draw = Math.round(draw * 100)
  awayWin = 100 - homeWin - draw

  const strDiff = teamAttack(home) - teamDefense(away) - (teamAttack(away) - teamDefense(home))
  const possHome = Math.max(30, Math.min(70, Math.round(50 + strDiff / 12)))

  return { homeWin, draw, awayWin, possHome, possAway: 100 - possHome }
}

export interface TeamAggregate {
  team: Team
  squadSize: number
  topPlayer: Player | null
  avgOverall: number
}

export function teamAggregates(season: Season): TeamAggregate[] {
  const { teams, players } = getSeason(season)
  return teams
    .map((team) => {
      const squad = players.filter((p) => p.teamId === team.id)
      const avgOverall = squad.length ? Math.round(mean(squad.map((p) => p.overall))) : 0
      const topPlayer = squad.length
        ? squad.reduce((best, p) => (p.overall > best.overall ? p : best))
        : null
      return { team, squadSize: squad.length, topPlayer, avgOverall }
    })
    .sort((a, b) => b.team.elo - a.team.elo)
}

// Look up a single player by sofifa id across every league.
export function getPlayerById(id: number): { player: Player; season: Season } | null {
  for (const season of SEASONS) {
    const player = DATA[season].players.find((p) => p.id === id)
    if (player) return { player, season }
  }
  return null
}

// ---- Strategy Builder: the full talent pool across every league ----
// Each league's players are distinct, so the pool is simply their union with an
// overall-derived rating the builder can sort and pick an XI from.

export interface CareerPlayer extends Player {
  seasonsPlayed: number
  rating: number
  league: Season
}

let CAREER_CACHE: CareerPlayer[] | null = null

export function getCareerPlayers(): CareerPlayer[] {
  if (CAREER_CACHE) return CAREER_CACHE
  const arr: CareerPlayer[] = []
  for (const season of SEASONS) {
    for (const p of getSeason(season).players) {
      arr.push({ ...p, seasonsPlayed: 1, rating: p.overall, league: season })
    }
  }
  CAREER_CACHE = arr
  return arr
}

export function getCareerSquad(teamId: number, season?: Season): CareerPlayer[] {
  if (season) {
    return getSeason(season).players
      .filter((p) => p.teamId === teamId)
      .map((p) => ({ ...p, seasonsPlayed: 1, rating: p.overall, league: season }))
      .sort((a, b) => b.rating - a.rating)
  }
  return getCareerPlayers()
    .filter((p) => p.teamId === teamId)
    .sort((a, b) => b.rating - a.rating)
}

// The full list of clubs across every league.
export function getAllTeams(): Team[] {
  const map = new Map<number, Team>()
  for (const season of SEASONS) {
    for (const t of getSeason(season).teams) {
      if (!map.has(t.id)) map.set(t.id, t)
    }
  }
  return [...map.values()].sort((a, b) => a.name.localeCompare(b.name))
}
