// Bayesian shooting-decision engine
// Adapted from the decision network in
// github.com/tadiwa-aizen/Optimizing-Football-Performance-with-Bayesian-Decision-Making-Tool
//
// The original notebook builds a Bayesian network over event factors (shot
// location, assist method, situation, body part, goalkeeper position) and a
// decision node that advises whether a player should shoot. We reproduce that
// idea as a naive-Bayes-style model whose conditional probabilities approximate
// real open-play conversion rates, then wrap it in an expected-value decision
// rule (shoot vs. pass/hold).

export type ShotLocation =
  | "six-yard"
  | "penalty-spot"
  | "box-edge"
  | "outside-box"
  | "long-range"

export type AssistMethod = "solo" | "pass" | "through-ball" | "cross" | "headed-pass"
export type Situation = "open-play" | "fast-break" | "set-piece" | "corner"
export type BodyPart = "strong-foot" | "weak-foot" | "head"
export type KeeperPosition = "rushing-out" | "off-line" | "on-line" | "well-set"
export type Pressure = "none" | "light" | "heavy"

export interface ShotContext {
  location: ShotLocation
  assist: AssistMethod
  situation: Situation
  body: BodyPart
  keeper: KeeperPosition
  pressure: Pressure
}

export type Recommendation = "Shoot" | "Take it on" | "Pass" | "Hold up play"

export interface ShotVerdict {
  goalProbability: number // P(goal | context), 0-1
  passSuccess: number // P(retain/progress if passing), 0-1
  recommendation: Recommendation
  confidence: number // 0-1, how decisive the verdict is
  drivers: { label: string; effect: "boost" | "drag" | "neutral"; detail: string }[]
}

// Prior conversion probability by location (open play, unassisted baseline).
const LOCATION_PRIOR: Record<ShotLocation, number> = {
  "six-yard": 0.45,
  "penalty-spot": 0.22,
  "box-edge": 0.11,
  "outside-box": 0.045,
  "long-range": 0.02,
}

// Likelihood multipliers — each factor shifts the posterior conversion odds.
const ASSIST_LR: Record<AssistMethod, number> = {
  "through-ball": 1.55,
  pass: 1.1,
  solo: 1.0,
  cross: 0.85,
  "headed-pass": 0.7,
}
const SITUATION_LR: Record<Situation, number> = {
  "fast-break": 1.4,
  "open-play": 1.0,
  "set-piece": 0.9,
  corner: 0.8,
}
const BODY_LR: Record<BodyPart, number> = {
  "strong-foot": 1.0,
  "weak-foot": 0.78,
  head: 0.7,
}
const KEEPER_LR: Record<KeeperPosition, number> = {
  "rushing-out": 1.35,
  "off-line": 1.2,
  "on-line": 1.0,
  "well-set": 0.72,
}
const PRESSURE_LR: Record<Pressure, number> = {
  none: 1.25,
  light: 1.0,
  heavy: 0.6,
}

function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v))
}

export function shotProbability(ctx: ShotContext): number {
  const p =
    LOCATION_PRIOR[ctx.location] *
    ASSIST_LR[ctx.assist] *
    SITUATION_LR[ctx.situation] *
    BODY_LR[ctx.body] *
    KEEPER_LR[ctx.keeper] *
    PRESSURE_LR[ctx.pressure]
  return clamp(p, 0.01, 0.95)
}

// Probability that keeping possession (passing/holding) keeps the attack alive
// or finds a better shot. Higher when the current shot is poor and pressure is
// manageable; lower when a defender is already on top of the ball.
function retainProbability(ctx: ShotContext): number {
  const base = 0.72
  const pressureAdj = ctx.pressure === "heavy" ? -0.28 : ctx.pressure === "light" ? -0.08 : 0.05
  const locationAdj = ctx.location === "six-yard" ? -0.12 : ctx.location === "outside-box" ? 0.06 : 0
  return clamp(base + pressureAdj + locationAdj, 0.15, 0.9)
}

function driversFor(ctx: ShotContext): ShotVerdict["drivers"] {
  const drivers: ShotVerdict["drivers"] = []

  drivers.push({
    label: "Location",
    effect: LOCATION_PRIOR[ctx.location] >= 0.2 ? "boost" : LOCATION_PRIOR[ctx.location] <= 0.045 ? "drag" : "neutral",
    detail:
      ctx.location === "six-yard"
        ? "Point-blank — prime scoring zone"
        : ctx.location === "penalty-spot"
          ? "Central, high-value chance"
          : ctx.location === "box-edge"
            ? "Edge of the box — moderate odds"
            : ctx.location === "outside-box"
              ? "Outside the area — low base odds"
              : "Long range — speculative",
  })

  if (ASSIST_LR[ctx.assist] !== 1) {
    drivers.push({
      label: "Assist",
      effect: ASSIST_LR[ctx.assist] > 1 ? "boost" : "drag",
      detail:
        ctx.assist === "through-ball"
          ? "Through ball breaks the line — clean sight of goal"
          : ctx.assist === "pass"
            ? "Laid off by a team-mate — set to strike"
            : ctx.assist === "cross"
              ? "From a cross — contact is harder to time"
              : "Headed assist — awkward finish",
    })
  }

  drivers.push({
    label: "Keeper",
    effect: KEEPER_LR[ctx.keeper] > 1 ? "boost" : KEEPER_LR[ctx.keeper] < 1 ? "drag" : "neutral",
    detail:
      ctx.keeper === "rushing-out"
        ? "Keeper committed — gaps to exploit"
        : ctx.keeper === "off-line"
          ? "Keeper off the line — angle available"
          : ctx.keeper === "well-set"
            ? "Keeper set and balanced — hard to beat"
            : "Keeper on the line — standard",
  })

  drivers.push({
    label: "Pressure",
    effect: ctx.pressure === "none" ? "boost" : ctx.pressure === "heavy" ? "drag" : "neutral",
    detail:
      ctx.pressure === "none"
        ? "Time and space to shoot"
        : ctx.pressure === "heavy"
          ? "Defender closing the shot down"
          : "Defender near but not blocking",
  })

  if (ctx.situation === "fast-break") {
    drivers.push({ label: "Situation", effect: "boost", detail: "Fast break — defence disorganised" })
  }
  if (ctx.body !== "strong-foot") {
    drivers.push({
      label: "Contact",
      effect: "drag",
      detail: ctx.body === "head" ? "Header — less power and placement" : "Weaker foot — less reliable",
    })
  }

  return drivers
}

export function evaluateShot(ctx: ShotContext): ShotVerdict {
  const goalProbability = shotProbability(ctx)
  const passSuccess = retainProbability(ctx)

  // Expected value: a goal now is worth 1; retaining possession is worth a
  // fraction of a future chance. We treat a kept ball as ~0.28 of a goal of
  // expected value (a good but not certain follow-up).
  const evShoot = goalProbability
  const evPass = passSuccess * 0.28

  let recommendation: Recommendation
  if (goalProbability >= 0.28) recommendation = "Shoot"
  else if (evShoot >= evPass && goalProbability >= 0.1) recommendation = "Shoot"
  else if (goalProbability >= 0.06 && ctx.pressure !== "heavy") recommendation = "Take it on"
  else if (passSuccess >= 0.5) recommendation = "Pass"
  else recommendation = "Hold up play"

  const margin = Math.abs(evShoot - evPass)
  const confidence = clamp(0.4 + margin * 2.2, 0.4, 0.98)

  return {
    goalProbability,
    passSuccess,
    recommendation,
    confidence,
    drivers: driversFor(ctx),
  }
}

// Where the shot marker sits on the pitch (percent coords, attacking upward
// toward y=0). Used to place the Bayesian marker on the tactical map.
export function shotMarkerPosition(location: ShotLocation): { x: number; y: number } {
  switch (location) {
    case "six-yard":
      return { x: 50, y: 11 }
    case "penalty-spot":
      return { x: 50, y: 17 }
    case "box-edge":
      return { x: 50, y: 24 }
    case "outside-box":
      return { x: 50, y: 32 }
    default:
      return { x: 50, y: 40 }
  }
}

export const RECOMMENDATION_TONE: Record<Recommendation, "good" | "warn" | "bad"> = {
  Shoot: "good",
  "Take it on": "good",
  Pass: "warn",
  "Hold up play": "bad",
}
