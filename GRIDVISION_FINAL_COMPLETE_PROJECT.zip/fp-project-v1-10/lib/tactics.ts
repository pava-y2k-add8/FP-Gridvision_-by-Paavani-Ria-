// Shared tactical-plan model used by the strategy API and the pitch overlay.
// The AI returns a structured TacticalPlan; the pitch draws deterministic
// overlays (attacking channel, press line, transition arrows) from it, so the
// map never depends on the model inventing slot coordinates.

export type AttackFocus = "left" | "central" | "right" | "balanced"
export type PressIntensity = "high" | "mid" | "low"
export type Tempo = "fast" | "balanced" | "patient"

export interface TacticalPlan {
  shape: string
  attackFocus: AttackFocus
  press: PressIntensity
  tempo: Tempo
  strengths: string[]
  watchOuts: string[]
  keyPlayer: string
  summary: string
}

export const ATTACK_FOCUS_VALUES: AttackFocus[] = ["left", "central", "right", "balanced"]
export const PRESS_VALUES: PressIntensity[] = ["high", "mid", "low"]
export const TEMPO_VALUES: Tempo[] = ["fast", "balanced", "patient"]

// Vertical position (percent from top, attacking upward) of the pressing line.
export const PRESS_LINE_Y: Record<PressIntensity, number> = {
  high: 38,
  mid: 52,
  low: 66,
}

export const PRESS_LABEL: Record<PressIntensity, string> = {
  high: "High press",
  mid: "Mid block",
  low: "Low block",
}

export const TEMPO_LABEL: Record<Tempo, string> = {
  fast: "Fast, direct tempo",
  balanced: "Balanced tempo",
  patient: "Patient build-up",
}

// Horizontal band (percent) the side attacks through.
export const FOCUS_BAND: Record<AttackFocus, { x: number; width: number } | null> = {
  left: { x: 6, width: 28 },
  central: { x: 36, width: 28 },
  right: { x: 66, width: 28 },
  balanced: null,
}

export const FOCUS_LABEL: Record<AttackFocus, string> = {
  left: "Overload the left",
  central: "Attack through the middle",
  right: "Overload the right",
  balanced: "Balanced width",
}
