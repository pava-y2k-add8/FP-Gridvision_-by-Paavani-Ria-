export type Position = "GK" | "DF" | "MF" | "FW"
export type Side = "home" | "away"

export interface Player {
  id: number
  name: string
  number: number
  position: Position
  nationality: string
  age: number
  rating: number // 0-100
  fitness: number // 0-100
  injuryRisk: number // 0-100
  topSpeed: number // km/h
  distance: number // km covered
  passAccuracy: number // %
  goals: number
  assists: number
  side: Side
}

export const HOME_TEAM = {
  name: "Vercel United",
  short: "VER",
  color: "#22c55e", // pitch green
  accent: "#0d1117",
}

export const AWAY_TEAM = {
  name: "Northside FC",
  short: "NOR",
  color: "#38bdf8", // sky blue
  accent: "#0d1117",
}

export const homeSquad: Player[] = [
  { id: 1, name: "M. Okafor", number: 1, position: "GK", nationality: "NG", age: 29, rating: 84, fitness: 96, injuryRisk: 8, topSpeed: 26.1, distance: 4.2, passAccuracy: 78, goals: 0, assists: 0, side: "home" },
  { id: 2, name: "L. Rossi", number: 2, position: "DF", nationality: "IT", age: 27, rating: 81, fitness: 90, injuryRisk: 14, topSpeed: 32.4, distance: 10.1, passAccuracy: 86, goals: 0, assists: 1, side: "home" },
  { id: 3, name: "K. Bauer", number: 4, position: "DF", nationality: "DE", age: 31, rating: 83, fitness: 82, injuryRisk: 28, topSpeed: 30.9, distance: 9.4, passAccuracy: 91, goals: 1, assists: 0, side: "home" },
  { id: 4, name: "D. Silva", number: 5, position: "DF", nationality: "BR", age: 25, rating: 80, fitness: 94, injuryRisk: 11, topSpeed: 31.8, distance: 9.9, passAccuracy: 88, goals: 0, assists: 0, side: "home" },
  { id: 5, name: "T. Mbeki", number: 3, position: "DF", nationality: "ZA", age: 24, rating: 79, fitness: 88, injuryRisk: 19, topSpeed: 33.7, distance: 10.6, passAccuracy: 84, goals: 0, assists: 2, side: "home" },
  { id: 6, name: "J. Novak", number: 6, position: "MF", nationality: "CZ", age: 28, rating: 85, fitness: 91, injuryRisk: 16, topSpeed: 31.2, distance: 11.8, passAccuracy: 92, goals: 2, assists: 3, side: "home" },
  { id: 7, name: "A. Haddad", number: 8, position: "MF", nationality: "MA", age: 23, rating: 82, fitness: 93, injuryRisk: 12, topSpeed: 32.0, distance: 12.1, passAccuracy: 89, goals: 1, assists: 4, side: "home" },
  { id: 8, name: "R. Tanaka", number: 10, position: "MF", nationality: "JP", age: 26, rating: 87, fitness: 89, injuryRisk: 21, topSpeed: 33.1, distance: 11.2, passAccuracy: 90, goals: 5, assists: 6, side: "home" },
  { id: 9, name: "P. Andersen", number: 7, position: "FW", nationality: "DK", age: 24, rating: 84, fitness: 95, injuryRisk: 9, topSpeed: 34.9, distance: 10.8, passAccuracy: 79, goals: 8, assists: 3, side: "home" },
  { id: 10, name: "C. Mendez", number: 9, position: "FW", nationality: "AR", age: 27, rating: 88, fitness: 87, injuryRisk: 24, topSpeed: 34.2, distance: 9.7, passAccuracy: 76, goals: 12, assists: 4, side: "home" },
  { id: 11, name: "S. Kovac", number: 11, position: "FW", nationality: "HR", age: 22, rating: 81, fitness: 97, injuryRisk: 7, topSpeed: 35.6, distance: 11.0, passAccuracy: 74, goals: 6, assists: 5, side: "home" },
  // bench
  { id: 12, name: "F. Costa", number: 12, position: "GK", nationality: "PT", age: 33, rating: 79, fitness: 92, injuryRisk: 10, topSpeed: 25.4, distance: 0, passAccuracy: 80, goals: 0, assists: 0, side: "home" },
  { id: 13, name: "N. Diallo", number: 14, position: "DF", nationality: "SN", age: 21, rating: 76, fitness: 98, injuryRisk: 6, topSpeed: 34.0, distance: 0, passAccuracy: 82, goals: 0, assists: 0, side: "home" },
  { id: 14, name: "V. Ivanov", number: 16, position: "MF", nationality: "BG", age: 30, rating: 80, fitness: 85, injuryRisk: 22, topSpeed: 30.1, distance: 0, passAccuracy: 90, goals: 1, assists: 2, side: "home" },
  { id: 15, name: "E. Lindqvist", number: 18, position: "MF", nationality: "SE", age: 25, rating: 78, fitness: 90, injuryRisk: 13, topSpeed: 31.5, distance: 0, passAccuracy: 87, goals: 0, assists: 1, side: "home" },
  { id: 16, name: "G. Fernández", number: 19, position: "FW", nationality: "ES", age: 20, rating: 77, fitness: 99, injuryRisk: 5, topSpeed: 35.9, distance: 0, passAccuracy: 72, goals: 3, assists: 2, side: "home" },
  { id: 17, name: "H. Yılmaz", number: 21, position: "DF", nationality: "TR", age: 29, rating: 78, fitness: 80, injuryRisk: 31, topSpeed: 29.8, distance: 0, passAccuracy: 85, goals: 0, assists: 0, side: "home" },
  { id: 18, name: "B. Owusu", number: 23, position: "FW", nationality: "GH", age: 23, rating: 79, fitness: 94, injuryRisk: 11, topSpeed: 35.1, distance: 0, passAccuracy: 75, goals: 4, assists: 1, side: "home" },
]

export const startingXI = homeSquad.slice(0, 11)
export const bench = homeSquad.slice(11)

// Selectable teams for the dashboard matchup builder
export interface Team {
  id: string
  name: string
  short: string
  color: string
  rating: number // overall 0-100
  attack: number // 0-100
  defense: number // 0-100
  possession: number // avg possession tendency %
  form: ("W" | "D" | "L")[] // most recent last
}

export const TEAMS: Team[] = [
  { id: "ver", name: "Vercel United", short: "VER", color: "#22c55e", rating: 84, attack: 86, defense: 78, possession: 58, form: ["W", "W", "D", "W", "L"] },
  { id: "nor", name: "Northside FC", short: "NOR", color: "#38bdf8", rating: 80, attack: 74, defense: 79, possession: 49, form: ["L", "W", "W", "D", "W"] },
  { id: "rvr", name: "Riverside Athletic", short: "RVR", color: "#f97316", rating: 82, attack: 81, defense: 74, possession: 54, form: ["W", "D", "L", "W", "W"] },
  { id: "hrb", name: "Harbour City", short: "HRB", color: "#a855f7", rating: 78, attack: 72, defense: 80, possession: 47, form: ["D", "D", "W", "L", "D"] },
  { id: "kln", name: "Kingsland Rovers", short: "KLN", color: "#ef4444", rating: 86, attack: 88, defense: 82, possession: 61, form: ["W", "W", "W", "D", "W"] },
  { id: "mdw", name: "Meadowbrook", short: "MDW", color: "#eab308", rating: 75, attack: 70, defense: 73, possession: 45, form: ["L", "L", "D", "W", "L"] },
  { id: "stc", name: "Stonecross FC", short: "STC", color: "#14b8a6", rating: 81, attack: 79, defense: 77, possession: 52, form: ["W", "D", "W", "W", "D"] },
  { id: "ash", name: "Ashford Town", short: "ASH", color: "#ec4899", rating: 77, attack: 76, defense: 71, possession: 50, form: ["D", "L", "W", "D", "L"] },
]

export function getTeam(id: string): Team {
  return TEAMS.find((t) => t.id === id) ?? TEAMS[0]
}

// Simple win-probability model from team ratings + home advantage
export function matchup(home: Team, away: Team) {
  const HOME_ADV = 4
  const homeStrength = home.rating + HOME_ADV + (home.attack - away.defense) * 0.25
  const awayStrength = away.rating + (away.attack - home.defense) * 0.25
  const total = homeStrength + awayStrength
  const rawHome = (homeStrength / total) * 100
  // carve out a draw chance based on how close the two sides are
  const drawPct = Math.round(26 - Math.abs(rawHome - 50) * 0.35)
  const draw = Math.max(10, Math.min(30, drawPct))
  const remaining = 100 - draw
  const homeWin = Math.round((rawHome / 100) * remaining)
  const awayWin = 100 - draw - homeWin

  const totalPoss = home.possession + away.possession
  const possHome = Math.round((home.possession / totalPoss) * 100)

  return {
    homeWin,
    draw,
    awayWin,
    possHome,
    possAway: 100 - possHome,
  }
}

// Formations expressed as normalized pitch coordinates (x: 0-100 width, y: 0-100 length; 0 = own goal line)
export interface Slot {
  role: Position
  x: number
  y: number
  label: string
}

export const FORMATIONS: Record<string, Slot[]> = {
  "4-3-3": [
    { role: "GK", x: 50, y: 6, label: "GK" },
    { role: "DF", x: 18, y: 24, label: "LB" },
    { role: "DF", x: 39, y: 20, label: "CB" },
    { role: "DF", x: 61, y: 20, label: "CB" },
    { role: "DF", x: 82, y: 24, label: "RB" },
    { role: "MF", x: 30, y: 46, label: "CM" },
    { role: "MF", x: 50, y: 42, label: "CM" },
    { role: "MF", x: 70, y: 46, label: "CM" },
    { role: "FW", x: 20, y: 74, label: "LW" },
    { role: "FW", x: 50, y: 80, label: "ST" },
    { role: "FW", x: 80, y: 74, label: "RW" },
  ],
  "4-4-2": [
    { role: "GK", x: 50, y: 6, label: "GK" },
    { role: "DF", x: 18, y: 24, label: "LB" },
    { role: "DF", x: 39, y: 20, label: "CB" },
    { role: "DF", x: 61, y: 20, label: "CB" },
    { role: "DF", x: 82, y: 24, label: "RB" },
    { role: "MF", x: 18, y: 50, label: "LM" },
    { role: "MF", x: 39, y: 46, label: "CM" },
    { role: "MF", x: 61, y: 46, label: "CM" },
    { role: "MF", x: 82, y: 50, label: "RM" },
    { role: "FW", x: 38, y: 78, label: "ST" },
    { role: "FW", x: 62, y: 78, label: "ST" },
  ],
  "3-5-2": [
    { role: "GK", x: 50, y: 6, label: "GK" },
    { role: "DF", x: 30, y: 20, label: "CB" },
    { role: "DF", x: 50, y: 18, label: "CB" },
    { role: "DF", x: 70, y: 20, label: "CB" },
    { role: "MF", x: 14, y: 48, label: "LWB" },
    { role: "MF", x: 36, y: 44, label: "CM" },
    { role: "MF", x: 50, y: 40, label: "CM" },
    { role: "MF", x: 64, y: 44, label: "CM" },
    { role: "MF", x: 86, y: 48, label: "RWB" },
    { role: "FW", x: 38, y: 78, label: "ST" },
    { role: "FW", x: 62, y: 78, label: "ST" },
  ],
  "4-2-3-1": [
    { role: "GK", x: 50, y: 6, label: "GK" },
    { role: "DF", x: 18, y: 24, label: "LB" },
    { role: "DF", x: 39, y: 20, label: "CB" },
    { role: "DF", x: 61, y: 20, label: "CB" },
    { role: "DF", x: 82, y: 24, label: "RB" },
    { role: "MF", x: 38, y: 40, label: "DM" },
    { role: "MF", x: 62, y: 40, label: "DM" },
    { role: "MF", x: 20, y: 62, label: "LAM" },
    { role: "MF", x: 50, y: 60, label: "CAM" },
    { role: "MF", x: 80, y: 62, label: "RAM" },
    { role: "FW", x: 50, y: 82, label: "ST" },
  ],
}

export const FORMATION_NAMES = Object.keys(FORMATIONS)

// Match / possession data
export const matchMeta = {
  competition: "Premier Division · Matchday 24",
  venue: "Riverside Arena",
  date: "Sat 21 Mar",
  status: "FT",
  homeScore: 2,
  awayScore: 1,
  possessionHome: 58,
  possessionAway: 42,
  attendance: "41,208",
}

export const possessionTimeline = [
  { minute: 0, home: 50, away: 50 },
  { minute: 15, home: 61, away: 39 },
  { minute: 30, home: 57, away: 43 },
  { minute: 45, home: 63, away: 37 },
  { minute: 60, home: 54, away: 46 },
  { minute: 75, home: 59, away: 41 },
  { minute: 90, home: 58, away: 42 },
]

export const shotData = [
  { name: "Shots", home: 16, away: 9 },
  { name: "On Target", home: 7, away: 3 },
  { name: "Corners", home: 8, away: 4 },
  { name: "Fouls", home: 11, away: 14 },
  { name: "Offsides", home: 2, away: 3 },
]

export const passNetwork = [
  { zone: "Def 3rd", home: 182, away: 141 },
  { zone: "Mid 3rd", home: 264, away: 198 },
  { zone: "Att 3rd", home: 121, away: 77 },
]

export const xgTimeline = [
  { minute: 10, home: 0.12, away: 0.04 },
  { minute: 20, home: 0.31, away: 0.09 },
  { minute: 34, home: 0.55, away: 0.28 },
  { minute: 45, home: 0.88, away: 0.34 },
  { minute: 58, home: 1.12, away: 0.61 },
  { minute: 67, home: 1.44, away: 0.72 },
  { minute: 79, home: 1.79, away: 0.95 },
  { minute: 90, home: 2.05, away: 1.08 },
]

export const radarData = [
  { metric: "Attack", home: 82, away: 64 },
  { metric: "Defense", home: 74, away: 71 },
  { metric: "Pressing", home: 88, away: 59 },
  { metric: "Passing", home: 86, away: 70 },
  { metric: "Set Pieces", home: 61, away: 78 },
  { metric: "Transition", home: 79, away: 66 },
]

export interface CalendarEvent {
  id: string
  title: string
  date: string // ISO date
  type: "match" | "training" | "recovery" | "meeting"
  note: string
  author: string
}

export const initialEvents: CalendarEvent[] = [
  { id: "e1", title: "vs Northside FC (H)", date: "2026-03-21", type: "match", note: "Kickoff 15:00. Press high, exploit their left flank.", author: "Coach A" },
  { id: "e2", title: "Recovery + video review", date: "2026-03-22", type: "recovery", note: "Pool session, then 30 min clips.", author: "Fitness" },
  { id: "e3", title: "Tactical session — pressing traps", date: "2026-03-24", type: "training", note: "Focus on 4-3-3 mid-block.", author: "Coach B" },
  { id: "e4", title: "Set-piece drills", date: "2026-03-26", type: "training", note: "New corner routine for Bauer.", author: "Coach A" },
  { id: "e5", title: "Squad meeting", date: "2026-03-27", type: "meeting", note: "Announce travel squad.", author: "Manager" },
]
