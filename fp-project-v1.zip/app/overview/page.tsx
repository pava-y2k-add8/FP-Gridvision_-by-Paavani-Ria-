"use client"

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { PageHeader } from "@/components/page-header"
import {
  HOME_TEAM,
  AWAY_TEAM,
  matchMeta,
  possessionTimeline,
  shotData,
  xgTimeline,
  radarData,
  passNetwork,
} from "@/lib/data"

const H = HOME_TEAM.color
const A = AWAY_TEAM.color

const tooltipStyle = {
  backgroundColor: "#1a2030",
  border: "1px solid rgba(255,255,255,0.12)",
  borderRadius: 8,
  fontSize: 12,
}

export default function OverviewPage() {
  const possessionPie = [
    { name: HOME_TEAM.short, value: matchMeta.possessionHome, color: H },
    { name: AWAY_TEAM.short, value: matchMeta.possessionAway, color: A },
  ]

  return (
    <>
      <PageHeader
        eyebrow="Post-Game"
        title="Match Overview"
        description={`${HOME_TEAM.name} vs ${AWAY_TEAM.name} · ${matchMeta.competition}`}
        actions={
          <Badge variant="secondary" className="font-mono">
            {matchMeta.homeScore}–{matchMeta.awayScore} {matchMeta.status}
          </Badge>
        }
      />

      <div className="space-y-6 px-5 py-6 md:px-8">
        {/* Legend */}
        <div className="flex flex-wrap items-center gap-4 text-xs">
          <LegendDot color={H} label={HOME_TEAM.name} />
          <LegendDot color={A} label={AWAY_TEAM.name} />
          <span className="ml-auto text-muted-foreground">
            {matchMeta.venue} · {matchMeta.attendance} attendance
          </span>
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          {/* Possession pie */}
          <ChartCard title="Possession" className="lg:col-span-1">
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={possessionPie}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                  strokeWidth={0}
                >
                  {possessionPie.map((d) => (
                    <Cell key={d.name} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => `${v}%`} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-around font-mono text-sm">
              <span style={{ color: H }}>{matchMeta.possessionHome}%</span>
              <span style={{ color: A }}>{matchMeta.possessionAway}%</span>
            </div>
          </ChartCard>

          {/* Possession timeline */}
          <ChartCard title="Possession over time" className="lg:col-span-2">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={possessionTimeline} margin={{ left: -20, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="ph" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={H} stopOpacity={0.5} />
                    <stop offset="100%" stopColor={H} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                <XAxis dataKey="minute" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} unit="'" />
                <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} domain={[0, 100]} />
                <Tooltip contentStyle={tooltipStyle} />
                <Area type="monotone" dataKey="home" name={HOME_TEAM.short} stroke={H} fill="url(#ph)" strokeWidth={2} />
                <Line type="monotone" dataKey="away" name={AWAY_TEAM.short} stroke={A} strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* Shots / match stats bar */}
          <ChartCard title="Match statistics" className="lg:col-span-2">
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={shotData} margin={{ left: -20, right: 8, top: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" vertical={false} />
                <XAxis dataKey="name" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} />
                <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="home" name={HOME_TEAM.short} fill={H} radius={[3, 3, 0, 0]} />
                <Bar dataKey="away" name={AWAY_TEAM.short} fill={A} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* Team radar */}
          <ChartCard title="Team profile" className="lg:col-span-1">
            <ResponsiveContainer width="100%" height={280}>
              <RadarChart data={radarData} outerRadius={90}>
                <PolarGrid stroke="rgba(255,255,255,0.12)" />
                <PolarAngleAxis dataKey="metric" tick={{ fill: "rgba(255,255,255,0.6)", fontSize: 10 }} />
                <Radar name={HOME_TEAM.short} dataKey="home" stroke={H} fill={H} fillOpacity={0.3} />
                <Radar name={AWAY_TEAM.short} dataKey="away" stroke={A} fill={A} fillOpacity={0.2} />
                <Tooltip contentStyle={tooltipStyle} />
              </RadarChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* xG timeline */}
          <ChartCard title="Expected goals (xG)" className="lg:col-span-2">
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={xgTimeline} margin={{ left: -20, right: 8, top: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                <XAxis dataKey="minute" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} unit="'" />
                <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line type="stepAfter" dataKey="home" name={HOME_TEAM.short} stroke={H} strokeWidth={2} dot={false} />
                <Line type="stepAfter" dataKey="away" name={AWAY_TEAM.short} stroke={A} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* Pass distribution by zone */}
          <ChartCard title="Passes by pitch third" className="lg:col-span-3">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={passNetwork} layout="vertical" margin={{ left: 20, right: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" horizontal={false} />
                <XAxis type="number" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} />
                <YAxis type="category" dataKey="zone" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} width={70} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="home" name={HOME_TEAM.short} fill={H} radius={[0, 3, 3, 0]} />
                <Bar dataKey="away" name={AWAY_TEAM.short} fill={A} radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      </div>
    </>
  )
}

function ChartCard({
  title,
  className,
  children,
}: {
  title: string
  className?: string
  children: React.ReactNode
}) {
  return (
    <Card className={`gap-4 p-5 ${className ?? ""}`}>
      <h3 className="text-sm font-semibold">{title}</h3>
      {children}
    </Card>
  )
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="size-3 rounded-sm" style={{ backgroundColor: color }} />
      <span className="text-muted-foreground">{label}</span>
    </span>
  )
}
