"use client"

import { useRef, useState } from "react"
import { Shuffle, RotateCcw, Users, Move } from "lucide-react"
import { PageHeader } from "@/components/page-header"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Pitch } from "@/components/pitch"
import {
  FORMATIONS,
  FORMATION_NAMES,
  startingXI,
  bench,
  HOME_TEAM,
  type Position,
} from "@/lib/data"
import { cn } from "@/lib/utils"

interface Token {
  id: number
  name: string
  number: number
  role: Position
  label: string
  x: number // 0-100
  y: number // 0-100 (0 = top/attacking box in this view we flip)
}

function tokensFromFormation(name: string): Token[] {
  const slots = FORMATIONS[name]
  return slots.map((s, i) => {
    const p = startingXI[i]
    return {
      id: p.id,
      name: p.name,
      number: p.number,
      role: s.role,
      label: s.label,
      // formation y is 0 (own goal) -> 100 (attack). Pitch view: own goal at bottom.
      x: s.x,
      y: 100 - s.y,
    }
  })
}

const ROLE_BANDS: Record<Position, [number, number]> = {
  GK: [90, 97],
  DF: [68, 82],
  MF: [42, 62],
  FW: [15, 34],
}

const rand = (min: number, max: number) => min + Math.random() * (max - min)

export default function TacticsPage() {
  const [formation, setFormation] = useState("4-3-3")
  const [tokens, setTokens] = useState<Token[]>(() => tokensFromFormation("4-3-3"))
  const [dragId, setDragId] = useState<number | null>(null)
  const pitchRef = useRef<HTMLDivElement>(null)

  const applyFormation = (name: string) => {
    setFormation(name)
    setTokens(tokensFromFormation(name))
  }

  const randomize = () => {
    setTokens((prev) =>
      prev.map((t) => {
        const [minY, maxY] = ROLE_BANDS[t.role]
        return {
          ...t,
          x: t.role === "GK" ? rand(42, 58) : rand(8, 92),
          y: rand(minY, maxY),
        }
      }),
    )
  }

  const onPointerDown = (id: number) => (e: React.PointerEvent) => {
    e.preventDefault()
    setDragId(id)
    ;(e.target as HTMLElement).setPointerCapture(e.pointerId)
  }

  const onPointerMove = (e: React.PointerEvent) => {
    if (dragId === null || !pitchRef.current) return
    const rect = pitchRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    setTokens((prev) =>
      prev.map((t) =>
        t.id === dragId
          ? { ...t, x: Math.max(3, Math.min(97, x)), y: Math.max(3, Math.min(97, y)) }
          : t,
      ),
    )
  }

  const onPointerUp = () => setDragId(null)

  const roleCounts = tokens.reduce(
    (acc, t) => {
      acc[t.role] = (acc[t.role] ?? 0) + 1
      return acc
    },
    {} as Record<Position, number>,
  )

  return (
    <>
      <PageHeader
        eyebrow="Lineup & Tactics"
        title="Formation & Strategy Board"
        description="Pick a shape to auto-arrange your XI, drag any player to fine-tune, or scatter the team into a random tactical setup within the chosen ratio."
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={randomize}>
              <Shuffle className="size-4" /> Auto tactic
            </Button>
            <Button variant="secondary" onClick={() => applyFormation(formation)}>
              <RotateCcw className="size-4" /> Reset
            </Button>
          </div>
        }
      />

      <div className="grid gap-6 px-5 py-6 md:px-8 lg:grid-cols-[minmax(0,1fr)_320px]">
        {/* Pitch */}
        <div>
          <div
            ref={pitchRef}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            className="mx-auto max-w-md touch-none select-none"
          >
            <Pitch>
              {tokens.map((t) => (
                <button
                  key={t.id}
                  onPointerDown={onPointerDown(t.id)}
                  className={cn(
                    "absolute z-10 flex -translate-x-1/2 -translate-y-1/2 cursor-grab flex-col items-center gap-0.5 active:cursor-grabbing",
                    dragId === t.id && "z-20",
                  )}
                  style={{ left: `${t.x}%`, top: `${t.y}%` }}
                  aria-label={`${t.name}, ${t.label}`}
                >
                  <span
                    className={cn(
                      "grid size-8 place-items-center rounded-full font-mono text-xs font-bold text-black shadow-lg ring-2 ring-black/30 transition-transform sm:size-9",
                      dragId === t.id && "scale-110",
                    )}
                    style={{ backgroundColor: HOME_TEAM.color }}
                  >
                    {t.number}
                  </span>
                  <span className="rounded bg-black/70 px-1 text-[9px] font-medium leading-tight text-white">
                    {t.name.split(" ").slice(-1)[0]}
                  </span>
                </button>
              ))}
            </Pitch>
          </div>
          <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
            <Move className="size-3.5" /> Drag any player to reposition
          </p>
        </div>

        {/* Controls */}
        <div className="space-y-4">
          <Card className="gap-4 p-5">
            <h3 className="text-sm font-semibold">Formation</h3>
            <Select value={formation} onValueChange={applyFormation}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {FORMATION_NAMES.map((f) => (
                  <SelectItem key={f} value={f}>
                    {f}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="grid grid-cols-4 gap-2">
              {(["GK", "DF", "MF", "FW"] as Position[]).map((r) => (
                <div key={r} className="rounded-lg border border-border p-2 text-center">
                  <p className="text-[10px] text-muted-foreground">{r}</p>
                  <p className="font-mono text-lg font-semibold tabular-nums">{roleCounts[r] ?? 0}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card className="gap-3 p-5">
            <div className="flex items-center gap-2">
              <Users className="size-4 text-primary" />
              <h3 className="text-sm font-semibold">Starting XI</h3>
            </div>
            <ul className="space-y-1.5">
              {tokens.map((t) => (
                <li key={t.id} className="flex items-center gap-2 text-sm">
                  <span className="grid size-6 shrink-0 place-items-center rounded bg-secondary font-mono text-[11px]">
                    {t.number}
                  </span>
                  <span className="flex-1 truncate">{t.name}</span>
                  <Badge variant="secondary" className="font-mono text-[10px]">
                    {t.label}
                  </Badge>
                </li>
              ))}
            </ul>
          </Card>

          <Card className="gap-3 p-5">
            <h3 className="text-sm font-semibold">Bench</h3>
            <ul className="space-y-1.5">
              {bench.map((p) => (
                <li key={p.id} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="grid size-6 shrink-0 place-items-center rounded bg-secondary font-mono text-[11px]">
                    {p.number}
                  </span>
                  <span className="flex-1 truncate">{p.name}</span>
                  <Badge variant="outline" className="font-mono text-[10px]">
                    {p.position}
                  </Badge>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </>
  )
}
