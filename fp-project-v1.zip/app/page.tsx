import Link from "next/link"
import {
  Video,
  ClipboardList,
  PieChart,
  ArrowRight,
} from "lucide-react"
import { PageHeader } from "@/components/page-header"
import { MatchupSelector } from "@/components/matchup-selector"
import { Card } from "@/components/ui/card"
import { buttonVariants } from "@/components/ui/button"

const features = [
  {
    href: "/analysis",
    icon: Video,
    title: "Video Analysis",
    desc: "Import footage from your device or YouTube. Detect and track every player, split teams by jersey colour, and measure possession, speed and distance.",
  },
  {
    href: "/tactics",
    icon: ClipboardList,
    title: "Lineup & Tactics",
    desc: "Build your XI from the squad database, drag players across the pitch, and auto-generate formations to plan your approach.",
  },
  {
    href: "/overview",
    icon: PieChart,
    title: "Post-Game Overview",
    desc: "Break the match down with possession timelines, shot maps, xG curves and team radar comparisons.",
  },
]

export default function DashboardPage() {
  return (
    <>
      <PageHeader
        eyebrow="Dashboard"
        title="Match Intelligence Console"
        description="Choose a matchup, compare the two sides, then dive into video analysis, tactics and post-game analytics."
        actions={
          <Link href="/analysis" className={buttonVariants()}>
            New analysis <ArrowRight className="size-4" />
          </Link>
        }
      />

      <div className="space-y-6 px-5 py-6 md:px-8">
        {/* Team vs team matchup builder */}
        <MatchupSelector />

        {/* Feature entries */}
        <div className="grid gap-4 md:grid-cols-3">
          {features.map((f) => {
            const Icon = f.icon
            return (
              <Link key={f.href} href={f.href} className="group">
                <Card className="h-full gap-3 p-5 transition-colors hover:border-primary/50">
                  <div className="flex items-center justify-between">
                    <span className="grid size-10 place-items-center rounded-lg bg-primary/10 text-primary">
                      <Icon className="size-5" />
                    </span>
                    <ArrowRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
                  </div>
                  <h3 className="text-base font-semibold">{f.title}</h3>
                  <p className="text-sm text-muted-foreground text-pretty">{f.desc}</p>
                </Card>
              </Link>
            )
          })}
        </div>
      </div>
    </>
  )
}
