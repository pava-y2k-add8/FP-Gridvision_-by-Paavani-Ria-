"use client"

import { useMemo, useRef, useState } from "react"
import {
  Upload,
  MonitorPlay,
  Play,
  Pause,
  ScanLine,
  Tag,
  Waypoints,
  Percent,
  Gauge,
  Route,
  Shirt,
  Loader2,
  RotateCcw,
} from "lucide-react"
import { PageHeader } from "@/components/page-header"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { DetectionOverlay, buildTracks } from "@/components/detection-overlay"
import { startingXI, HOME_TEAM, AWAY_TEAM } from "@/lib/data"
import { cn } from "@/lib/utils"

type Phase = "idle" | "processing" | "done"

export default function AnalysisPage() {
  const [phase, setPhase] = useState<Phase>("idle")
  const [progress, setProgress] = useState(0)
  const [sourceLabel, setSourceLabel] = useState("")
  const [ytUrl, setYtUrl] = useState("")

  const [playing, setPlaying] = useState(true)
  const [showBoxes, setShowBoxes] = useState(true)
  const [showLabels, setShowLabels] = useState(true)
  const [showTrails, setShowTrails] = useState(false)

  const fileRef = useRef<HTMLInputElement>(null)
  const tracks = useMemo(() => buildTracks(), [])

  const runAnalysis = (label: string) => {
    setSourceLabel(label)
    setPhase("processing")
    setProgress(0)
    const started = Date.now()
    const timer = setInterval(() => {
      const elapsed = Date.now() - started
      const pct = Math.min(100, Math.round((elapsed / 2600) * 100))
      setProgress(pct)
      if (pct >= 100) {
        clearInterval(timer)
        setPhase("done")
        setPlaying(true)
      }
    }, 90)
  }

  const reset = () => {
    setPhase("idle")
    setProgress(0)
    setSourceLabel("")
    setYtUrl("")
  }

  return (
    <>
      <PageHeader
        eyebrow="Video Analysis"
        title="Player Detection & Tracking"
        description="Import footage, detect every player with YOLO, assign teams by jersey colour with KMeans, then read possession, speed and distance per player."
        actions={
          phase === "done" ? (
            <Button variant="secondary" onClick={reset}>
              <RotateCcw className="size-4" /> New source
            </Button>
          ) : null
        }
      />

      <div className="space-y-6 px-5 py-6 md:px-8">
        {phase === "idle" && (
          <ImportPanel
            fileRef={fileRef}
            ytUrl={ytUrl}
            setYtUrl={setYtUrl}
            onFile={(name) => runAnalysis(name)}
            onYoutube={(url) => runAnalysis(url)}
          />
        )}

        {phase === "processing" && <ProcessingPanel progress={progress} source={sourceLabel} />}

        {phase === "done" && (
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-4">
              {/* Video / detection viewport */}
              <Card className="overflow-hidden p-0">
                <div className="relative aspect-video w-full">
                  <PitchCamera />
                  <DetectionOverlay
                    players={tracks}
                    playing={playing}
                    showBoxes={showBoxes}
                    showLabels={showLabels}
                    showTrails={showTrails}
                  />
                  {/* HUD */}
                  <div className="pointer-events-none absolute left-3 top-3 flex items-center gap-2">
                    <Badge className="bg-destructive/90 font-mono text-[10px] text-white">● REC</Badge>
                    <Badge variant="secondary" className="font-mono text-[10px]">
                      22 tracked
                    </Badge>
                  </div>
                  <div className="pointer-events-none absolute right-3 top-3">
                    <Badge variant="secondary" className="max-w-[220px] truncate font-mono text-[10px]">
                      {sourceLabel}
                    </Badge>
                  </div>
                </div>

                {/* Controls */}
                <div className="flex flex-wrap items-center gap-2 border-t border-border p-3">
                  <Button size="sm" variant="secondary" onClick={() => setPlaying((v) => !v)}>
                    {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
                    {playing ? "Pause" : "Play"}
                  </Button>
                  <div className="mx-1 h-5 w-px bg-border" />
                  <Toggle active={showBoxes} onClick={() => setShowBoxes((v) => !v)} icon={ScanLine}>
                    Boxes
                  </Toggle>
                  <Toggle active={showLabels} onClick={() => setShowLabels((v) => !v)} icon={Tag}>
                    Labels
                  </Toggle>
                  <Toggle active={showTrails} onClick={() => setShowTrails((v) => !v)} icon={Waypoints}>
                    Trails
                  </Toggle>
                </div>
              </Card>

              {/* Per-player tracking table */}
              <TrackingTable />
            </div>

            {/* Right column: team detection + possession */}
            <div className="space-y-4">
              <TeamDetectionCard />
              <PossessionCard />
              <PipelineCard />
            </div>
          </div>
        )}
      </div>
    </>
  )
}

function ImportPanel({
  fileRef,
  ytUrl,
  setYtUrl,
  onFile,
  onYoutube,
}: {
  fileRef: React.RefObject<HTMLInputElement | null>
  ytUrl: string
  setYtUrl: (v: string) => void
  onFile: (name: string) => void
  onYoutube: (url: string) => void
}) {
  return (
    <div className="mx-auto max-w-2xl">
      <Tabs defaultValue="upload">
        <TabsList className="w-full">
          <TabsTrigger value="upload" className="flex-1">
            <Upload className="size-4" /> Local file
          </TabsTrigger>
          <TabsTrigger value="youtube" className="flex-1">
            <MonitorPlay className="size-4" /> YouTube
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload">
          <Card className="p-0">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="flex w-full flex-col items-center gap-3 rounded-xl border-2 border-dashed border-border px-6 py-14 text-center transition-colors hover:border-primary/60 hover:bg-primary/5"
            >
              <span className="grid size-12 place-items-center rounded-full bg-primary/10 text-primary">
                <Upload className="size-6" />
              </span>
              <span className="text-sm font-medium">Drop a match clip or click to browse</span>
              <span className="text-xs text-muted-foreground">MP4, MOV or WebM · up to 1080p</span>
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                onFile(f ? f.name : "clip.mp4")
              }}
            />
          </Card>
        </TabsContent>

        <TabsContent value="youtube">
          <Card className="gap-4 p-6">
            <div className="flex items-center gap-3">
              <span className="grid size-11 place-items-center rounded-lg bg-destructive/10 text-destructive">
                <MonitorPlay className="size-5" />
              </span>
              <div>
                <p className="text-sm font-medium">Import from YouTube</p>
                <p className="text-xs text-muted-foreground">Paste a match or highlight URL to fetch and analyse.</p>
              </div>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input
                placeholder="https://www.youtube.com/watch?v=..."
                value={ytUrl}
                onChange={(e) => setYtUrl(e.target.value)}
              />
              <Button
                disabled={!ytUrl.trim()}
                onClick={() => onYoutube(ytUrl.trim() || "YouTube clip")}
              >
                Fetch & analyse
              </Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function ProcessingPanel({ progress, source }: { progress: number; source: string }) {
  const steps = [
    { at: 15, label: "Decoding frames" },
    { at: 40, label: "Running YOLO detection" },
    { at: 65, label: "DeepSORT tracking" },
    { at: 85, label: "KMeans jersey clustering" },
    { at: 100, label: "Computing speed & distance" },
  ]
  return (
    <div className="mx-auto max-w-2xl">
      <Card className="gap-5 p-8">
        <div className="flex items-center gap-3">
          <Loader2 className="size-5 animate-spin text-primary" />
          <div className="min-w-0">
            <p className="text-sm font-medium">Analysing footage</p>
            <p className="truncate font-mono text-xs text-muted-foreground">{source}</p>
          </div>
          <span className="ml-auto font-mono text-lg font-semibold tabular-nums">{progress}%</span>
        </div>
        <Progress value={progress} />
        <ul className="space-y-2">
          {steps.map((s) => {
            const done = progress >= s.at
            const active = !done && progress >= s.at - 25
            return (
              <li
                key={s.label}
                className={cn(
                  "flex items-center gap-2 font-mono text-xs",
                  done ? "text-primary" : active ? "text-foreground" : "text-muted-foreground",
                )}
              >
                <span className={cn("size-1.5 rounded-full", done ? "bg-primary" : active ? "bg-foreground animate-pulse" : "bg-muted-foreground/40")} />
                {s.label}
              </li>
            )
          })}
        </ul>
      </Card>
    </div>
  )
}

function Toggle({
  active,
  onClick,
  icon: Icon,
  children,
}: {
  active: boolean
  onClick: () => void
  icon: React.ComponentType<{ className?: string }>
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors",
        active ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary",
      )}
    >
      <Icon className="size-3.5" />
      {children}
    </button>
  )
}

function PitchCamera() {
  // broadcast-style green pitch with subtle perspective
  return (
    <div className="absolute inset-0 bg-[linear-gradient(175deg,#1a5f2a_0%,#166b2c_45%,#0f5222_100%)]">
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "repeating-linear-gradient(90deg, transparent 0 46px, rgba(255,255,255,0.12) 46px 48px)",
        }}
      />
      <svg className="absolute inset-0 h-full w-full" viewBox="0 0 100 56" preserveAspectRatio="none">
        <rect x="3" y="3" width="94" height="50" fill="none" stroke="white" strokeOpacity="0.35" strokeWidth="0.3" />
        <line x1="50" y1="3" x2="50" y2="53" stroke="white" strokeOpacity="0.35" strokeWidth="0.3" />
        <circle cx="50" cy="28" r="7" fill="none" stroke="white" strokeOpacity="0.35" strokeWidth="0.3" />
        <rect x="3" y="16" width="12" height="24" fill="none" stroke="white" strokeOpacity="0.35" strokeWidth="0.3" />
        <rect x="85" y="16" width="12" height="24" fill="none" stroke="white" strokeOpacity="0.35" strokeWidth="0.3" />
      </svg>
    </div>
  )
}

function TeamDetectionCard() {
  return (
    <Card className="gap-4 p-5">
      <div className="flex items-center gap-2">
        <Shirt className="size-4 text-primary" />
        <h3 className="text-sm font-semibold">Jersey-colour team detection</h3>
      </div>
      <p className="text-xs text-muted-foreground">
        Pixels inside each player box are clustered with KMeans; the dominant shirt colour assigns the team.
      </p>
      <div className="grid grid-cols-2 gap-3">
        <TeamSwatch team={HOME_TEAM} count={11} />
        <TeamSwatch team={AWAY_TEAM} count={11} />
      </div>
    </Card>
  )
}

function TeamSwatch({ team, count }: { team: typeof HOME_TEAM; count: number }) {
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="flex items-center gap-2">
        <span className="size-6 rounded-md" style={{ backgroundColor: team.color }} />
        <span className="font-mono text-xs">{team.short}</span>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">{team.name}</p>
      <p className="font-mono text-lg font-semibold tabular-nums">{count}</p>
    </div>
  )
}

function PossessionCard() {
  const home = 58
  const away = 42
  return (
    <Card className="gap-4 p-5">
      <div className="flex items-center gap-2">
        <Percent className="size-4 text-[var(--color-accent)]" />
        <h3 className="text-sm font-semibold">Ball possession</h3>
      </div>
      <div className="flex items-end justify-between font-mono">
        <div>
          <p className="text-2xl font-semibold" style={{ color: HOME_TEAM.color }}>{home}%</p>
          <p className="text-xs text-muted-foreground">{HOME_TEAM.short}</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-semibold" style={{ color: AWAY_TEAM.color }}>{away}%</p>
          <p className="text-xs text-muted-foreground">{AWAY_TEAM.short}</p>
        </div>
      </div>
      <div className="flex h-2.5 overflow-hidden rounded-full bg-secondary">
        <div className="h-full" style={{ width: `${home}%`, backgroundColor: HOME_TEAM.color }} />
        <div className="h-full flex-1" style={{ backgroundColor: AWAY_TEAM.color }} />
      </div>
      <p className="text-xs text-muted-foreground">
        Derived from which team holds the nearest tracked player to the ball each frame.
      </p>
    </Card>
  )
}

function PipelineCard() {
  const rows = [
    { label: "Detector", value: "YOLOv8x" },
    { label: "Tracker", value: "DeepSORT" },
    { label: "Team split", value: "KMeans (k=2)" },
    { label: "Frame rate", value: "25 fps" },
    { label: "Perspective", value: "Homography" },
  ]
  return (
    <Card className="gap-3 p-5">
      <h3 className="text-sm font-semibold">Pipeline</h3>
      <dl className="space-y-2">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center justify-between text-xs">
            <dt className="text-muted-foreground">{r.label}</dt>
            <dd className="font-mono">{r.value}</dd>
          </div>
        ))}
      </dl>
    </Card>
  )
}

function TrackingTable() {
  const [sort, setSort] = useState<"topSpeed" | "distance" | "number">("topSpeed")
  const rows = [...startingXI].sort((a, b) => (b[sort] as number) - (a[sort] as number))
  const maxSpeed = Math.max(...startingXI.map((p) => p.topSpeed))
  const maxDist = Math.max(...startingXI.map((p) => p.distance))

  return (
    <Card className="gap-0 p-0">
      <div className="flex items-center justify-between border-b border-border p-4">
        <div className="flex items-center gap-2">
          <Gauge className="size-4 text-primary" />
          <h3 className="text-sm font-semibold">Per-player tracking</h3>
        </div>
        <div className="flex gap-1">
          {(["topSpeed", "distance", "number"] as const).map((k) => (
            <button
              key={k}
              onClick={() => setSort(k)}
              className={cn(
                "rounded-md px-2 py-1 text-[11px] font-medium transition-colors",
                sort === k ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary",
              )}
            >
              {k === "topSpeed" ? "Speed" : k === "distance" ? "Distance" : "No."}
            </button>
          ))}
        </div>
      </div>
      <div className="divide-y divide-border">
        {rows.map((p) => (
          <div key={p.id} className="flex items-center gap-3 px-4 py-2.5">
            <span className="grid size-7 shrink-0 place-items-center rounded-md bg-secondary font-mono text-xs">
              {p.number}
            </span>
            <div className="w-28 shrink-0">
              <p className="truncate text-sm font-medium">{p.name}</p>
              <p className="text-[11px] text-muted-foreground">{p.position}</p>
            </div>
            <div className="flex flex-1 items-center gap-3">
              <div className="flex-1">
                <div className="mb-0.5 flex justify-between font-mono text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-1"><Gauge className="size-3" /> {p.topSpeed} km/h</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                  <div className="h-full bg-primary" style={{ width: `${(p.topSpeed / maxSpeed) * 100}%` }} />
                </div>
              </div>
              <div className="flex-1">
                <div className="mb-0.5 flex justify-between font-mono text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-1"><Route className="size-3" /> {p.distance} km</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                  <div className="h-full bg-[var(--color-accent)]" style={{ width: `${(p.distance / maxDist) * 100}%` }} />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  )
}
