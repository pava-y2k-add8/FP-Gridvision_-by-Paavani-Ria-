"use client"

import { useMemo, useState } from "react"
import { ArrowLeftRight, Users, Gauge, Percent, Trophy } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { StatCard } from "@/components/stat-card"
import { TEAMS, getTeam, matchup, type Team } from "@/lib/data"

export function MatchupSelector() {
  const [homeId, setHomeId] = useState(TEAMS[0].id)
  const [awayId, setAwayId] = useState(TEAMS[1].id)

  const home = getTeam(homeId)
  const away = getTeam(awayId)
  const sameTeam = homeId === awayId

  const result = useMemo(() => matchup(home, away), [home, away])

  function swap() {
    setHomeId(awayId)
    setAwayId(homeId)
  }

  return (
    <Card className="overflow-hidden p-0">
      {/* Selector row */}
      <div className="grid grid-cols-1 items-end gap-4 border-b border-border p-6 md:grid-cols-[1fr_auto_1fr]">
        <TeamSelect
          label="Home team"
          value={homeId}
          onChange={setHomeId}
          disabledId={awayId}
          team={home}
        />

        <div className="flex items-center justify-center pb-1">
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={swap}
            aria-label="Swap home and away teams"
            className="rounded-full"
          >
            <ArrowLeftRight className="size-4" />
          </Button>
        </div>

        <TeamSelect
          label="Away team"
          value={awayId}
          onChange={setAwayId}
          disabledId={homeId}
          team={away}
          align="right"
        />
      </div>

      {sameTeam ? (
        <div className="p-6 text-center text-sm text-muted-foreground">
          Pick two different teams to compare the matchup.
        </div>
      ) : (
        <div className="space-y-6 p-6">
          {/* Matchup hero */}
          <div className="flex items-center justify-between gap-4">
            <TeamBadge team={home} />
            <div className="text-center">
              <div className="font-mono text-xs uppercase tracking-wide text-muted-foreground">
                Matchday preview
              </div>
              <div className="font-mono text-2xl font-semibold text-muted-foreground">vs</div>
            </div>
            <TeamBadge team={away} align="right" />
          </div>

          {/* Win probability */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-medium">
              <span style={{ color: home.color }}>{result.homeWin}% {home.short} win</span>
              <span className="text-muted-foreground">{result.draw}% draw</span>
              <span style={{ color: away.color }}>{away.short} win {result.awayWin}%</span>
            </div>
            <div className="flex h-3 overflow-hidden rounded-full bg-secondary">
              <div className="h-full" style={{ width: `${result.homeWin}%`, backgroundColor: home.color }} />
              <div className="h-full bg-muted-foreground/40" style={{ width: `${result.draw}%` }} />
              <div className="h-full flex-1" style={{ backgroundColor: away.color }} />
            </div>
            <p className="text-xs text-muted-foreground">
              Win probability derived from team ratings, attack vs defense and home advantage.
            </p>
          </div>

          {/* Comparison stats */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <StatCard icon={Trophy} label="Overall" value={home.rating} hint={`${away.short} ${away.rating}`} />
            <StatCard icon={Gauge} label="Attack" value={home.attack} accent="accent" hint={`${away.short} ${away.attack}`} />
            <StatCard icon={Users} label="Defense" value={home.defense} accent="chart-3" hint={`${away.short} ${away.defense}`} />
            <StatCard icon={Percent} label="Possession" value={result.possHome} unit="%" hint={`${result.possAway}% away`} />
          </div>

          {/* Head-to-head bars */}
          <div className="space-y-3">
            <CompareRow label="Overall rating" home={home} away={away} homeVal={home.rating} awayVal={away.rating} />
            <CompareRow label="Attack" home={home} away={away} homeVal={home.attack} awayVal={away.attack} />
            <CompareRow label="Defense" home={home} away={away} homeVal={home.defense} awayVal={away.defense} />
            <CompareRow label="Avg possession" home={home} away={away} homeVal={result.possHome} awayVal={result.possAway} unit="%" />
          </div>

          {/* Recent form */}
          <div className="grid grid-cols-2 gap-4">
            <FormRow team={home} />
            <FormRow team={away} align="right" />
          </div>
        </div>
      )}
    </Card>
  )
}

function TeamSelect({
  label,
  value,
  onChange,
  disabledId,
  team,
  align = "left",
}: {
  label: string
  value: string
  onChange: (v: string) => void
  disabledId: string
  team: Team
  align?: "left" | "right"
}) {
  return (
    <div className="space-y-1.5">
      <label className={`block text-xs font-medium text-muted-foreground ${align === "right" ? "text-right" : ""}`}>
        {label}
      </label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="w-full">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {TEAMS.map((t) => (
            <SelectItem key={t.id} value={t.id} disabled={t.id === disabledId}>
              <span className="flex items-center gap-2">
                <span
                  className="size-3 shrink-0 rounded-sm"
                  style={{ backgroundColor: t.color }}
                  aria-hidden
                />
                {t.name}
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

function TeamBadge({ team, align = "left" }: { team: Team; align?: "left" | "right" }) {
  return (
    <div className={`flex flex-1 items-center gap-3 ${align === "right" ? "flex-row-reverse text-right" : ""}`}>
      <span
        className="grid size-12 shrink-0 place-items-center rounded-lg font-mono text-sm font-bold text-black"
        style={{ backgroundColor: team.color }}
      >
        {team.short}
      </span>
      <div className={align === "right" ? "text-right" : ""}>
        <div className="text-sm font-semibold leading-tight">{team.name}</div>
        <div className="font-mono text-xs text-muted-foreground">Rating {team.rating}</div>
      </div>
    </div>
  )
}

function CompareRow({
  label,
  home,
  away,
  homeVal,
  awayVal,
  unit = "",
}: {
  label: string
  home: Team
  away: Team
  homeVal: number
  awayVal: number
  unit?: string
}) {
  const total = homeVal + awayVal || 1
  const homePct = (homeVal / total) * 100
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between font-mono text-xs">
        <span className="tabular-nums" style={{ color: home.color }}>
          {homeVal}
          {unit}
        </span>
        <span className="text-muted-foreground">{label}</span>
        <span className="tabular-nums" style={{ color: away.color }}>
          {awayVal}
          {unit}
        </span>
      </div>
      <div className="flex h-2 overflow-hidden rounded-full bg-secondary">
        <div className="h-full" style={{ width: `${homePct}%`, backgroundColor: home.color }} />
        <div className="h-full flex-1" style={{ backgroundColor: away.color }} />
      </div>
    </div>
  )
}

function FormRow({ team, align = "left" }: { team: Team; align?: "left" | "right" }) {
  const colors: Record<string, string> = {
    W: "bg-primary text-primary-foreground",
    D: "bg-muted-foreground/40 text-foreground",
    L: "bg-destructive text-white",
  }
  return (
    <div className={`space-y-1.5 ${align === "right" ? "text-right" : ""}`}>
      <div className="text-xs font-medium text-muted-foreground">{team.short} recent form</div>
      <div className={`flex gap-1.5 ${align === "right" ? "justify-end" : ""}`}>
        {team.form.map((r, i) => (
          <span
            key={i}
            className={`grid size-6 place-items-center rounded font-mono text-xs font-bold ${colors[r]}`}
          >
            {r}
          </span>
        ))}
      </div>
    </div>
  )
}
