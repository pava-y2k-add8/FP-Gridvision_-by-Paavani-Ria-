"use client"

import type React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  Video,
  ClipboardList,
  PieChart,
  Radar,
  CircleDot,
} from "lucide-react"
import { cn } from "@/lib/utils"

const NAV = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/analysis", label: "Video Analysis", icon: Video },
  { href: "/tactics", label: "Lineup & Tactics", icon: ClipboardList },
  { href: "/overview", label: "Post-Game", icon: PieChart },
]

export function AppFrame({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-border bg-sidebar md:flex">
        <div className="flex items-center gap-2.5 px-5 py-5">
          <div className="grid size-9 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Radar className="size-5" />
          </div>
          <div className="leading-tight">
            <p className="font-mono text-sm font-semibold tracking-tight">GridVision</p>
            <p className="text-[11px] text-muted-foreground">Match Intelligence</p>
          </div>
        </div>

        <nav className="flex flex-1 flex-col gap-1 px-3 py-2">
          {NAV.map((item) => {
            const active = pathname === item.href
            const Icon = item.icon
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary/15 text-primary"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                )}
              >
                <Icon className="size-[18px]" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div className="mx-3 mb-4 rounded-lg border border-border bg-card p-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <CircleDot className="size-3.5 text-primary animate-pulse" />
            Engine online
          </div>
          <p className="mt-1 font-mono text-[11px] text-muted-foreground">
            YOLOv8 · DeepSORT · KMeans
          </p>
        </div>
      </aside>

      {/* Mobile top nav */}
      <div className="flex w-full flex-col">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-border bg-sidebar/80 px-4 py-3 backdrop-blur md:hidden">
          <div className="grid size-8 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Radar className="size-4" />
          </div>
          <span className="font-mono text-sm font-semibold">GridVision</span>
          <nav className="ml-auto flex gap-1">
            {NAV.map((item) => {
              const active = pathname === item.href
              const Icon = item.icon
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-label={item.label}
                  className={cn(
                    "grid size-9 place-items-center rounded-md",
                    active ? "bg-primary/15 text-primary" : "text-muted-foreground",
                  )}
                >
                  <Icon className="size-[18px]" />
                </Link>
              )
            })}
          </nav>
        </header>

        <main className="flex-1">{children}</main>
      </div>
    </div>
  )
}
