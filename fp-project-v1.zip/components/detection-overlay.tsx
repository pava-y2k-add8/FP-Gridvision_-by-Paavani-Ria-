"use client"

import { useEffect, useRef } from "react"

export interface TrackedPlayer {
  id: string
  team: "home" | "away"
  number: number
  bx: number // base x 0-1
  by: number // base y 0-1
  ax: number // amplitude x
  ay: number // amplitude y
  phase: number
  speed: number // km/h
}

const HOME_COLOR = "#22c55e"
const AWAY_COLOR = "#38bdf8"

export function buildTracks(): TrackedPlayer[] {
  // home (attacking up), away (defending) rough spots, normalized to the frame
  const home: [number, number, number][] = [
    [0.08, 0.5, 7], [0.24, 0.24, 2], [0.24, 0.42, 4], [0.24, 0.58, 5], [0.24, 0.76, 3],
    [0.44, 0.3, 6], [0.44, 0.5, 10], [0.44, 0.7, 8], [0.62, 0.28, 11], [0.66, 0.52, 9], [0.62, 0.74, 7],
  ]
  const away: [number, number, number][] = [
    [0.92, 0.5, 1], [0.76, 0.26, 2], [0.76, 0.44, 4], [0.76, 0.56, 5], [0.76, 0.74, 3],
    [0.58, 0.32, 6], [0.58, 0.5, 8], [0.58, 0.68, 10], [0.4, 0.3, 7], [0.36, 0.52, 9], [0.4, 0.72, 11],
  ]
  const mk = (arr: [number, number, number][], team: "home" | "away"): TrackedPlayer[] =>
    arr.map(([x, y, num], i) => ({
      id: `${team}-${i}`,
      team,
      number: num,
      bx: x,
      by: y,
      ax: 0.015 + (i % 4) * 0.008,
      ay: 0.02 + (i % 3) * 0.01,
      phase: (i * 1.7) % (Math.PI * 2),
      speed: 6 + ((i * 37) % 28),
    }))
  return [...mk(home, "home"), ...mk(away, "away")]
}

export function DetectionOverlay({
  players,
  playing,
  showBoxes,
  showLabels,
  showTrails,
}: {
  players: TrackedPlayer[]
  playing: boolean
  showBoxes: boolean
  showLabels: boolean
  showTrails: boolean
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const rafRef = useRef<number>(0)
  const tRef = useRef<number>(0)
  const trailsRef = useRef<Record<string, { x: number; y: number }[]>>({})

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let last = performance.now()

    const resize = () => {
      const rect = canvas.getBoundingClientRect()
      const dpr = window.devicePixelRatio || 1
      canvas.width = rect.width * dpr
      canvas.height = rect.height * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    window.addEventListener("resize", resize)

    const draw = (now: number) => {
      const dt = (now - last) / 1000
      last = now
      if (playing) tRef.current += dt

      const rect = canvas.getBoundingClientRect()
      const W = rect.width
      const H = rect.height
      const t = tRef.current

      ctx.clearRect(0, 0, W, H)

      players.forEach((p) => {
        const x = (p.bx + Math.sin(t * 0.8 + p.phase) * p.ax) * W
        const y = (p.by + Math.cos(t * 0.7 + p.phase) * p.ay) * H
        const color = p.team === "home" ? HOME_COLOR : AWAY_COLOR

        // trails
        if (showTrails) {
          const trail = trailsRef.current[p.id] ?? (trailsRef.current[p.id] = [])
          if (playing) {
            trail.push({ x, y })
            if (trail.length > 24) trail.shift()
          }
          ctx.beginPath()
          trail.forEach((pt, i) => {
            if (i === 0) ctx.moveTo(pt.x, pt.y)
            else ctx.lineTo(pt.x, pt.y)
          })
          ctx.strokeStyle = color + "55"
          ctx.lineWidth = 2
          ctx.stroke()
        }

        const boxW = 22
        const boxH = 34

        if (showBoxes) {
          ctx.strokeStyle = color
          ctx.lineWidth = 1.5
          ctx.strokeRect(x - boxW / 2, y - boxH / 2, boxW, boxH)
          // corner ticks
          ctx.fillStyle = color
          ctx.fillRect(x - boxW / 2, y - boxH / 2, 5, 2)
          ctx.fillRect(x - boxW / 2, y - boxH / 2, 2, 5)
          ctx.fillRect(x + boxW / 2 - 5, y + boxH / 2 - 2, 5, 2)
          ctx.fillRect(x + boxW / 2 - 2, y + boxH / 2 - 5, 2, 5)
        }

        // player dot
        ctx.beginPath()
        ctx.arc(x, y + boxH / 2 + 3, 3, 0, Math.PI * 2)
        ctx.fillStyle = color
        ctx.fill()

        if (showLabels) {
          const label = `${p.team === "home" ? "H" : "A"}${p.number}`
          ctx.font = "600 10px ui-monospace, monospace"
          const tw = ctx.measureText(label).width
          ctx.fillStyle = color
          ctx.fillRect(x - boxW / 2, y - boxH / 2 - 14, tw + 8, 12)
          ctx.fillStyle = "#0d1117"
          ctx.fillText(label, x - boxW / 2 + 4, y - boxH / 2 - 4)
        }
      })

      rafRef.current = requestAnimationFrame(draw)
    }

    rafRef.current = requestAnimationFrame(draw)
    return () => {
      cancelAnimationFrame(rafRef.current)
      window.removeEventListener("resize", resize)
    }
  }, [players, playing, showBoxes, showLabels, showTrails])

  return <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" aria-hidden />
}
